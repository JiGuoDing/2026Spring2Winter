"""
ZeroTune 算法后台监控进程
==========================

核心思想（来自 ZeroTune 论文 Section IV-V）：
- 离线层：在历史数据上预训练性能预测器（Random Forest），学习
  (parallelism, batch_size, arrival_rate) → (latency, throughput, gpu_util) 的映射。
- 在线层：监控运行中的作业，利用预测器评估所有候选配置，在满足 SLO 和队列
  稳定性约束的前提下，选择资源成本最低的配置。

本系统适配（单算子场景）：
    - 仅有一个推理算子，仅并行度 (parallelism) 可调，批次大小 (batch_size) 固定。
    - 在线阶段仅评估当前 batch_size 下的 4 个候选配置 (p=1,2,3,4)。
    - 成本度量：gpu_utilization × parallelism。
    - 约束：延迟 ≤ SLO × 0.9（安全裕度），吞吐率 ≥ 到达率（队列稳定）。

本程序与 DS2 daemon (daemon_reconfiguration_monitor_ds2_recorder.py) 保持相同的外部接口：
    - TCP 协议：接收 DS2MetricsPayload JSON 数组
    - 广播机制：prepare_rescale 消息
    - 日志格式：DecisionLogger + RescaleEventLogger（新增 zt_* 列）
    - rescale.sh 调用方式
    - CLI 参数签名：所有位置参数（与 Sink Java 算子启动命令一致）

Docker 环境说明：
    - 模型文件路径：/mnt/models/（由宿主机 zerotune_models 目录挂载）
    - 脚本路径：/mnt/code/（由宿主机代码目录挂载）
    - rescale.sh 路径：/mnt/scripts/rescale.sh
"""
import csv
import json
import math
import os
import re
import socket
import subprocess
import sys
import threading
import time
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

import joblib
import numpy as np
from loguru import logger

from zerotune_constants import (
    # 候选配置
    PARALLELISM_VALUES, BATCH_SIZE_VALUES, CANDIDATE_CONFIGS,
    MIN_PARALLELISM, MAX_PARALLELISM,
    # 算法参数
    ZT_COOLDOWN_SECONDS, ZT_MIN_HISTORY_WINDOWS, ZT_ARRIVAL_RATE_WINDOW,
    ZT_SLO_SAFETY_MARGIN, DEFAULT_SLO_MS,
    # 模型路径
    ZT_MODEL_DIR, ZT_MODEL_LATENCY, ZT_MODEL_THROUGHPUT, ZT_MODEL_GPU,
    ZT_MODEL_METADATA,
    # 成本度量
    ZT_COST_METRIC,
    # 数据结构
    ZeroTuneDecision,
)

# ─── 看门狗配置 ────────────────────────────────────────────────────────────
TIMEOUT_SECONDS         = 180
WATCHDOG_CHECK_INTERVAL = 10
REPORT_WINDOW_NUM       = 5

# ─── Flink REST API ───────────────────────────────────────────────────────
FLINK_REST = "http://flink-jm:8081"

# ─── rescale.sh 路径与默认参数 ────────────────────────────────────────────
RESCALE_SCRIPT_PATH    = "/mnt/scripts/rescale.sh"
RESCALE_SCRIPT_TIMEOUT = 2100
DEFAULT_JAR_PATH       = "/mnt/jobs/NJULocalKVCacheTest-op-state-cache-async-inference-keepalive-tcp-docker-sglang-auto-reconfig-gpuhours-ds2-5slower.jar"

# ─── 默认运行时参数（CLI 可覆盖） ─────────────────────────────────────────
DEFAULT_MAX_REQUESTS  = 1000
DEFAULT_BASE_INTERVAL = 1000
DEFAULT_CACHE_TYPE    = "FREQUENCY"
DEFAULT_SLO_MS        = 90000.0

# ─── HDFS 路径常量 ─────────────────────────────────────────────────────────
HDFS_NAMENODE     = "hdfs://10.0.0.16:9090"
HDFS_SINK_BASE    = "/sink/cache_test"
HDFS_MARKER_BASE  = f"{HDFS_NAMENODE}/tmp/job_markers"

# ─── Daemon 启动时间 / Session ID（跨重配置不变） ─────────────────────────
DAEMON_START_TIME_TS: float = time.time()
DAEMON_START_ISO: str       = datetime.fromtimestamp(DAEMON_START_TIME_TS).strftime("%Y%m%d_%H%M%S")
DAEMON_SESSION_ID: str      = DAEMON_START_ISO

# ─── 全局状态 ──────────────────────────────────────────────────────────────
last_recv_time: float          = time.time()
heartbeat_lock                 = threading.Lock()
current_job_id: Optional[str]  = None
job_id_lock                    = threading.Lock()
reconfiguration_lock           = threading.Lock()
is_reconfiguring: bool         = False
last_reconfig_time: float      = 0.0

runtime_max_requests: int  = DEFAULT_MAX_REQUESTS
runtime_base_interval: int = DEFAULT_BASE_INTERVAL
runtime_cache_type: str    = DEFAULT_CACHE_TYPE
runtime_slo_ms: float      = DEFAULT_SLO_MS

# ─── rescale 序号 & 客户端注册表（用于 prepare_rescale 广播） ─────────────
rescale_seq_counter: int            = 0
rescale_seq_lock                    = threading.Lock()
active_clients_lock                 = threading.Lock()
active_clients: List[Tuple[socket.socket, Tuple[str, int]]] = []
broadcast_send_lock                 = threading.Lock()

# ─── ZeroTune 预测器全局状态 ──────────────────────────────────────────────
zt_predictors: Dict[str, Any]       = {}   # {"latency": model, "throughput": model, "gpu": model}
zt_model_metadata: Dict[str, Any]   = {}
zt_models_loaded: bool              = False


# ============================================================================
# Rescale.sh timing 解析（与 rescale.sh 末尾 echo 行严格对齐）
# ============================================================================
_SAVEPOINT_KEYS: Tuple[str, ...] = ("Stop+Savepoint Time", "Savepoint Time", "Stop Time")
_RECOVERY_KEYS:  Tuple[str, ...] = ("State Recovery Time", "Recovery Time")
_TOTAL_KEYS:     Tuple[str, ...] = ("Total Time",)
_TIMING_MS_RE                    = re.compile(r":\s*(\d+)\s*ms")


def _classify_timing_line(stripped: str) -> Tuple[Optional[str], Optional[str]]:
    """判断一行 stdout 是否属于 timing 行，并尝试解析其中的毫秒数。"""
    for key in _SAVEPOINT_KEYS:
        if key in stripped:
            m = _TIMING_MS_RE.search(stripped)
            return "savepoint", (m.group(1) if m else None)
    for key in _RECOVERY_KEYS:
        if key in stripped:
            m = _TIMING_MS_RE.search(stripped)
            return "recovery", (m.group(1) if m else None)
    for key in _TOTAL_KEYS:
        if key in stripped:
            m = _TIMING_MS_RE.search(stripped)
            return "total", (m.group(1) if m else None)
    return None, None


def _parse_rescale_timings(stdout_lines: List[str]) -> Tuple[str, str, List[str]]:
    """遍历 rescale.sh 全部 stdout 行，抽出 savepoint / recovery 两个关键耗时（ms）。"""
    stop_savepoint_ms: str = ""
    state_recovery_ms: str = ""
    timing_lines: List[str] = []

    for line in stdout_lines:
        stripped = line.strip()
        if not stripped:
            continue
        kind, ms_str = _classify_timing_line(stripped)
        if kind is None:
            continue
        timing_lines.append(stripped)
        if ms_str is None:
            continue
        if kind == "savepoint":
            stop_savepoint_ms = ms_str
        elif kind == "recovery":
            state_recovery_ms = ms_str

    return stop_savepoint_ms, state_recovery_ms, timing_lines


def next_rescale_seq() -> int:
    """生成下一个单调递增的 rescale 序号（线程安全）。"""
    global rescale_seq_counter
    with rescale_seq_lock:
        rescale_seq_counter += 1
        return rescale_seq_counter


def register_client(sock: socket.socket, addr: Tuple[str, int]) -> None:
    with active_clients_lock:
        active_clients.append((sock, addr))
        logger.info(f"client 注册到广播列表 | {addr} | total={len(active_clients)}")


def unregister_client(sock: socket.socket) -> None:
    with active_clients_lock:
        before = len(active_clients)
        active_clients[:] = [(s, a) for (s, a) in active_clients if s is not sock]
        after = len(active_clients)
        logger.info(f"client 已从广播列表移除 | before={before}, after={after}")


def broadcast_prepare_rescale(rescale_seq: int,
                              reason: str,
                              decision: "ZeroTuneDecision",
                              old_job_id: Optional[str]) -> int:
    """
    向所有已连接的 Sink 广播 prepare_rescale 通知。
    Sink 收到后会把 rescale_seq 写入下一次 snapshotState 产生的 CSV 行。
    返回成功发送的客户端数。
    """
    msg = {
        "type": "prepare_rescale",
        "rescale_seq": rescale_seq,
        "session_id": DAEMON_SESSION_ID,
        "reason": reason,
        "old_job_id": old_job_id or "",
        "current_parallelism": decision.current_parallelism,
        "target_parallelism": decision.candidate_parallelism,
        "true_rate_per_subtask": 0.0,  # ZeroTune 不使用此字段，保留兼容
        "avg_utilization": decision.predicted_gpu_utilization,
        "issued_at_ms": int(time.time() * 1000),
    }
    line = (json.dumps(msg) + "\n").encode("utf-8")

    with active_clients_lock:
        clients = list(active_clients)

    sent_ok = 0
    failed = 0
    with broadcast_send_lock:
        for sock, addr in clients:
            try:
                sock.sendall(line)
                sent_ok += 1
                logger.info(f"已广播 prepare_rescale 给 {addr} | seq={rescale_seq}")
            except Exception as e:
                failed += 1
                logger.warning(f"广播 prepare_rescale 给 {addr} 失败: {e}")
    logger.info(
        f"prepare_rescale 广播完成 | seq={rescale_seq} | "
        f"sent_ok={sent_ok} | failed={failed} | total_clients={len(clients)}"
    )
    return sent_ok


# ============================================================================
# DecisionLogger —— 详细的人类可读决策日志
# ============================================================================
class DecisionLogger:
    SYNC_INTERVAL_S = 15.0

    def __init__(self) -> None:
        self.local_path: Optional[str] = None
        self.hdfs_path: Optional[str]  = None
        self.lock                      = threading.Lock()
        self.enabled: bool             = False
        self.hdfs_enabled: bool        = True
        self.pending_changes: bool     = False
        self.entry_seq: int            = 0
        self.model_name: str           = ""

    def init(self, model_name: str) -> None:
        self.model_name = model_name or "unknown_model"
        local_dir = "/tmp/zerotune_daemon_logs"
        os.makedirs(local_dir, exist_ok=True)
        self.local_path = os.path.join(local_dir, f"monitor_{DAEMON_START_ISO}.log")
        self.hdfs_path = (
            f"{HDFS_NAMENODE}{HDFS_SINK_BASE}/{self.model_name}/collector/"
            f"monitor_{DAEMON_START_ISO}.log"
        )

        header = (
            "=" * 80 + "\n"
            f"ZeroTune Monitor Decision Log\n"
            f"Daemon Start Time: {datetime.fromtimestamp(DAEMON_START_TIME_TS).isoformat()}\n"
            f"Session ID: {DAEMON_SESSION_ID}\n"
            f"Model: {self.model_name}\n"
            f"ZeroTune Params: COOLDOWN={ZT_COOLDOWN_SECONDS}s, "
            f"MIN_WINDOWS={ZT_MIN_HISTORY_WINDOWS}, "
            f"ARRIVAL_WINDOW={ZT_ARRIVAL_RATE_WINDOW}, "
            f"SLO_MARGIN={ZT_SLO_SAFETY_MARGIN}, "
            f"COST_METRIC={ZT_COST_METRIC}, "
            f"P_RANGE=[{MIN_PARALLELISM},{MAX_PARALLELISM}], "
            f"B_VALUES={BATCH_SIZE_VALUES}\n"
            f"Local Log: {self.local_path}\n"
            f"HDFS  Log: {self.hdfs_path}\n"
            + "=" * 80 + "\n\n"
        )
        try:
            with open(self.local_path, "w", encoding="utf-8") as f:
                f.write(header)
            self.enabled = True
        except Exception as e:
            logger.error(f"DecisionLogger 初始化本地文件失败: {e}")
            return

        self._sync_to_hdfs(force=True)
        threading.Thread(target=self._sync_loop, name="decision-log-sync", daemon=True).start()
        logger.info(f"DecisionLogger 已启用 | local={self.local_path} | hdfs={self.hdfs_path}")

    def event(self, event_type: str, lines: Optional[List[str]] = None) -> None:
        if not self.enabled or self.local_path is None:
            return
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        with self.lock:
            self.entry_seq += 1
            seq = self.entry_seq
            try:
                with open(self.local_path, "a", encoding="utf-8") as f:
                    f.write(f"[{ts}] #{seq:05d} {event_type}\n")
                    if lines:
                        for line in lines:
                            f.write(f"    {line}\n")
                    f.write("\n")
                    f.flush()
                self.pending_changes = True
            except Exception as e:
                logger.error(f"DecisionLogger 写入失败: {e}")

    def force_sync(self) -> None:
        if self.enabled:
            self._sync_to_hdfs(force=True)

    def _sync_to_hdfs(self, force: bool = False) -> None:
        if not self.enabled or not self.hdfs_enabled \
                or self.local_path is None or self.hdfs_path is None:
            return
        if not force and not self.pending_changes:
            return
        with self.lock:
            self.pending_changes = False
        try:
            parent_dir = self.hdfs_path.rsplit("/", 1)[0]
            mk = subprocess.run(
                ["hadoop", "fs", "-mkdir", "-p", parent_dir],
                capture_output=True, timeout=30,
            )
            if mk.returncode != 0:
                logger.warning(
                    f"hadoop fs -mkdir 失败: rc={mk.returncode}, "
                    f"stderr={mk.stderr.decode('utf-8', errors='ignore')[:300]}"
                )
            cp = subprocess.run(
                ["hadoop", "fs", "-copyFromLocal", "-f", self.local_path, self.hdfs_path],
                capture_output=True, timeout=120,
            )
            if cp.returncode != 0:
                logger.warning(
                    f"hadoop fs -copyFromLocal 失败: rc={cp.returncode}, "
                    f"stderr={cp.stderr.decode('utf-8', errors='ignore')[:300]}"
                )
            else:
                logger.debug(f"决策日志已同步到 HDFS: {self.hdfs_path}")
        except FileNotFoundError:
            logger.warning(
                "未找到 hadoop CLI，决策日志仅保存在本地（后续不再尝试同步 HDFS）"
            )
            self.hdfs_enabled = False
        except subprocess.TimeoutExpired:
            logger.warning("hadoop fs 命令超时")
        except Exception as e:
            logger.warning(f"同步决策日志到 HDFS 异常: {e}")

    def _sync_loop(self) -> None:
        while True:
            time.sleep(self.SYNC_INTERVAL_S)
            if not self.enabled or not self.hdfs_enabled:
                continue
            try:
                self._sync_to_hdfs(force=False)
            except Exception as e:
                logger.warning(f"DecisionLogger 同步循环异常: {e}")


decision_logger = DecisionLogger()


# ============================================================================
# RescaleEventLogger —— 结构化 CSV，便于后续分析
# ============================================================================
class RescaleEventLogger:
    """
    把每次 rescale 相关事件以 CSV 行追加写入本地文件，并同步到 HDFS。
    每写一行立即触发一次 HDFS 覆盖上传。
    """

    HEADER = [
        # ── DS2 兼容列（保持不变，便于跨算法对比） ──
        "event_seq",
        "event_time_iso",
        "event_time_ms",
        "session_id",
        "rescale_seq",
        "model",
        "event_type",
        "old_job_id",
        "new_job_id",
        "old_parallelism",
        "new_parallelism",
        "batch_size",
        "reason",
        "true_rate_per_subtask",    # ZeroTune 不使用，填 0
        "avg_utilization",          # ZeroTune 不使用，填 0
        "observed_throughput",      # ZeroTune 不使用，填 0
        "source_rate",              # ZeroTune 不使用，填 0
        "base_target_rate",         # ZeroTune 不使用，填 0
        "effective_target_rate",    # ZeroTune 不使用，填 0
        "raw_optimal",              # ZeroTune 不使用，填 0
        "diff_ratio",
        "overload_detected",        # ZeroTune 不使用，填 false
        "windows_used",
        "total_records",
        "total_busy_ms",
        "total_duration_ms",
        "rescale_status",
        "rescale_elapsed_ms",
        "stop_savepoint_ms",
        "state_recovery_ms",
        "broadcast_clients_ok",
        "error_msg",
        # ── ZeroTune 特有列（追加在末尾） ──
        "zt_arrival_rate",              # 到达率估计
        "zt_predicted_latency_ms",      # 预测延迟
        "zt_predicted_throughput_rps",  # 预测吞吐
        "zt_predicted_gpu_util",        # 预测 GPU 利用率
        "zt_predicted_cost",            # 预测成本 (gpu_util × p)
        "zt_slo_satisfied",             # 是否满足 SLO 约束
        "zt_queue_stable",              # 是否满足队列稳定性约束
        "zt_num_candidates_evaluated",  # 评估的候选配置数
        "zt_num_candidates_slo_ok",     # 满足 SLO 的候选数
        "zt_num_candidates_queue_ok",   # 满足队列稳定的候选数
        "zt_num_candidates_both_ok",    # 同时满足两个约束的候选数
    ]

    def __init__(self) -> None:
        self.local_path: Optional[str] = None
        self.hdfs_path: Optional[str]  = None
        self.lock                      = threading.Lock()
        self.enabled: bool             = False
        self.hdfs_enabled: bool        = True
        self.event_seq: int            = 0
        self.model_name: str           = ""

    def init(self, model_name: str) -> None:
        self.model_name = model_name or "unknown_model"
        local_dir = "/tmp/zerotune_daemon_logs"
        os.makedirs(local_dir, exist_ok=True)
        self.local_path = os.path.join(
            local_dir, f"rescale_events_{DAEMON_START_ISO}.csv"
        )
        self.hdfs_path = (
            f"{HDFS_NAMENODE}{HDFS_SINK_BASE}/{self.model_name}/collector/"
            f"rescale_events_{DAEMON_START_ISO}.csv"
        )
        try:
            with open(self.local_path, "w", encoding="utf-8", newline="") as f:
                w = csv.writer(f)
                w.writerow(self.HEADER)
            self.enabled = True
            logger.info(
                f"RescaleEventLogger 已启用 | local={self.local_path} | hdfs={self.hdfs_path}"
            )
            self._sync_to_hdfs()
        except Exception as e:
            logger.error(f"RescaleEventLogger 初始化失败: {e}")
            self.enabled = False

    def log(self, event_type: str, fields: Optional[Dict[str, Any]] = None) -> None:
        """追加一条事件并立刻同步到 HDFS。"""
        if not self.enabled or self.local_path is None:
            return

        now_ms = int(time.time() * 1000)
        now_iso = datetime.fromtimestamp(now_ms / 1000.0).strftime(
            "%Y-%m-%dT%H:%M:%S.%f"
        )[:-3]

        with self.lock:
            self.event_seq += 1
            row_dict: Dict[str, Any] = {
                "event_seq": self.event_seq,
                "event_time_iso": now_iso,
                "event_time_ms": now_ms,
                "session_id": DAEMON_SESSION_ID,
                "model": self.model_name,
                "event_type": event_type,
            }
            if fields:
                row_dict.update(fields)

            row = [self._fmt(row_dict.get(col, "")) for col in self.HEADER]

            try:
                with open(self.local_path, "a", encoding="utf-8", newline="") as f:
                    w = csv.writer(f)
                    w.writerow(row)
                    f.flush()
            except Exception as e:
                logger.error(f"RescaleEventLogger 写入本地失败: {e}")
                return

        self._sync_to_hdfs()

    @staticmethod
    def _fmt(v: Any) -> str:
        if v is None:
            return ""
        if isinstance(v, bool):
            return "true" if v else "false"
        if isinstance(v, float):
            if math.isnan(v) or math.isinf(v):
                return ""
            return f"{v:.6f}"
        if isinstance(v, str):
            return v.replace("\n", " | ").replace("\r", " ")
        return str(v)

    def _sync_to_hdfs(self) -> None:
        if not self.enabled or not self.hdfs_enabled \
                or self.local_path is None or self.hdfs_path is None:
            return
        try:
            parent_dir = self.hdfs_path.rsplit("/", 1)[0]
            mk = subprocess.run(
                ["hadoop", "fs", "-mkdir", "-p", parent_dir],
                capture_output=True, timeout=30,
            )
            if mk.returncode != 0:
                logger.warning(
                    f"[rescale-events] hadoop fs -mkdir 失败: rc={mk.returncode}, "
                    f"stderr={mk.stderr.decode('utf-8', errors='ignore')[:300]}"
                )
            cp = subprocess.run(
                ["hadoop", "fs", "-copyFromLocal", "-f",
                 self.local_path, self.hdfs_path],
                capture_output=True, timeout=120,
            )
            if cp.returncode != 0:
                logger.warning(
                    f"[rescale-events] hadoop fs -copyFromLocal 失败: rc={cp.returncode}, "
                    f"stderr={cp.stderr.decode('utf-8', errors='ignore')[:300]}"
                )
            else:
                logger.debug(f"[rescale-events] 已同步到 HDFS: {self.hdfs_path}")
        except FileNotFoundError:
            logger.warning(
                "未找到 hadoop CLI，rescale 事件 CSV 仅保存本地（后续不再尝试同步 HDFS）"
            )
            self.hdfs_enabled = False
        except subprocess.TimeoutExpired:
            logger.warning("[rescale-events] hadoop fs 命令超时")
        except Exception as e:
            logger.warning(f"[rescale-events] 同步到 HDFS 异常: {e}")


rescale_event_logger = RescaleEventLogger()


# ─── 数据模型 ──────────────────────────────────────────────────────────────
@dataclass
class DS2MetricsPayload:
    """
    从 Java Sink 接收的指标数据。与 DS2 daemon 保持完全一致的字段，
    确保 TCP 协议兼容。
    """
    nodeIp: str
    windowStartTimestamp: int
    windowEndTimestamp: int
    windowDurationMs: int
    recordsProcessed: int
    totalBusyTimeMs: int
    observedThroughput: float
    sourceEmissionRate: float
    currentParallelism: int
    currentBatchSize: int

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "DS2MetricsPayload":
        return DS2MetricsPayload(
            nodeIp                = d.get("nodeIp", ""),
            windowStartTimestamp  = d.get("windowStartTimestamp", 0),
            windowEndTimestamp    = d.get("windowEndTimestamp", 0),
            windowDurationMs      = d.get("windowDurationMs", 0),
            recordsProcessed      = d.get("recordsProcessed", 0),
            totalBusyTimeMs       = d.get("totalBusyTimeMs", 0),
            observedThroughput    = d.get("observedThroughput", 0.0),
            sourceEmissionRate    = d.get("sourceEmissionRate", 0.0),
            currentParallelism    = d.get("currentParallelism", 0),
            currentBatchSize      = d.get("currentBatchSize", 0),
        )


# ─── Job ID 管理 ───────────────────────────────────────────────────────────
def get_current_job_id() -> Optional[str]:
    with job_id_lock:
        return current_job_id


def set_current_job_id(job_id: Optional[str]) -> None:
    global current_job_id
    with job_id_lock:
        current_job_id = job_id
    logger.info(f"当前 Flink Job ID 已更新为: {job_id}")


def get_running_job_id_from_rest() -> Optional[str]:
    url = f"{FLINK_REST}/jobs"
    try:
        with urllib.request.urlopen(url, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        running = [j for j in data.get("jobs", []) if j.get("status") == "RUNNING"]
        if not running:
            logger.warning("未发现 RUNNING Job")
            return None
        if len(running) > 1:
            logger.warning(f"发现 {len(running)} 个 RUNNING Job，取第一个: {running[0]['id']}")
        return running[0]["id"]
    except Exception as e:
        logger.error(f"查询 Flink REST API 失败: {e}")
        return None


def is_job_running(job_id: str) -> bool:
    """检查指定 job 是否还处于 RUNNING。"""
    if not job_id:
        return False
    url = f"{FLINK_REST}/jobs/{job_id}"
    try:
        with urllib.request.urlopen(url, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return data.get("state") == "RUNNING"
    except Exception as e:
        logger.warning(f"查询 job {job_id} 状态失败: {e}")
        return False


# ─── 看门狗 ────────────────────────────────────────────────────────────────
def update_heartbeat() -> None:
    global last_recv_time
    with heartbeat_lock:
        last_recv_time = time.time()


def watchdog() -> None:
    while True:
        time.sleep(WATCHDOG_CHECK_INTERVAL)
        if is_reconfiguring:
            update_heartbeat()
            continue
        with heartbeat_lock:
            idle = time.time() - last_recv_time
        if idle > TIMEOUT_SECONDS:
            logger.error(f"看门狗触发：已 {idle:.0f}s 未收到数据，Daemon 退出")
            decision_logger.event(
                "DAEMON_EXIT_BY_WATCHDOG",
                [f"idle_seconds={idle:.1f}", f"timeout={TIMEOUT_SECONDS}s"],
            )
            decision_logger.force_sync()
            os._exit(0)


# ============================================================================
# ZeroTune 预测器加载
# ============================================================================
def load_zerotune_models(model_dir: str) -> bool:
    """
    加载预训练的 ZeroTune 性能预测器模型。

    从 model_dir 读取三个 joblib 文件和一个元数据 JSON。
    成功加载后设置全局 zt_predictors 和 zt_models_loaded。

    返回: True 表示全部模型加载成功，False 表示失败。
    """
    global zt_predictors, zt_model_metadata, zt_models_loaded

    model_files = {
        "latency":    os.path.join(model_dir, ZT_MODEL_LATENCY),
        "throughput": os.path.join(model_dir, ZT_MODEL_THROUGHPUT),
        "gpu":        os.path.join(model_dir, ZT_MODEL_GPU),
    }
    meta_file = os.path.join(model_dir, ZT_MODEL_METADATA)

    # 检查文件是否存在
    for name, fpath in model_files.items():
        if not os.path.isfile(fpath):
            logger.error(f"ZeroTune 模型文件不存在: {fpath}")
            return False

    # 加载模型
    try:
        for name, fpath in model_files.items():
            zt_predictors[name] = joblib.load(fpath)
            logger.info(f"已加载 ZeroTune 模型 [{name}]: {fpath}")
    except Exception as e:
        logger.error(f"加载 ZeroTune 模型失败: {e}", exc_info=True)
        return False

    # 加载元数据（可选，失败不影响运行）
    if os.path.isfile(meta_file):
        try:
            with open(meta_file, "r", encoding="utf-8") as f:
                zt_model_metadata = json.load(f)
            logger.info(f"已加载 ZeroTune 模型元数据: {meta_file}")
            logger.info(f"  训练时间: {zt_model_metadata.get('training_time', 'N/A')}")
            logger.info(f"  训练样本数: {zt_model_metadata.get('num_training_samples', 'N/A')}")
        except Exception as e:
            logger.warning(f"加载 ZeroTune 模型元数据失败（不影响运行）: {e}")

    zt_models_loaded = True
    logger.info("ZeroTune 预测器全部加载成功")
    return True


# ============================================================================
# ZeroTune 核心决策算法
# ============================================================================
def compute_zerotune_decision(history: List[DS2MetricsPayload]) -> Optional[ZeroTuneDecision]:
    """
    ZeroTune 在线决策算法。

    核心流程（忠实于论文 Section IV-B, V-B）：
        1. 估计当前到达率（arrival rate）
        2. 利用预训练预测器评估当前 batch_size 下的所有候选并行度配置
        3. 在满足 SLO 和队列稳定性约束的配置中，选择成本最低者
        4. 若无配置满足约束，则选择延迟最低者（尽力满足 SLO）

    返回: ZeroTuneDecision 或 None（跳过决策）
    """
    # ── 守卫条件 ──
    if not history:
        logger.debug("ZeroTune: 无历史数据")
        decision_logger.event("DECISION_SKIPPED", ["reason=no_history"])
        return None

    if len(history) < ZT_MIN_HISTORY_WINDOWS:
        msg = f"len(history)={len(history)} < MIN_WINDOWS={ZT_MIN_HISTORY_WINDOWS}"
        logger.debug(f"ZeroTune: 历史窗口不足（{msg}），跳过")
        decision_logger.event("DECISION_SKIPPED",
                              ["reason=insufficient_windows", msg])
        return None

    if not zt_models_loaded:
        logger.warning("ZeroTune: 预测器模型未加载，跳过决策")
        decision_logger.event("DECISION_SKIPPED",
                              ["reason=models_not_loaded"])
        return None

    # ── 聚合指标（用于日志和诊断） ──
    total_records      = sum(p.recordsProcessed for p in history)
    total_busy_time_ms = sum(p.totalBusyTimeMs for p in history)
    total_duration_ms  = sum(p.windowDurationMs for p in history)

    if total_records <= 0 or total_busy_time_ms <= 0 or total_duration_ms <= 0:
        logger.debug("ZeroTune: 关键指标为 0，跳过")
        decision_logger.event(
            "DECISION_SKIPPED",
            [
                "reason=zero_metrics",
                f"total_records={total_records}",
                f"total_busy_ms={total_busy_time_ms}",
                f"total_duration_ms={total_duration_ms}",
            ],
        )
        return None

    current_parallelism = history[-1].currentParallelism
    current_batch_size  = history[-1].currentBatchSize

    if current_parallelism <= 0:
        logger.warning("ZeroTune: currentParallelism <= 0，跳过")
        decision_logger.event(
            "DECISION_SKIPPED",
            ["reason=invalid_parallelism", f"current_parallelism={current_parallelism}"],
        )
        return None

    if current_batch_size <= 0:
        logger.warning("ZeroTune: currentBatchSize <= 0，跳过")
        decision_logger.event(
            "DECISION_SKIPPED",
            ["reason=invalid_batch_size", f"current_batch_size={current_batch_size}"],
        )
        return None

    # ── 步骤 1：估计到达率 ──
    # 取最近 ZT_ARRIVAL_RATE_WINDOW 个窗口中 sourceEmissionRate > 0 的均值
    recent = history[-ZT_ARRIVAL_RATE_WINDOW:]
    source_rates = [p.sourceEmissionRate for p in recent if p.sourceEmissionRate > 0]
    if source_rates:
        arrival_rate = sum(source_rates) / len(source_rates)
    else:
        # 回退：使用最新窗口的观测吞吐率
        arrival_rate = history[-1].observedThroughput
        if arrival_rate <= 0:
            logger.warning("ZeroTune: 无法估计到达率（source_rate 和 throughput 均为 0），跳过")
            decision_logger.event("DECISION_SKIPPED",
                                  ["reason=no_arrival_rate"])
            return None

    # ── 步骤 2：评估候选配置 ──
    # 仅评估当前 batch_size 下的 4 个并行度配置（因为 rescale.sh 只能改并行度）
    candidates: List[Dict[str, Any]] = []
    slo_threshold = runtime_slo_ms * ZT_SLO_SAFETY_MARGIN

    for p in PARALLELISM_VALUES:
        # 构造特征向量：[parallelism, batch_size, arrival_rate]
        features = np.array([[p, current_batch_size, arrival_rate]])

        # 预测
        pred_latency    = float(zt_predictors["latency"].predict(features)[0])
        pred_throughput = float(zt_predictors["throughput"].predict(features)[0])
        pred_gpu        = float(zt_predictors["gpu"].predict(features)[0])

        # 钳位到合理范围
        pred_latency    = max(pred_latency, 0.0)
        pred_throughput = max(pred_throughput, 0.0)
        pred_gpu        = max(min(pred_gpu, 1.0), 0.0)

        # 约束评估
        # SLO 约束：预测延迟 ≤ SLO × 安全裕度
        slo_ok = pred_latency <= slo_threshold

        # 队列稳定性约束：预测吞吐率 ≥ 到达率
        # （服务速率必须 >= 到达速率，否则队列会无限增长）
        queue_ok = pred_throughput >= arrival_rate

        # 成本：gpu_utilization × parallelism
        cost = pred_gpu * p

        candidates.append({
            "parallelism": p,
            "batch_size": current_batch_size,
            "pred_latency": pred_latency,
            "pred_throughput": pred_throughput,
            "pred_gpu": pred_gpu,
            "slo_ok": slo_ok,
            "queue_ok": queue_ok,
            "cost": cost,
            "both_ok": slo_ok and queue_ok,
        })

    # ── 步骤 3：选择最优配置 ──
    # 优先级：同时满足两个约束 > 仅满足 SLO > 仅满足队列稳定 > 最低延迟
    feasible = [c for c in candidates if c["both_ok"]]

    if feasible:
        # 在可行解中选择成本最低者
        best = min(feasible, key=lambda c: c["cost"])
        logger.info(f"ZeroTune: 从 {len(feasible)} 个可行配置中选择成本最低者")
    else:
        slo_only = [c for c in candidates if c["slo_ok"]]
        if slo_only:
            best = min(slo_only, key=lambda c: c["cost"])
            logger.warning(
                f"ZeroTune: 无配置同时满足 SLO+队列稳定，"
                f"选择满足 SLO 的最低成本配置 (p={best['parallelism']})"
            )
        else:
            # 没有任何配置满足 SLO，选择预测延迟最低者
            best = min(candidates, key=lambda c: c["pred_latency"])
            logger.warning(
                f"ZeroTune: 无配置满足 SLO，选择预测延迟最低的配置 (p={best['parallelism']})"
            )

    # ── 构造决策结果 ──
    decision = ZeroTuneDecision(
        candidate_parallelism   = best["parallelism"],
        candidate_batch_size    = best["batch_size"],
        predicted_latency_ms    = best["pred_latency"],
        predicted_throughput_rps = best["pred_throughput"],
        predicted_gpu_utilization = best["pred_gpu"],
        slo_satisfied           = best["slo_ok"],
        queue_stable            = best["queue_ok"],
        predicted_cost          = best["cost"],
        arrival_rate_used       = arrival_rate,
        current_parallelism     = current_parallelism,
        current_batch_size      = current_batch_size,
        num_candidates_evaluated = len(candidates),
        num_candidates_slo_ok   = sum(1 for c in candidates if c["slo_ok"]),
        num_candidates_queue_ok = sum(1 for c in candidates if c["queue_ok"]),
        num_candidates_both_ok  = len(feasible),
        all_candidates_detail   = candidates,
    )

    # ── 日志输出 ──
    logger.info(
        f"ZeroTune 决策 | arrival_rate={arrival_rate:.4f} req/s | "
        f"pred_latency={best['pred_latency']:.1f}ms | "
        f"pred_throughput={best['pred_throughput']:.4f} req/s | "
        f"pred_gpu={best['pred_gpu']:.4f} | "
        f"cost={best['cost']:.4f} | "
        f"slo_ok={best['slo_ok']} | queue_ok={best['queue_ok']} | "
        f"current_p={current_parallelism} → optimal_p={best['parallelism']} | "
        f"batch_size={current_batch_size}"
    )

    decision_logger.event(
        "DECISION_COMPUTED",
        [
            f"arrival_rate={arrival_rate:.4f} req/s",
            f"slo_threshold={slo_threshold:.1f}ms  (SLO={runtime_slo_ms}ms × {ZT_SLO_SAFETY_MARGIN})",
            f"current_p={current_parallelism}, current_b={current_batch_size}",
            f"optimal_p={best['parallelism']}, optimal_b={best['batch_size']}",
            f"predicted_latency={best['pred_latency']:.1f}ms",
            f"predicted_throughput={best['pred_throughput']:.4f} req/s",
            f"predicted_gpu={best['pred_gpu']:.4f}",
            f"predicted_cost={best['cost']:.4f}",
            f"slo_satisfied={best['slo_ok']}",
            f"queue_stable={best['queue_ok']}",
            f"candidates_evaluated={len(candidates)}",
            f"candidates_slo_ok={sum(1 for c in candidates if c['slo_ok'])}",
            f"candidates_queue_ok={sum(1 for c in candidates if c['queue_ok'])}",
            f"candidates_both_ok={len(feasible)}",
            # 所有候选的简要评估
            *[f"candidate_p={c['parallelism']}: "
              f"lat={c['pred_latency']:.1f}, thr={c['pred_throughput']:.4f}, "
              f"gpu={c['pred_gpu']:.4f}, cost={c['cost']:.4f}, "
              f"slo={'Y' if c['slo_ok'] else 'N'}, q={'Y' if c['queue_ok'] else 'N'}"
              for c in candidates],
        ],
    )
    return decision


def should_trigger_rescale(decision: ZeroTuneDecision) -> bool:
    """
    判断是否应该触发重配置。

    条件（全部满足才触发）：
        1. 冷却期已过（ZT_COOLDOWN_SECONDS）
        2. 目标并行度与当前并行度不同
    """
    elapsed_since_last = time.time() - last_reconfig_time
    if elapsed_since_last < ZT_COOLDOWN_SECONDS:
        logger.info(
            f"ZeroTune: 冷却中（{elapsed_since_last:.1f}s < {ZT_COOLDOWN_SECONDS}s），跳过"
        )
        decision_logger.event(
            "RESCALE_SKIPPED",
            [
                "reason=cooldown",
                f"elapsed_since_last={elapsed_since_last:.1f}s",
                f"cooldown={ZT_COOLDOWN_SECONDS}s",
                f"current_p={decision.current_parallelism}",
                f"optimal_p={decision.candidate_parallelism}",
            ],
        )
        return False

    if decision.candidate_parallelism == decision.current_parallelism:
        logger.info("ZeroTune: optimal == current，无需 rescale")
        decision_logger.event(
            "RESCALE_SKIPPED",
            [
                "reason=optimal_equals_current",
                f"current_p={decision.current_parallelism}",
                f"optimal_p={decision.candidate_parallelism}",
            ],
        )
        return False

    logger.info(
        f"ZeroTune: 触发 rescale | {decision.current_parallelism} → "
        f"{decision.candidate_parallelism}"
    )
    decision_logger.event(
        "RESCALE_DECISION",
        [
            "decision=TRIGGER",
            f"current_p={decision.current_parallelism}",
            f"optimal_p={decision.candidate_parallelism}",
            f"arrival_rate={decision.arrival_rate_used:.4f} req/s",
            f"predicted_latency={decision.predicted_latency_ms:.1f}ms",
            f"predicted_throughput={decision.predicted_throughput_rps:.4f} req/s",
            f"predicted_gpu={decision.predicted_gpu_utilization:.4f}",
            f"predicted_cost={decision.predicted_cost:.4f}",
            f"slo_satisfied={decision.slo_satisfied}",
            f"queue_stable={decision.queue_stable}",
        ],
    )
    return True


# ─── 重配置流程 ───────────────────────────────────────────────────────────
def trigger_reconfiguration(
    history: List[DS2MetricsPayload],
    decision: ZeroTuneDecision,
    model_name: str,
) -> None:
    """
    完整的重配置流程（在独立线程中运行）。

    流程与 DS2 daemon 保持一致：
        1. 获取重配置锁
        2. 预检查（脚本路径、Job ID、Job 状态）
        3. 分配 rescale_seq 并广播 prepare_rescale
        4. 调用 rescale.sh
        5. 解析新 Job ID 和耗时
        6. 记录日志
        7. 失败时刷新 Job ID
    """
    global is_reconfiguring, last_reconfig_time

    if not reconfiguration_lock.acquire(blocking=False):
        logger.warning("重配置正在进行中，忽略本次触发")
        decision_logger.event("RESCALE_SKIPPED", ["reason=already_reconfiguring"])
        return

    rescale_succeeded = False
    old_job_id_for_refresh: Optional[str] = None
    new_job_id: Optional[str] = None
    rescale_seq: int = 0
    broadcast_clients_ok: int = 0

    latest = history[-1]
    new_parallelism = decision.candidate_parallelism
    keep_batchsize  = latest.currentBatchSize  # batch_size 保持不变

    # 公共字段：用于所有 rescale 事件 CSV 行
    base_event_fields: Dict[str, Any] = {
        "old_parallelism": decision.current_parallelism,
        "new_parallelism": new_parallelism,
        "batch_size": keep_batchsize,
        # DS2 兼容字段（填 0 或默认值）
        "true_rate_per_subtask": 0.0,
        "avg_utilization": 0.0,
        "observed_throughput": 0.0,
        "source_rate": 0.0,
        "base_target_rate": 0.0,
        "effective_target_rate": 0.0,
        "raw_optimal": float(new_parallelism),
        "diff_ratio": (
            abs(new_parallelism - decision.current_parallelism) / decision.current_parallelism
            if decision.current_parallelism > 0 else 0.0
        ),
        "overload_detected": False,
        "windows_used": len(history),
        "total_records": sum(p.recordsProcessed for p in history),
        "total_busy_ms": sum(p.totalBusyTimeMs for p in history),
        "total_duration_ms": sum(p.windowDurationMs for p in history),
        # ZeroTune 特有字段
        "zt_arrival_rate": decision.arrival_rate_used,
        "zt_predicted_latency_ms": decision.predicted_latency_ms,
        "zt_predicted_throughput_rps": decision.predicted_throughput_rps,
        "zt_predicted_gpu_util": decision.predicted_gpu_utilization,
        "zt_predicted_cost": decision.predicted_cost,
        "zt_slo_satisfied": decision.slo_satisfied,
        "zt_queue_stable": decision.queue_stable,
        "zt_num_candidates_evaluated": decision.num_candidates_evaluated,
        "zt_num_candidates_slo_ok": decision.num_candidates_slo_ok,
        "zt_num_candidates_queue_ok": decision.num_candidates_queue_ok,
        "zt_num_candidates_both_ok": decision.num_candidates_both_ok,
    }

    try:
        is_reconfiguring = True

        logger.info("=" * 60)
        logger.info("ZeroTune 重配置流程启动")
        logger.info(f"  当前并行度: {decision.current_parallelism}")
        logger.info(f"  目标并行度: {new_parallelism}")
        logger.info(f"  批次大小:   {keep_batchsize}（保持不变）")
        logger.info(f"  预测延迟:   {decision.predicted_latency_ms:.1f}ms")
        logger.info(f"  预测吞吐:   {decision.predicted_throughput_rps:.4f} req/s")
        logger.info(f"  预测GPU:    {decision.predicted_gpu_utilization:.4f}")
        logger.info(f"  预测成本:   {decision.predicted_cost:.4f}")
        logger.info("=" * 60)

        # ========= 预检查 =========
        if not RESCALE_SCRIPT_PATH or not os.path.isfile(RESCALE_SCRIPT_PATH):
            logger.error(f"RESCALE_SCRIPT_PATH 无效: {RESCALE_SCRIPT_PATH}")
            decision_logger.event(
                "RESCALE_FAILED",
                ["stage=pre_check", f"reason=invalid_script_path:{RESCALE_SCRIPT_PATH}"],
            )
            rescale_event_logger.log("RESCALE_FAILED", {
                **base_event_fields,
                "rescale_seq": "",
                "old_job_id": get_current_job_id() or "",
                "reason": "invalid_script_path",
                "rescale_status": "PRECHECK_FAIL",
                "error_msg": f"invalid script path: {RESCALE_SCRIPT_PATH}",
            })
            return

        old_job_id = get_current_job_id()
        if not old_job_id:
            old_job_id = get_running_job_id_from_rest()
            if old_job_id:
                set_current_job_id(old_job_id)
        if not old_job_id:
            logger.error("无法获取当前 Job ID，重配置中止")
            decision_logger.event(
                "RESCALE_FAILED",
                ["stage=get_job_id", "reason=no_running_job_id"],
            )
            rescale_event_logger.log("RESCALE_FAILED", {
                **base_event_fields,
                "rescale_seq": "",
                "old_job_id": "",
                "reason": "no_running_job_id",
                "rescale_status": "PRECHECK_FAIL",
                "error_msg": "no running job id",
            })
            return

        if not is_job_running(old_job_id):
            logger.warning(
                f"Job {old_job_id} 不再处于 RUNNING 状态，刷新 job_id 后重试本次决策"
            )
            decision_logger.event(
                "RESCALE_FAILED",
                ["stage=pre_check", f"reason=job_not_running:{old_job_id}"],
            )
            rescale_event_logger.log("RESCALE_FAILED", {
                **base_event_fields,
                "rescale_seq": "",
                "old_job_id": old_job_id,
                "reason": "job_not_running",
                "rescale_status": "PRECHECK_FAIL",
                "error_msg": f"job {old_job_id} not running",
            })
            old_job_id_for_refresh = old_job_id
            return

        old_job_id_for_refresh = old_job_id

        # ========= 分配 rescale_seq 并广播 prepare_rescale =========
        rescale_seq = next_rescale_seq()
        broadcast_clients_ok = broadcast_prepare_rescale(
            rescale_seq=rescale_seq,
            reason="zerotune_decision",
            decision=decision,
            old_job_id=old_job_id,
        )
        time.sleep(0.3)

        decision_logger.event(
            "RESCALE_TRIGGERED",
            [
                f"rescale_seq={rescale_seq}",
                f"trigger_node_ip={latest.nodeIp}",
                f"current_p={decision.current_parallelism}",
                f"target_p={new_parallelism}",
                f"keep_batchsize={keep_batchsize}",
                f"arrival_rate={decision.arrival_rate_used:.4f} req/s",
                f"predicted_latency={decision.predicted_latency_ms:.1f}ms",
                f"predicted_throughput={decision.predicted_throughput_rps:.4f} req/s",
                f"predicted_gpu={decision.predicted_gpu_utilization:.4f}",
                f"current_job_id={old_job_id}",
                f"broadcast_clients_ok={broadcast_clients_ok}",
            ],
        )
        decision_logger.force_sync()

        reconfig_start = time.time()

        # ========= TRIGGERED 事件 =========
        rescale_event_logger.log("RESCALE_TRIGGERED", {
            **base_event_fields,
            "rescale_seq": rescale_seq,
            "old_job_id": old_job_id,
            "reason": "zerotune_decision",
            "rescale_status": "STARTED",
            "broadcast_clients_ok": broadcast_clients_ok,
        })

        # ========= 调用 rescale.sh =========
        cmd = [
            "bash", RESCALE_SCRIPT_PATH,
            "-j", old_job_id,
            "-p", str(new_parallelism),
            "-b", str(keep_batchsize),
            "-m", model_name,
            "-r", str(runtime_max_requests),
            "-i", str(runtime_base_interval),
            "-c", runtime_cache_type,
        ]
        if DEFAULT_JAR_PATH:
            cmd += ["-J", DEFAULT_JAR_PATH]

        logger.info(f"执行命令: {' '.join(cmd)}")
        decision_logger.event(
            "RESCALE_SCRIPT_INVOKED",
            [f"rescale_seq={rescale_seq}", f"old_job_id={old_job_id}", f"cmd={' '.join(cmd)}"],
        )

        stdout_lines: List[str] = []
        stderr_lines: List[str] = []
        proc_returncode: Optional[int] = None

        try:
            proc = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
            )
            assert proc.stdout is not None
            for line in proc.stdout:
                stripped = line.rstrip()
                stdout_lines.append(stripped)
                logger.info(f"[rescale.sh] {stripped}")

            try:
                proc.wait(timeout=RESCALE_SCRIPT_TIMEOUT)
                proc_returncode = proc.returncode
            except subprocess.TimeoutExpired:
                proc.kill()
                logger.error(f"rescale.sh 超时（{RESCALE_SCRIPT_TIMEOUT}s），已强杀")
                decision_logger.event(
                    "RESCALE_FAILED",
                    [
                        f"rescale_seq={rescale_seq}",
                        "stage=script_execution",
                        f"reason=timeout_{RESCALE_SCRIPT_TIMEOUT}s",
                    ],
                )
                rescale_event_logger.log("RESCALE_FAILED", {
                    **base_event_fields,
                    "rescale_seq": rescale_seq,
                    "old_job_id": old_job_id,
                    "reason": "script_timeout",
                    "rescale_status": "TIMEOUT",
                    "rescale_elapsed_ms": int((time.time() - reconfig_start) * 1000),
                    "broadcast_clients_ok": broadcast_clients_ok,
                    "error_msg": f"timeout_{RESCALE_SCRIPT_TIMEOUT}s",
                })
                return

            if proc.stderr:
                for line in proc.stderr:
                    stderr_lines.append(line.rstrip())

            if proc_returncode != 0:
                logger.error(
                    f"rescale.sh 失败 (rc={proc_returncode}): \n" + "\n".join(stderr_lines)
                )
                decision_logger.event(
                    "RESCALE_FAILED",
                    [
                        f"rescale_seq={rescale_seq}",
                        "stage=script_execution",
                        f"return_code={proc_returncode}",
                        "stderr_tail=" + " | ".join(stderr_lines[-5:])
                        if stderr_lines else "stderr=<empty>",
                    ],
                )
                rescale_event_logger.log("RESCALE_FAILED", {
                    **base_event_fields,
                    "rescale_seq": rescale_seq,
                    "old_job_id": old_job_id,
                    "reason": "script_nonzero_exit",
                    "rescale_status": f"EXIT_{proc_returncode}",
                    "rescale_elapsed_ms": int((time.time() - reconfig_start) * 1000),
                    "broadcast_clients_ok": broadcast_clients_ok,
                    "error_msg": " | ".join(stderr_lines[-5:]) or "<empty>",
                })
                return

        except FileNotFoundError:
            logger.error("未找到 bash 命令")
            decision_logger.event(
                "RESCALE_FAILED",
                [f"rescale_seq={rescale_seq}", "stage=script_execution", "reason=bash_not_found"],
            )
            rescale_event_logger.log("RESCALE_FAILED", {
                **base_event_fields,
                "rescale_seq": rescale_seq,
                "old_job_id": old_job_id,
                "reason": "bash_not_found",
                "rescale_status": "EXEC_ERROR",
                "broadcast_clients_ok": broadcast_clients_ok,
                "error_msg": "bash not found",
            })
            return
        except Exception as e:
            logger.error(f"调用 rescale.sh 异常: {e}", exc_info=True)
            decision_logger.event(
                "RESCALE_FAILED",
                [f"rescale_seq={rescale_seq}", "stage=script_execution",
                 f"exception={type(e).__name__}: {e}"],
            )
            rescale_event_logger.log("RESCALE_FAILED", {
                **base_event_fields,
                "rescale_seq": rescale_seq,
                "old_job_id": old_job_id,
                "reason": "script_exception",
                "rescale_status": "EXEC_ERROR",
                "broadcast_clients_ok": broadcast_clients_ok,
                "error_msg": f"{type(e).__name__}: {e}",
            })
            return

        # ========= 解析新 Job ID =========
        full_stdout = "\n".join(stdout_lines)
        match = re.search(r"New Job ID\s*:\s*([0-9a-fA-F]{32})", full_stdout)
        new_job_id = match.group(1) if match else None
        if new_job_id:
            set_current_job_id(new_job_id)
            logger.info(f"ZeroTune 重配置成功，新 Job ID: {new_job_id}")
        else:
            logger.warning("无法从 rescale.sh 输出解析新 Job ID")

        # ========= 解析耗时 =========
        stop_savepoint_ms, state_recovery_ms, timing_lines = _parse_rescale_timings(stdout_lines)

        for tl in timing_lines:
            logger.info(f"[rescale.sh 耗时] {tl}")

        if not stop_savepoint_ms or not state_recovery_ms:
            logger.warning(
                "rescale.sh 已成功 (rc=0)，但未从 stdout 解析到完整的 timing 行："
                f"stop_savepoint_ms='{stop_savepoint_ms}', "
                f"state_recovery_ms='{state_recovery_ms}', "
                f"timing_lines_count={len(timing_lines)}; "
                "请检查 rescale.sh 末尾的 echo 文案是否变化。"
            )

        elapsed = time.time() - reconfig_start
        logger.info(f"ZeroTune 重配置完成，总耗时 {elapsed:.1f}s")

        decision_logger.event(
            "RESCALE_SUCCESS",
            [
                f"rescale_seq={rescale_seq}",
                f"old_job_id={old_job_id}",
                f"new_job_id={new_job_id or 'UNKNOWN'}",
                f"new_parallelism={new_parallelism}",
                f"batchsize={keep_batchsize}",
                f"total_elapsed_s={elapsed:.2f}",
                f"parsed_stop_savepoint_ms={stop_savepoint_ms or 'UNKNOWN'}",
                f"parsed_state_recovery_ms={state_recovery_ms or 'UNKNOWN'}",
                *([f"timing: {t}" for t in timing_lines] if timing_lines else []),
            ],
        )

        rescale_event_logger.log("RESCALE_SUCCESS", {
            **base_event_fields,
            "rescale_seq": rescale_seq,
            "old_job_id": old_job_id,
            "new_job_id": new_job_id or "",
            "reason": "zerotune_decision",
            "rescale_status": "OK",
            "rescale_elapsed_ms": int(elapsed * 1000),
            "stop_savepoint_ms": stop_savepoint_ms,
            "state_recovery_ms": state_recovery_ms,
            "broadcast_clients_ok": broadcast_clients_ok,
        })

        update_heartbeat()
        decision_logger.force_sync()
        rescale_succeeded = True

    except Exception as e:
        logger.error(f"重配置流程未预期异常: {e}", exc_info=True)
        decision_logger.event(
            "RESCALE_FAILED",
            [f"rescale_seq={rescale_seq}", "stage=outer_handler",
             f"exception={type(e).__name__}: {e}"],
        )
        try:
            rescale_event_logger.log("RESCALE_FAILED", {
                **base_event_fields,
                "rescale_seq": rescale_seq if rescale_seq > 0 else "",
                "old_job_id": old_job_id_for_refresh or get_current_job_id() or "",
                "reason": "outer_exception",
                "rescale_status": "EXCEPTION",
                "broadcast_clients_ok": broadcast_clients_ok,
                "error_msg": f"{type(e).__name__}: {e}",
            })
        except Exception:
            pass
    finally:
        last_reconfig_time = time.time()
        is_reconfiguring = False
        reconfiguration_lock.release()

        if not rescale_succeeded:
            try:
                old_id = old_job_id_for_refresh or get_current_job_id()
                set_current_job_id(None)
                discovered = get_running_job_id_from_rest()
                if discovered:
                    set_current_job_id(discovered)
                    logger.warning(
                        f"rescale 失败后已重新发现 RUNNING job: {discovered} (was {old_id})"
                    )
                    decision_logger.event(
                        "JOB_ID_REFRESHED_AFTER_FAILURE",
                        [f"old_job_id={old_id}", f"new_job_id={discovered}"],
                    )
                else:
                    logger.warning(
                        f"rescale 失败后未发现任何 RUNNING job (was {old_id})；"
                        f"将等待 {ZT_COOLDOWN_SECONDS:.0f}s 后再决策"
                    )
                    decision_logger.event(
                        "JOB_ID_REFRESH_FAILED",
                        [f"old_job_id={old_id}", "reason=no_running_job"],
                    )
            except Exception as e:
                logger.error(f"刷新 job_id 异常: {e}", exc_info=True)

        decision_logger.force_sync()
        logger.info("ZeroTune 重配置流程结束，锁已释放")


# ============================================================================
# TCP 连接处理
# ============================================================================
def _send_greeting(client_socket: socket.socket, addr: Tuple[str, int]) -> bool:
    greeting = {
        "type": "greeting",
        "session_id": DAEMON_SESSION_ID,
        "daemon_start_time_ms": int(DAEMON_START_TIME_TS * 1000),
        "daemon_start_iso": DAEMON_START_ISO,
        "monitor_log_hdfs": decision_logger.hdfs_path or "",
        "rescale_events_hdfs": rescale_event_logger.hdfs_path or "",
        "algorithm": "ZeroTune",
    }
    try:
        line = (json.dumps(greeting) + "\n").encode("utf-8")
        with broadcast_send_lock:
            client_socket.sendall(line)
        logger.info(f"已向 {addr} 发送 greeting | session_id={DAEMON_SESSION_ID}")
        return True
    except Exception as e:
        logger.error(f"发送 greeting 给 {addr} 失败: {e}")
        return False


def handle_connection(
    client_socket: socket.socket,
    addr: Tuple[str, int],
    model_name: str,
) -> None:
    logger.info(f"接收到 Java Sink 新连接: {addr}")
    update_heartbeat()
    decision_logger.event(
        "SINK_CONNECTED",
        [
            f"remote_addr={addr[0]}:{addr[1]}",
            f"session_id={DAEMON_SESSION_ID}",
        ],
    )

    if not _send_greeting(client_socket, addr):
        try:
            client_socket.close()
        except Exception:
            pass
        return

    register_client(client_socket, addr)

    try:
        with client_socket.makefile("r", encoding="utf-8") as reader:
            for line in reader:
                line = line.strip()
                if not line:
                    continue
                update_heartbeat()
                try:
                    raw_list = json.loads(line)
                    if not isinstance(raw_list, list):
                        logger.warning(f"收到非数组 JSON，已忽略: {raw_list!r}")
                        continue
                except json.JSONDecodeError as e:
                    logger.error(f"JSON 解析失败: {e}; line={line[:200]!r}")
                    continue

                try:
                    history: List[DS2MetricsPayload] = [
                        DS2MetricsPayload.from_dict(item)
                        for item in raw_list if isinstance(item, dict)
                    ]
                except Exception as e:
                    logger.error(f"DS2MetricsPayload 反序列化失败: {e}", exc_info=True)
                    continue

                if not history:
                    logger.debug("解析后无有效 payload，跳过")
                    continue

                latest = history[-1]
                logger.info(
                    f"收到 ZeroTune 指标 from {addr[0]} | windows={len(history)} | "
                    f"latest: records={latest.recordsProcessed}, "
                    f"busy={latest.totalBusyTimeMs}ms, "
                    f"dur={latest.windowDurationMs}ms, "
                    f"throughput={latest.observedThroughput:.4f} req/s, "
                    f"src_rate={latest.sourceEmissionRate:.4f} req/s, "
                    f"p={latest.currentParallelism}, b={latest.currentBatchSize}"
                )

                decision_logger.event(
                    "METRICS_RECEIVED",
                    [
                        f"from={addr[0]}:{addr[1]}",
                        f"windows={len(history)}",
                        f"latest.records={latest.recordsProcessed}",
                        f"latest.busy_ms={latest.totalBusyTimeMs}",
                        f"latest.duration_ms={latest.windowDurationMs}",
                        f"latest.throughput={latest.observedThroughput:.4f}",
                        f"latest.src_rate={latest.sourceEmissionRate:.4f}",
                        f"latest.parallelism={latest.currentParallelism}",
                        f"latest.batchsize={latest.currentBatchSize}",
                        f"is_reconfiguring={is_reconfiguring}",
                    ],
                )

                if is_reconfiguring:
                    logger.debug("重配置进行中，本次指标仅刷新心跳，不参与决策")
                    decision_logger.event(
                        "DECISION_SKIPPED",
                        ["reason=is_reconfiguring"],
                    )
                    continue

                try:
                    decision = compute_zerotune_decision(history)
                except Exception as e:
                    logger.error(f"ZeroTune 决策计算异常: {e}", exc_info=True)
                    decision_logger.event(
                        "DECISION_SKIPPED",
                        ["reason=exception", f"exception={type(e).__name__}: {e}"],
                    )
                    continue

                if decision is None:
                    continue

                if not should_trigger_rescale(decision):
                    continue

                t = threading.Thread(
                    target=trigger_reconfiguration,
                    args=(history, decision, model_name),
                    name=f"ZeroTune-Rescale-{int(time.time())}",
                    daemon=True,
                )
                t.start()

    except ConnectionResetError:
        logger.warning(f"连接被对端重置: {addr}")
        decision_logger.event("SINK_DISCONNECTED",
                              [f"remote_addr={addr[0]}:{addr[1]}", "reason=reset"])
    except Exception as e:
        logger.error(f"处理连接 {addr} 时异常: {e}", exc_info=True)
        decision_logger.event(
            "SINK_DISCONNECTED",
            [f"remote_addr={addr[0]}:{addr[1]}", f"exception={type(e).__name__}: {e}"],
        )
    finally:
        unregister_client(client_socket)
        try:
            client_socket.close()
        except Exception:
            pass
        logger.info(f"连接 {addr} 已关闭")


# ─── 主入口 ────────────────────────────────────────────────────────────────
def parse_cli_args() -> Dict[str, Any]:
    """
    解析 CLI 参数。

    参数格式与 Sink 算子 (NJULocalCacheTestAutoReconfigUniformRecorderSink.java)
    启动 Daemon 的命令行严格对齐：

        python daemon_reconfiguration_monitor_zerotune_recorder.py \
            <nodeIP> <port> <model> [jobId] [maxRequests] [baseInterval] [cache] [SLO]

    Sink 中 connectOrStartDaemon() 方法的启动命令（第 663-667 行）：
        /opt/flink-python-venv/bin/python /mnt/code/daemon_reconfiguration_monitor_zerotune_recorder.py
        <nodeIP> <DAEMON_PORT> <llmModelName> <jobId> <maxRequests> <baseInterval> <cacheStrategy> <SLO>

    所有参数均为位置参数，无命名参数。模型路径通过 ZT_MODEL_DIR 常量
    硬编码为 /mnt/models（Docker 容器中由宿主机挂载）。
    """
    if len(sys.argv) < 4:
        print(
            "Usage: daemon_reconfiguration_monitor_zerotune_recorder.py "
            "<nodeIP> <port> <model> [jobId] [maxRequests] [baseInterval] [cache] [SLO]",
            file=sys.stderr,
        )
        sys.exit(2)

    args: Dict[str, Any] = {
        "node_ip": sys.argv[1],
        "port": int(sys.argv[2]),
        "model": sys.argv[3],
        "job_id": sys.argv[4] if len(sys.argv) > 4 else None,
        "max_requests": int(sys.argv[5]) if len(sys.argv) > 5 else DEFAULT_MAX_REQUESTS,
        "base_interval": int(sys.argv[6]) if len(sys.argv) > 6 else DEFAULT_BASE_INTERVAL,
        "cache": sys.argv[7] if len(sys.argv) > 7 else DEFAULT_CACHE_TYPE,
        "slo_ms": float(sys.argv[8]) if len(sys.argv) > 8 else DEFAULT_SLO_MS,
    }
    return args


def setup_logger(node_ip: str, model: str) -> None:
    log_dir = "/tmp/zerotune_daemon_logs"
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, f"zerotune_daemon_{node_ip}_{model.replace('/', '_')}.log")

    logger.remove()
    fmt = ("<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | "
           "<level>{level: <7}</level> | "
           "<cyan>{thread.name}</cyan> | "
           "<level>{message}</level>")
    logger.add(sys.stderr, level="INFO", format=fmt, enqueue=False)
    logger.add(log_path, level="DEBUG", format=fmt,
               rotation="50 MB", retention=5, encoding="utf-8", enqueue=True)
    logger.info(f"日志文件: {log_path}")


def start_tcp_server(host: str, port: int, model_name: str) -> None:
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        server.bind((host, port))
    except OSError as e:
        logger.error(f"绑定 {host}:{port} 失败: {e}")
        sys.exit(1)
    server.listen(16)
    logger.info(f"ZeroTune Daemon TCP server 监听 {host}:{port}")

    while True:
        try:
            client_sock, addr = server.accept()
        except KeyboardInterrupt:
            logger.info("收到 KeyboardInterrupt，关闭 server")
            break
        except Exception as e:
            logger.error(f"accept 异常: {e}", exc_info=True)
            time.sleep(1)
            continue

        t = threading.Thread(
            target=handle_connection,
            args=(client_sock, addr, model_name),
            name=f"sink-conn-{addr[0]}:{addr[1]}",
            daemon=True,
        )
        t.start()

    try:
        server.close()
    except Exception:
        pass


def main() -> None:
    global runtime_max_requests, runtime_base_interval, runtime_cache_type, runtime_slo_ms

    args = parse_cli_args()
    setup_logger(args["node_ip"], args["model"])

    runtime_max_requests  = args["max_requests"]
    runtime_base_interval = args["base_interval"]
    runtime_cache_type    = args["cache"]
    runtime_slo_ms        = args["slo_ms"]

    # 加载 ZeroTune 预测器（模型路径硬编码为 ZT_MODEL_DIR=/mnt/models）
    if not load_zerotune_models(ZT_MODEL_DIR):
        logger.error(
            f"ZeroTune 预测器加载失败（model_dir={ZT_MODEL_DIR}）。"
            f"请先运行 train_zerotune_predictors.py 训练模型，"
            f"并将模型文件挂载到容器 {ZT_MODEL_DIR} 目录。"
            f"Daemon 将继续运行但不会触发任何重配置。"
        )

    if args["job_id"]:
        set_current_job_id(args["job_id"])
    else:
        discovered = get_running_job_id_from_rest()
        if discovered:
            set_current_job_id(discovered)

    decision_logger.init(args["model"])
    rescale_event_logger.init(args["model"])

    decision_logger.event(
        "DAEMON_STARTED",
        [
            f"node_ip={args['node_ip']}",
            f"port={args['port']}",
            f"model={args['model']}",
            f"job_id={get_current_job_id()}",
            f"max_requests={runtime_max_requests}",
            f"base_interval={runtime_base_interval}",
            f"cache={runtime_cache_type}",
            f"slo_ms={runtime_slo_ms}",
            f"session_id={DAEMON_SESSION_ID}",
            f"model_dir={ZT_MODEL_DIR}",
            f"zt_models_loaded={zt_models_loaded}",
            f"algorithm=ZeroTune",
        ],
    )

    rescale_event_logger.log("DAEMON_STARTED", {
        "rescale_seq": "",
        "old_job_id": get_current_job_id() or "",
        "reason": "daemon_init",
        "rescale_status": "INIT",
    })

    logger.info("=" * 60)
    logger.info("ZeroTune Daemon 启动")
    logger.info(f"  session_id:         {DAEMON_SESSION_ID}")
    logger.info(f"  node_ip:            {args['node_ip']}")
    logger.info(f"  port:               {args['port']}")
    logger.info(f"  model:              {args['model']}")
    logger.info(f"  job_id:             {get_current_job_id()}")
    logger.info(f"  model_dir:          {ZT_MODEL_DIR}")
    logger.info(f"  zt_models_loaded:   {zt_models_loaded}")
    logger.info(f"  slo_ms:             {runtime_slo_ms}")
    logger.info(f"  decision_log_local: {decision_logger.local_path}")
    logger.info(f"  decision_log_hdfs:  {decision_logger.hdfs_path}")
    logger.info(f"  rescale_csv_local:  {rescale_event_logger.local_path}")
    logger.info(f"  rescale_csv_hdfs:   {rescale_event_logger.hdfs_path}")
    logger.info("=" * 60)

    update_heartbeat()
    threading.Thread(target=watchdog, name="zerotune-watchdog", daemon=True).start()

    start_tcp_server("0.0.0.0", args["port"], args["model"])


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as e:
        logger.error(f"Daemon 主流程异常退出: {e}", exc_info=True)
        try:
            decision_logger.event(
                "DAEMON_CRASH",
                [f"exception={type(e).__name__}: {e}"],
            )
            decision_logger.force_sync()
        except Exception:
            pass
        try:
            rescale_event_logger.log("DAEMON_CRASH", {
                "rescale_seq": "",
                "old_job_id": get_current_job_id() or "",
                "reason": "daemon_crash",
                "rescale_status": "CRASH",
                "error_msg": f"{type(e).__name__}: {e}",
            })
        except Exception:
            pass
        sys.exit(1)
