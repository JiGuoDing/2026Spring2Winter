#!/usr/bin/env python3
"""
ZeroTune 性能预测器离线训练脚本
=================================

本脚本从 traces/ 目录中加载所有 sink CSV 文件，训练三个 RandomForest 回归模型，
分别预测：
    1. avg_latency_ms    （平均延迟）
    2. throughput_rps    （吞吐率）
    3. gpu_utilization   （GPU 利用率）

特征列：parallelism, batch_size, arrival_rate（由 target_rate 重命名）

输出：
    - {model_dir}/predictor_latency.joblib
    - {model_dir}/predictor_throughput.joblib
    - {model_dir}/predictor_gpu.joblib
    - {model_dir}/model_metadata.json

用法：
    python train_zerotune_predictors.py [--traces-dir traces/] [--model-dir /tmp/zerotune_models]
"""
import argparse
import json
import os
import sys
import warnings
from datetime import datetime
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import cross_val_score
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# 导入共享常量
from zerotune_constants import (
    COL_PARALLELISM, COL_BATCH_SIZE, COL_TARGET_RATE,
    COL_THROUGHPUT, COL_LATENCY, COL_GPU_UTIL,
    COL_TOTAL_REQUESTS,
    FEATURE_COLUMNS, TARGET_COLUMNS,
    ZT_MODEL_DIR, ZT_MODEL_LATENCY, ZT_MODEL_THROUGHPUT, ZT_MODEL_GPU,
    ZT_MODEL_METADATA,
    PARALLELISM_VALUES, BATCH_SIZE_VALUES, CANDIDATE_CONFIGS,
)

warnings.filterwarnings("ignore", category=FutureWarning)


# ============================================================================
# 数据加载
# ============================================================================
def load_all_sink_csvs(traces_dir: str) -> pd.DataFrame:
    """
    递归遍历 traces_dir，加载所有 sink CSV 文件。

    查找模式：traces_dir/*/sink/session_*_subtask_0.csv
    也兼容 session_*_subtask_*.csv（多 subtask 场景）。

    返回合并后的 DataFrame，包含以下列：
        parallelism, batch_size, arrival_rate,
        avg_latency_ms, throughput_rps, gpu_utilization
    """
    import glob

    # 匹配所有 sink CSV 文件
    pattern = os.path.join(traces_dir, "*", "sink", "session_*_subtask_*.csv")
    csv_files = sorted(glob.glob(pattern))

    if not csv_files:
        # 尝试二级目录匹配：traces_dir/*/*/sink/session_*_subtask_*.csv
        pattern = os.path.join(traces_dir, "*", "*", "sink", "session_*_subtask_*.csv")
        csv_files = sorted(glob.glob(pattern))

    if not csv_files:
        print(f"[ERROR] 在 {traces_dir} 下未找到任何 sink CSV 文件", file=sys.stderr)
        sys.exit(1)

    print(f"[INFO] 找到 {len(csv_files)} 个 sink CSV 文件")

    all_dfs: List[pd.DataFrame] = []
    required_cols = [
        COL_PARALLELISM, COL_BATCH_SIZE, COL_TARGET_RATE,
        COL_THROUGHPUT, COL_LATENCY, COL_GPU_UTIL,
    ]

    for fpath in csv_files:
        try:
            df = pd.read_csv(fpath)
        except Exception as e:
            print(f"[WARN] 读取失败，跳过: {fpath}: {e}")
            continue

        # 检查必需列是否存在
        missing = [c for c in required_cols if c not in df.columns]
        if missing:
            print(f"[WARN] 缺少列 {missing}，跳过: {fpath}")
            continue

        # 只保留需要的列
        subset = df[required_cols].copy()

        # 从路径提取实验类型（如 2slower_ds2, 5slower_conttune）
        # 路径格式: traces/{experiment_type}/{config}/sink/...
        parts = os.path.normpath(fpath).split(os.sep)
        # 找到 sink 目录的上两级
        try:
            sink_idx = parts.index("sink")
            experiment_type = parts[sink_idx - 2]  # 如 2slower_ds2
            config_name = parts[sink_idx - 1]       # 如 p2b8
        except (ValueError, IndexError):
            experiment_type = "unknown"
            config_name = "unknown"

        subset["experiment_type"] = experiment_type
        subset["config_name"] = config_name
        subset["source_file"] = os.path.basename(fpath)

        all_dfs.append(subset)

    if not all_dfs:
        print("[ERROR] 没有成功加载任何 CSV 数据", file=sys.stderr)
        sys.exit(1)

    combined = pd.concat(all_dfs, ignore_index=True)
    print(f"[INFO] 合并后共 {len(combined)} 行原始数据")
    return combined


# ============================================================================
# 数据清洗
# ============================================================================
def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    清洗训练数据：
    1. 删除 throughput_rps == 0 的行（预热阶段）
    2. 删除 avg_latency_ms == 0 的行（无效数据）
    3. 删除 target_rate <= 0 的行（无到达率信息）
    4. 删除含 NaN 的行
    5. 将 target_rate 重命名为 arrival_rate
    """
    before = len(df)

    # 删除零值行
    df = df[df[COL_THROUGHPUT] > 0]
    df = df[df[COL_LATENCY] > 0]
    df = df[df[COL_TARGET_RATE] > 0]

    # 删除 NaN
    feature_target_cols = [
        COL_PARALLELISM, COL_BATCH_SIZE, COL_TARGET_RATE,
        COL_THROUGHPUT, COL_LATENCY, COL_GPU_UTIL,
    ]
    df = df.dropna(subset=feature_target_cols)

    # 重命名 target_rate → arrival_rate
    df = df.rename(columns={COL_TARGET_RATE: "arrival_rate"})

    after = len(df)
    print(f"[INFO] 数据清洗: {before} → {after} 行（删除 {before - after} 行）")
    return df


# ============================================================================
# 训练
# ============================================================================
def train_predictors(
    df: pd.DataFrame,
    model_type: str = "random_forest",
) -> Dict[str, RandomForestRegressor]:
    """
    训练三个预测器模型。

    参数:
        df: 清洗后的 DataFrame，包含 FEATURE_COLUMNS + 目标列
        model_type: 模型类型，目前支持 "random_forest"

    返回:
        {"latency": model, "throughput": model, "gpu": model}
    """
    X = df[FEATURE_COLUMNS].values  # shape: (N, 3)
    models: Dict[str, RandomForestRegressor] = {}

    for target_name, target_col in TARGET_COLUMNS.items():
        y = df[target_col].values

        if model_type == "random_forest":
            model = RandomForestRegressor(
                n_estimators=100,
                max_depth=8,
                min_samples_leaf=5,
                random_state=42,
                n_jobs=-1,
            )
        else:
            print(f"[ERROR] 不支持的模型类型: {model_type}", file=sys.stderr)
            sys.exit(1)

        # 5-fold 交叉验证
        cv_folds = min(5, len(X) // 2)  # 数据量小时减少折数
        if cv_folds < 2:
            print(f"[WARN] 数据量过少 ({len(X)} 行)，跳过交叉验证")
            model.fit(X, y)
            models[target_name] = model
            continue

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            cv_r2 = cross_val_score(model, X, y, cv=cv_folds, scoring="r2")
            cv_neg_mae = cross_val_score(
                model, X, y, cv=cv_folds, scoring="neg_mean_absolute_error"
            )

        # 在全量数据上训练最终模型
        model.fit(X, y)

        # 计算全量数据上的指标
        y_pred = model.predict(X)
        mae = mean_absolute_error(y, y_pred)
        rmse = np.sqrt(mean_squared_error(y, y_pred))
        r2 = r2_score(y, y_pred)

        print(f"\n[{target_name.upper()}] 目标列: {target_col}")
        print(f"  训练样本数: {len(X)}")
        print(f"  交叉验证 R²:  {cv_r2.mean():.4f} ± {cv_r2.std():.4f}")
        print(f"  交叉验证 MAE: {-cv_neg_mae.mean():.4f} ± {cv_neg_mae.std():.4f}")
        print(f"  全量 MAE:  {mae:.4f}")
        print(f"  全量 RMSE: {rmse:.4f}")
        print(f"  全量 R²:   {r2:.4f}")

        # 特征重要性
        importances = model.feature_importances_
        for fname, imp in zip(FEATURE_COLUMNS, importances):
            print(f"  特征重要性 [{fname}]: {imp:.4f}")

        models[target_name] = model

    return models


# ============================================================================
# 评估报告
# ============================================================================
def evaluate_per_config(
    df: pd.DataFrame,
    models: Dict[str, RandomForestRegressor],
) -> Dict[str, Dict[str, float]]:
    """
    按 (parallelism, batch_size) 配置分组评估预测精度。
    返回: {config_name: {target: {"mae": ..., "r2": ..., "n_samples": ...}}}
    """
    X_all = df[FEATURE_COLUMNS].values
    results: Dict[str, Dict[str, float]] = {}

    print("\n" + "=" * 80)
    print("按配置分组评估")
    print("=" * 80)

    for (p, b) in CANDIDATE_CONFIGS:
        mask = (df["parallelism"] == p) & (df["batch_size"] == b)
        n = mask.sum()
        if n == 0:
            continue

        config_name = f"p{p}b{b}"
        X_cfg = df.loc[mask, FEATURE_COLUMNS].values
        results[config_name] = {"n_samples": int(n)}

        print(f"\n  [{config_name}] 样本数: {n}")
        for target_name, target_col in TARGET_COLUMNS.items():
            y_true = df.loc[mask, target_col].values
            y_pred = models[target_name].predict(X_cfg)
            mae = mean_absolute_error(y_true, y_pred)
            r2 = r2_score(y_true, y_pred) if n > 1 else float("nan")
            results[config_name][f"{target_name}_mae"] = float(mae)
            results[config_name][f"{target_name}_r2"] = float(r2)
            print(f"    {target_name:12s}  MAE={mae:.4f}  R²={r2:.4f}")

    return results


# ============================================================================
# 模型保存
# ============================================================================
def save_models(
    models: Dict[str, RandomForestRegressor],
    model_dir: str,
    df: pd.DataFrame,
    per_config_results: Dict[str, Dict[str, float]],
) -> None:
    """保存模型文件和元数据 JSON。"""
    import joblib

    os.makedirs(model_dir, exist_ok=True)

    # 保存模型
    model_files = {
        "latency":    os.path.join(model_dir, ZT_MODEL_LATENCY),
        "throughput": os.path.join(model_dir, ZT_MODEL_THROUGHPUT),
        "gpu":        os.path.join(model_dir, ZT_MODEL_GPU),
    }
    for name, fpath in model_files.items():
        joblib.dump(models[name], fpath)
        size_kb = os.path.getsize(fpath) / 1024
        print(f"[INFO] 已保存模型: {fpath} ({size_kb:.1f} KB)")

    # 保存元数据
    metadata = {
        "training_time": datetime.now().isoformat(),
        "num_training_samples": len(df),
        "feature_columns": FEATURE_COLUMNS,
        "target_columns": TARGET_COLUMNS,
        "model_type": "RandomForestRegressor",
        "hyperparameters": {
            "n_estimators": 100,
            "max_depth": 8,
            "min_samples_leaf": 5,
            "random_state": 42,
        },
        "per_config_sample_counts": {},
        "per_config_evaluation": per_config_results,
        "data_distribution": {
            "parallelism_values": sorted(df["parallelism"].unique().tolist()),
            "batch_size_values": sorted(df["batch_size"].unique().tolist()),
            "arrival_rate_range": [
                float(df["arrival_rate"].min()),
                float(df["arrival_rate"].max()),
            ],
        },
    }

    # 每个配置的样本数
    for (p, b) in CANDIDATE_CONFIGS:
        mask = (df["parallelism"] == p) & (df["batch_size"] == b)
        count = int(mask.sum())
        if count > 0:
            metadata["per_config_sample_counts"][f"p{p}b{b}"] = count

    meta_path = os.path.join(model_dir, ZT_MODEL_METADATA)
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2, ensure_ascii=False)
    print(f"[INFO] 已保存元数据: {meta_path}")


# ============================================================================
# 主入口
# ============================================================================
def main() -> None:
    parser = argparse.ArgumentParser(
        description="ZeroTune 性能预测器离线训练脚本"
    )
    parser.add_argument(
        "--traces-dir",
        default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "traces"),
        help="traces 数据目录路径（默认: ./traces）",
    )
    parser.add_argument(
        "--model-dir",
        default=ZT_MODEL_DIR,
        help=f"模型输出目录（默认: {ZT_MODEL_DIR}）",
    )
    parser.add_argument(
        "--model-type",
        default="random_forest",
        choices=["random_forest"],
        help="模型类型（默认: random_forest）",
    )
    args = parser.parse_args()

    print("=" * 80)
    print("ZeroTune 性能预测器训练")
    print(f"  时间: {datetime.now().isoformat()}")
    print(f"  数据目录: {args.traces_dir}")
    print(f"  模型目录: {args.model_dir}")
    print(f"  模型类型: {args.model_type}")
    print("=" * 80)

    # 1. 加载数据
    df = load_all_sink_csvs(args.traces_dir)

    # 2. 清洗
    df = clean_data(df)
    if len(df) < 10:
        print(f"[ERROR] 清洗后仅剩 {len(df)} 行数据，不足以训练", file=sys.stderr)
        sys.exit(1)

    # 3. 数据概览
    print(f"\n[INFO] 训练数据概览:")
    print(f"  总样本数: {len(df)}")
    print(f"  并行度分布: {df['parallelism'].value_counts().to_dict()}")
    print(f"  批次大小分布: {df['batch_size'].value_counts().to_dict()}")
    print(f"  到达率范围: [{df['arrival_rate'].min():.4f}, {df['arrival_rate'].max():.4f}]")
    print(f"  延迟范围: [{df['avg_latency_ms'].min():.1f}, {df['avg_latency_ms'].max():.1f}] ms")
    print(f"  吞吐范围: [{df['throughput_rps'].min():.4f}, {df['throughput_rps'].max():.4f}] req/s")
    print(f"  GPU利用率范围: [{df['gpu_utilization'].min():.4f}, {df['gpu_utilization'].max():.4f}]")

    # 4. 训练
    models = train_predictors(df, model_type=args.model_type)

    # 5. 按配置评估
    per_config_results = evaluate_per_config(df, models)

    # 6. 保存
    save_models(models, args.model_dir, df, per_config_results)

    print("\n" + "=" * 80)
    print("训练完成！")
    print(f"  模型文件位于: {args.model_dir}")
    print("=" * 80)


if __name__ == "__main__":
    main()
