"""
DS2 (Dhalion Streaming Scaling) 算法后台监控进程
==================================================

核心思想（来自 OSDI 2018 DS2 论文）：
- 通过测量算子的 "真实处理率" (true processing rate) 和 "目标输入率"
  (target input rate)，直接计算最优并行度，而不依赖反应式启发式规则。

DS2 关键公式：
    true_rate_per_subtask = records_processed / busy_time_seconds
    optimal_parallelism   = ceil(target_rate / (true_rate_per_subtask × u_target))

本版本相对前版的关键改动：
1. 新增 rescale_seq 关联键：daemon 在每次真正决定 rescale 时生成单调递增的
   rescale_seq，并通过 TCP 向所有已连接的 Sink 广播 prepare_rescale 消息：
       {"type":"prepare_rescale","rescale_seq":N,"session_id":...,
        "current_parallelism":..,"target_parallelism":..,...}
   Sink 在下一次 snapshotState 时把该 seq 写入 CSV 行，使
   (session_id, rescale_seq)
   成为 Sink CSV 行与 Daemon rescale_events CSV 行 1:1 严格关联的主键。
2. RescaleEventLogger CSV header 新增 rescale_seq 列（紧邻 session_id）。
3. 维护 active_clients 注册表（线程安全），handle_connection 进入/退出时
   register/unregister，便于广播。
4. 保留所有原有功能：DecisionLogger、失败冷却、job_id 强制刷新等。
5. [Bugfix] DecisionLogger / RescaleEventLogger 的本地写入与 HDFS 同步彻底解耦：
   找不到 hadoop CLI 时只关闭 HDFS 同步（hdfs_enabled=False），不再误把整个
   logger 禁用，保证本地 CSV / log 始终能持续追加。
6. [Bugfix] 修正 rescale.sh 输出 timing 行的解析关键字：
   - 旧关键字 "Stop+Savepoint Time" / "State Recovery Time" 与当前
     rescale.sh 实际输出的 "Savepoint Time" / "Recovery Time" 不匹配，
     导致 RESCALE_SUCCESS 行的 stop_savepoint_ms / state_recovery_ms 列长期为空。
   - 现已抽出独立的 _parse_rescale_timings() 函数，新关键字同时兼容新旧两种
     脚本输出格式：
        Savepoint:  "Savepoint Time" / "Stop+Savepoint Time" / "Stop Time"
        Recovery :  "Recovery Time"  / "State Recovery Time"
        Total    :  "Total Time"
   - 解析时按"先精确后宽泛"的顺序判断，避免 "Recovery Time" 误命中
     "Savepoint Time" 类分支（其实它们本来就不互相包含，但函数内仍做了显式排序，
     更加严谨）。
"""
import csv
import json
import math
import os
import re
import socket
import subprocess
import sys
import threading
import time
import urllib.request
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from loguru import logger

# ─── 看门狗配置 ────────────────────────────────────────────────────────────
TIMEOUT_SECONDS         = 180
WATCHDOG_CHECK_INTERVAL = 10
REPORT_WINDOW_NUM       = 5

# ─── Flink REST API ───────────────────────────────────────────────────────
FLINK_REST = "http://flink-jm:8081"

# ─── rescale.sh 路径与默认参数 ────────────────────────────────────────────
RESCALE_SCRIPT_PATH    = "/mnt/scripts/rescale.sh"
RESCALE_SCRIPT_TIMEOUT = 2100
DEFAULT_JAR_PATH       = "/mnt/jobs/NJULocalKVCacheTest-op-state-cache-async-inference-keepalive-tcp-docker-sglang-auto-reconfig-gpuhours-ds2-5slower.jar"

# ─── DS2 算法参数 ──────────────────────────────────────────────────────────
DS2_TARGET_UTILIZATION: float = 0.8
DS2_SCALE_THRESHOLD: float    = 0.15
DS2_MIN_PARALLELISM: int      = 1
DS2_MAX_PARALLELISM: int      = 4
DS2_MIN_WINDOWS_REQUIRED: int = 3
DS2_MIN_BUSY_RATIO_FOR_DECISION: float = 0.05
DS2_OVERLOAD_UTIL_THRESHOLD: float     = 0.92
DS2_OVERLOAD_PROBE_FACTOR: float       = 1.25
DS2_COOLDOWN_SECONDS: float            = 120.0

# ─── 默认运行时参数（CLI 可覆盖） ─────────────────────────────────────────
DEFAULT_MAX_REQUESTS  = 1000
DEFAULT_BASE_INTERVAL = 1000
DEFAULT_CACHE_TYPE    = "FREQUENCY"
DEFAULT_SLO_MS        = 90000.0

# ─── HDFS 路径常量 ─────────────────────────────────────────────────────────
HDFS_NAMENODE     = "hdfs://10.0.0.16:9090"
HDFS_SINK_BASE    = "/sink/cache_test"
HDFS_MARKER_BASE  = f"{HDFS_NAMENODE}/tmp/job_markers"

# ─── Daemon 启动时间 / Session ID（跨重配置不变） ─────────────────────────
DAEMON_START_TIME_TS: float = time.time()
DAEMON_START_ISO: str       = datetime.fromtimestamp(DAEMON_START_TIME_TS).strftime("%Y%m%d_%H%M%S")
DAEMON_SESSION_ID: str      = DAEMON_START_ISO

# ─── 全局状态 ──────────────────────────────────────────────────────────────
last_recv_time: float          = time.time()
heartbeat_lock                 = threading.Lock()
current_job_id: Optional[str]  = None
job_id_lock                    = threading.Lock()
reconfiguration_lock           = threading.Lock()
is_reconfiguring: bool         = False
last_reconfig_time: float      = 0.0

runtime_max_requests: int  = DEFAULT_MAX_REQUESTS
runtime_base_interval: int = DEFAULT_BASE_INTERVAL
runtime_cache_type: str    = DEFAULT_CACHE_TYPE
runtime_slo_ms: float      = DEFAULT_SLO_MS

# ─── rescale 序号 & 客户端注册表（用于 prepare_rescale 广播） ─────────────
rescale_seq_counter: int            = 0
rescale_seq_lock                    = threading.Lock()
active_clients_lock                 = threading.Lock()
active_clients: List[Tuple[socket.socket, Tuple[str, int]]] = []
broadcast_send_lock                 = threading.Lock()  # 串行化对所有 client socket 的写


# ============================================================================
# Rescale.sh timing 解析（与 rescale.sh 末尾 echo 行严格对齐）
# ============================================================================
#
# 当前 rescale.sh 末尾会按顺序打印类似：
#       Savepoint Time: 1234 ms
#       Recovery  Time: 5678 ms        # 注意脚本里实际为 "Recovery Time"（无 State 前缀）
#       Total     Time: 6912 ms
#
# 历史上某些版本曾使用：
#       Stop+Savepoint Time: 1234 ms
#       State Recovery Time: 5678 ms
#
# 为兼容两套关键字，下面用候选关键字列表 + 顺序优先级（最精确的写在最前面）
# 来匹配，并用统一正则 r":\s*(\d+)\s*ms" 抽出毫秒整数。
#
# 设计要点：
#   1. _classify_timing_line() 返回 ("savepoint" | "recovery" | "total" | None, ms 或 None)。
#   2. 关键字判断按 _SAVEPOINT_KEYS / _RECOVERY_KEYS / _TOTAL_KEYS 的顺序检查，
#      互不重叠（"Savepoint Time" 与 "Recovery Time" 不互为子串，"Total Time" 不与
#      前两者重叠），因此即使 if/elif 结构也不会误判；
#   3. 任一关键字命中后用正则抓 ms 数字；正则匹配失败则只把该行收进 timing_lines
#      但不更新对应 ms 字段（保持空字符串，与原行为一致）。
# ─────────────────────────────────────────────────────────────────────────────
_SAVEPOINT_KEYS: Tuple[str, ...] = ("Stop+Savepoint Time", "Savepoint Time", "Stop Time")
_RECOVERY_KEYS:  Tuple[str, ...] = ("State Recovery Time", "Recovery Time")
_TOTAL_KEYS:     Tuple[str, ...] = ("Total Time",)
_TIMING_MS_RE                    = re.compile(r":\s*(\d+)\s*ms")


def _classify_timing_line(stripped: str) -> Tuple[Optional[str], Optional[str]]:
    """
    判断一行 stdout 是否属于 timing 行，并尝试解析其中的毫秒数。

    返回:
        (kind, ms_str)
        kind   = "savepoint" / "recovery" / "total" / None
        ms_str = 解析出的毫秒整数字符串，未解析到则为 None

    注意:
        - kind 不为 None 仅代表"该行被识别为 timing 行"（应收入 timing_lines），
          ms_str 可能仍是 None（说明文案里没有 "...: <digit> ms" 结构）。
    """
    # 优先匹配 savepoint：包括 "Stop+Savepoint Time"（旧）、"Savepoint Time"（新）、"Stop Time"（极旧）
    for key in _SAVEPOINT_KEYS:
        if key in stripped:
            m = _TIMING_MS_RE.search(stripped)
            return "savepoint", (m.group(1) if m else None)

    # 再匹配 recovery：包括 "State Recovery Time"（旧）、"Recovery Time"（新）
    for key in _RECOVERY_KEYS:
        if key in stripped:
            m = _TIMING_MS_RE.search(stripped)
            return "recovery", (m.group(1) if m else None)

    # 最后匹配 total
    for key in _TOTAL_KEYS:
        if key in stripped:
            m = _TIMING_MS_RE.search(stripped)
            return "total", (m.group(1) if m else None)

    return None, None


def _parse_rescale_timings(stdout_lines: List[str]) -> Tuple[str, str, List[str]]:
    """
    遍历 rescale.sh 全部 stdout 行，抽出 savepoint / recovery 两个关键耗时（ms），
    并返回所有被识别为 timing 行的原文（含 Total Time），用于落到 decision log。

    返回:
        (stop_savepoint_ms, state_recovery_ms, timing_lines)
        - stop_savepoint_ms: 字符串形式的毫秒整数，未解析到则为 ""
        - state_recovery_ms: 同上
        - timing_lines:      所有被识别为 timing 类的原始 stdout 行（去首尾空白）

    解析策略:
        - 一行最多分类一次（kind ∈ {savepoint, recovery, total, None}）；
        - 若同一类型出现多行（不应发生），以"最后一次解析成功的值"为准 ——
          这样即便脚本未来加入中间调试输出也不会被早期错误值覆盖；
        - 若关键字命中但正则未抓到数字，仍把该行计入 timing_lines（便于人工排查）。
    """
    stop_savepoint_ms: str = ""
    state_recovery_ms: str = ""
    timing_lines: List[str] = []

    for line in stdout_lines:
        stripped = line.strip()
        if not stripped:
            continue
        kind, ms_str = _classify_timing_line(stripped)
        if kind is None:
            continue
        # 该行属于 timing 行，无条件收入（便于在 decision log 中保留原文）
        timing_lines.append(stripped)
        if ms_str is None:
            continue
        if kind == "savepoint":
            stop_savepoint_ms = ms_str
        elif kind == "recovery":
            state_recovery_ms = ms_str
        # kind == "total" 仅入 timing_lines，不单独落字段

    return stop_savepoint_ms, state_recovery_ms, timing_lines


def next_rescale_seq() -> int:
    """生成下一个单调递增的 rescale 序号（线程安全）。"""
    global rescale_seq_counter
    with rescale_seq_lock:
        rescale_seq_counter += 1
        return rescale_seq_counter


def register_client(sock: socket.socket, addr: Tuple[str, int]) -> None:
    with active_clients_lock:
        active_clients.append((sock, addr))
        logger.info(f"client 注册到广播列表 | {addr} | total={len(active_clients)}")


def unregister_client(sock: socket.socket) -> None:
    with active_clients_lock:
        before = len(active_clients)
        active_clients[:] = [(s, a) for (s, a) in active_clients if s is not sock]
        after = len(active_clients)
        logger.info(f"client 已从广播列表移除 | before={before}, after={after}")


def broadcast_prepare_rescale(rescale_seq: int,
                              reason: str,
                              decision: "DS2Decision",
                              old_job_id: Optional[str]) -> int:
    """
    向所有已连接的 Sink 广播 prepare_rescale 通知。
    Sink 收到后会把 rescale_seq 写入下一次 snapshotState 产生的 CSV 行。
    返回成功发送的客户端数。
    """
    msg = {
        "type": "prepare_rescale",
        "rescale_seq": rescale_seq,
        "session_id": DAEMON_SESSION_ID,
        "reason": reason,
        "old_job_id": old_job_id or "",
        "current_parallelism": decision.current_parallelism,
        "target_parallelism": decision.optimal_parallelism,
        "true_rate_per_subtask": decision.true_rate_per_subtask,
        "avg_utilization": decision.avg_utilization,
        "issued_at_ms": int(time.time() * 1000),
    }
    line = (json.dumps(msg) + "\n").encode("utf-8")

    with active_clients_lock:
        clients = list(active_clients)

    sent_ok = 0
    failed = 0
    with broadcast_send_lock:
        for sock, addr in clients:
            try:
                sock.sendall(line)
                sent_ok += 1
                logger.info(f"已广播 prepare_rescale 给 {addr} | seq={rescale_seq}")
            except Exception as e:
                failed += 1
                logger.warning(f"广播 prepare_rescale 给 {addr} 失败: {e}")
    logger.info(
        f"prepare_rescale 广播完成 | seq={rescale_seq} | "
        f"sent_ok={sent_ok} | failed={failed} | total_clients={len(clients)}"
    )
    return sent_ok


# ============================================================================
# DecisionLogger —— 详细的人类可读决策日志（保持原有功能）
# ============================================================================
class DecisionLogger:
    SYNC_INTERVAL_S = 15.0

    def __init__(self) -> None:
        self.local_path: Optional[str] = None
        self.hdfs_path: Optional[str]  = None
        self.lock                      = threading.Lock()
        self.enabled: bool             = False   # 本地写入是否可用
        self.hdfs_enabled: bool        = True    # HDFS 同步是否可用（独立开关）
        self.pending_changes: bool     = False
        self.entry_seq: int            = 0
        self.model_name: str           = ""

    def init(self, model_name: str) -> None:
        self.model_name = model_name or "unknown_model"
        local_dir = "/tmp/ds2_daemon_logs"
        os.makedirs(local_dir, exist_ok=True)
        self.local_path = os.path.join(local_dir, f"monitor_{DAEMON_START_ISO}.log")
        self.hdfs_path = (
            f"{HDFS_NAMENODE}{HDFS_SINK_BASE}/{self.model_name}/collector/"
            f"monitor_{DAEMON_START_ISO}.log"
        )

        header = (
            "=" * 80 + "\n"
            f"DS2 Monitor Decision Log\n"
            f"Daemon Start Time: {datetime.fromtimestamp(DAEMON_START_TIME_TS).isoformat()}\n"
            f"Session ID: {DAEMON_SESSION_ID}\n"
            f"Model: {self.model_name}\n"
            f"DS2 Params: TARGET_UTIL={DS2_TARGET_UTILIZATION}, "
            f"SCALE_THRESHOLD={DS2_SCALE_THRESHOLD}, "
            f"COOLDOWN={DS2_COOLDOWN_SECONDS}s, "
            f"MIN_WINDOWS={DS2_MIN_WINDOWS_REQUIRED}, "
            f"MIN_BUSY={DS2_MIN_BUSY_RATIO_FOR_DECISION}, "
            f"OVERLOAD_UTIL={DS2_OVERLOAD_UTIL_THRESHOLD}, "
            f"OVERLOAD_FACTOR={DS2_OVERLOAD_PROBE_FACTOR}, "
            f"P_RANGE=[{DS2_MIN_PARALLELISM},{DS2_MAX_PARALLELISM}]\n"
            f"Local Log: {self.local_path}\n"
            f"HDFS  Log: {self.hdfs_path}\n"
            + "=" * 80 + "\n\n"
        )
        try:
            with open(self.local_path, "w", encoding="utf-8") as f:
                f.write(header)
            self.enabled = True
        except Exception as e:
            logger.error(f"DecisionLogger 初始化本地文件失败: {e}")
            return

        # 首次同步失败也只会关闭 hdfs_enabled，不影响 enabled
        self._sync_to_hdfs(force=True)
        threading.Thread(target=self._sync_loop, name="decision-log-sync", daemon=True).start()
        logger.info(f"DecisionLogger 已启用 | local={self.local_path} | hdfs={self.hdfs_path}")

    def event(self, event_type: str, lines: Optional[List[str]] = None) -> None:
        if not self.enabled or self.local_path is None:
            return
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        with self.lock:
            self.entry_seq += 1
            seq = self.entry_seq
            try:
                with open(self.local_path, "a", encoding="utf-8") as f:
                    f.write(f"[{ts}] #{seq:05d} {event_type}\n")
                    if lines:
                        for line in lines:
                            f.write(f"    {line}\n")
                    f.write("\n")
                    f.flush()
                self.pending_changes = True
            except Exception as e:
                logger.error(f"DecisionLogger 写入失败: {e}")

    def force_sync(self) -> None:
        if self.enabled:
            self._sync_to_hdfs(force=True)

    def _sync_to_hdfs(self, force: bool = False) -> None:
        # 本地不可用，或 HDFS 同步已被禁用，则直接 return
        if not self.enabled or not self.hdfs_enabled \
                or self.local_path is None or self.hdfs_path is None:
            return
        if not force and not self.pending_changes:
            return
        with self.lock:
            self.pending_changes = False
        try:
            parent_dir = self.hdfs_path.rsplit("/", 1)[0]
            mk = subprocess.run(
                ["hadoop", "fs", "-mkdir", "-p", parent_dir],
                capture_output=True, timeout=30,
            )
            if mk.returncode != 0:
                logger.warning(
                    f"hadoop fs -mkdir 失败: rc={mk.returncode}, "
                    f"stderr={mk.stderr.decode('utf-8', errors='ignore')[:300]}"
                )
            cp = subprocess.run(
                ["hadoop", "fs", "-copyFromLocal", "-f", self.local_path, self.hdfs_path],
                capture_output=True, timeout=120,
            )
            if cp.returncode != 0:
                logger.warning(
                    f"hadoop fs -copyFromLocal 失败: rc={cp.returncode}, "
                    f"stderr={cp.stderr.decode('utf-8', errors='ignore')[:300]}"
                )
            else:
                logger.debug(f"决策日志已同步到 HDFS: {self.hdfs_path}")
        except FileNotFoundError:
            # ★ 关键修复：只关 HDFS 同步，本地写入不受影响
            logger.warning(
                "未找到 hadoop CLI，决策日志仅保存在本地（后续不再尝试同步 HDFS）"
            )
            self.hdfs_enabled = False
        except subprocess.TimeoutExpired:
            logger.warning("hadoop fs 命令超时")
        except Exception as e:
            logger.warning(f"同步决策日志到 HDFS 异常: {e}")

    def _sync_loop(self) -> None:
        while True:
            time.sleep(self.SYNC_INTERVAL_S)
            # 若 HDFS 同步已被禁用，没必要再起调用
            if not self.enabled or not self.hdfs_enabled:
                continue
            try:
                self._sync_to_hdfs(force=False)
            except Exception as e:
                logger.warning(f"DecisionLogger 同步循环异常: {e}")


decision_logger = DecisionLogger()


# ============================================================================
# RescaleEventLogger —— 结构化 CSV，便于后续分析
# ============================================================================
class RescaleEventLogger:
    """
    把每次 rescale 相关事件以 CSV 行追加写入本地文件，并同步到 HDFS。
    每写一行立即触发一次 HDFS 覆盖上传，确保即使 daemon 异常退出，
    最近一次决定的事件也已经持久化。

    CSV 路径：
        local: /tmp/ds2_daemon_logs/rescale_events_{DAEMON_START_ISO}.csv
        hdfs:  {HDFS_NAMENODE}{HDFS_SINK_BASE}/{model}/collector/
                   rescale_events_{DAEMON_START_ISO}.csv

    关键列：
        session_id + rescale_seq → 与 Sink CSV 行的 (session_id, rescale_seq)
        1:1 关联，用于跨进程 join 分析。
    """

    HEADER = [
        "event_seq",
        "event_time_iso",
        "event_time_ms",
        "session_id",
        "rescale_seq",          # 与 Sink CSV 行 join 的关键列；预检查失败时为空
        "model",
        "event_type",
        "old_job_id",
        "new_job_id",
        "old_parallelism",
        "new_parallelism",
        "batch_size",
        "reason",
        "true_rate_per_subtask",
        "avg_utilization",
        "observed_throughput",
        "source_rate",
        "base_target_rate",
        "effective_target_rate",
        "raw_optimal",
        "diff_ratio",
        "overload_detected",
        "windows_used",
        "total_records",
        "total_busy_ms",
        "total_duration_ms",
        "rescale_status",
        "rescale_elapsed_ms",
        "stop_savepoint_ms",
        "state_recovery_ms",
        "broadcast_clients_ok",
        "error_msg",
    ]

    def __init__(self) -> None:
        self.local_path: Optional[str] = None
        self.hdfs_path: Optional[str]  = None
        self.lock                      = threading.Lock()
        self.enabled: bool             = False   # 本地写入是否可用
        self.hdfs_enabled: bool        = True    # HDFS 同步是否可用（独立开关）
        self.event_seq: int            = 0
        self.model_name: str           = ""

    def init(self, model_name: str) -> None:
        self.model_name = model_name or "unknown_model"
        local_dir = "/tmp/ds2_daemon_logs"
        os.makedirs(local_dir, exist_ok=True)
        self.local_path = os.path.join(
            local_dir, f"rescale_events_{DAEMON_START_ISO}.csv"
        )
        self.hdfs_path = (
            f"{HDFS_NAMENODE}{HDFS_SINK_BASE}/{self.model_name}/collector/"
            f"rescale_events_{DAEMON_START_ISO}.csv"
        )
        try:
            # 首次创建：写 header
            with open(self.local_path, "w", encoding="utf-8", newline="") as f:
                w = csv.writer(f)
                w.writerow(self.HEADER)
            self.enabled = True
            logger.info(
                f"RescaleEventLogger 已启用 | local={self.local_path} | hdfs={self.hdfs_path}"
            )
            # 首次同步失败只会关 hdfs_enabled，不会影响 enabled
            self._sync_to_hdfs()
        except Exception as e:
            logger.error(f"RescaleEventLogger 初始化失败: {e}")
            self.enabled = False

    def log(self, event_type: str, fields: Optional[Dict[str, Any]] = None) -> None:
        """
        追加一条事件并立刻同步到 HDFS。fields 可不传任何字段；缺失的列会写空字符串。
        """
        if not self.enabled or self.local_path is None:
            return

        now_ms = int(time.time() * 1000)
        now_iso = datetime.fromtimestamp(now_ms / 1000.0).strftime(
            "%Y-%m-%dT%H:%M:%S.%f"
        )[:-3]

        with self.lock:
            self.event_seq += 1
            row_dict: Dict[str, Any] = {
                "event_seq": self.event_seq,
                "event_time_iso": now_iso,
                "event_time_ms": now_ms,
                "session_id": DAEMON_SESSION_ID,
                "model": self.model_name,
                "event_type": event_type,
            }
            if fields:
                row_dict.update(fields)

            row = [self._fmt(row_dict.get(col, "")) for col in self.HEADER]

            try:
                with open(self.local_path, "a", encoding="utf-8", newline="") as f:
                    w = csv.writer(f)
                    w.writerow(row)
                    f.flush()
            except Exception as e:
                logger.error(f"RescaleEventLogger 写入本地失败: {e}")
                return

        # 写完立刻同步（不持锁，避免长时间阻塞其它 log 调用）
        # 内部会自动判断 hdfs_enabled，若已禁用则直接 return
        self._sync_to_hdfs()

    @staticmethod
    def _fmt(v: Any) -> str:
        if v is None:
            return ""
        if isinstance(v, bool):
            return "true" if v else "false"
        if isinstance(v, float):
            if math.isnan(v) or math.isinf(v):
                return ""
            return f"{v:.6f}"
        # 把可能含逗号 / 换行的 reason / error_msg 拍扁；csv 模块本身会做引号转义
        if isinstance(v, str):
            return v.replace("\n", " | ").replace("\r", " ")
        return str(v)

    def _sync_to_hdfs(self) -> None:
        # 本地不可用，或 HDFS 同步已被禁用，则直接 return
        if not self.enabled or not self.hdfs_enabled \
                or self.local_path is None or self.hdfs_path is None:
            return
        try:
            parent_dir = self.hdfs_path.rsplit("/", 1)[0]
            mk = subprocess.run(
                ["hadoop", "fs", "-mkdir", "-p", parent_dir],
                capture_output=True, timeout=30,
            )
            if mk.returncode != 0:
                logger.warning(
                    f"[rescale-events] hadoop fs -mkdir 失败: rc={mk.returncode}, "
                    f"stderr={mk.stderr.decode('utf-8', errors='ignore')[:300]}"
                )
            cp = subprocess.run(
                ["hadoop", "fs", "-copyFromLocal", "-f",
                 self.local_path, self.hdfs_path],
                capture_output=True, timeout=120,
            )
            if cp.returncode != 0:
                logger.warning(
                    f"[rescale-events] hadoop fs -copyFromLocal 失败: rc={cp.returncode}, "
                    f"stderr={cp.stderr.decode('utf-8', errors='ignore')[:300]}"
                )
            else:
                logger.debug(f"[rescale-events] 已同步到 HDFS: {self.hdfs_path}")
        except FileNotFoundError:
            # ★ 关键修复：只关 HDFS 同步，本地写入不受影响
            logger.warning(
                "未找到 hadoop CLI，rescale 事件 CSV 仅保存本地（后续不再尝试同步 HDFS）"
            )
            self.hdfs_enabled = False
        except subprocess.TimeoutExpired:
            logger.warning("[rescale-events] hadoop fs 命令超时")
        except Exception as e:
            logger.warning(f"[rescale-events] 同步到 HDFS 异常: {e}")


rescale_event_logger = RescaleEventLogger()


# ─── 数据模型 ──────────────────────────────────────────────────────────────
@dataclass
class DS2MetricsPayload:
    nodeIp: str
    windowStartTimestamp: int
    windowEndTimestamp: int
    windowDurationMs: int
    recordsProcessed: int
    totalBusyTimeMs: int
    observedThroughput: float
    sourceEmissionRate: float
    currentParallelism: int
    currentBatchSize: int

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "DS2MetricsPayload":
        return DS2MetricsPayload(
            nodeIp                = d.get("nodeIp", ""),
            windowStartTimestamp  = d.get("windowStartTimestamp", 0),
            windowEndTimestamp    = d.get("windowEndTimestamp", 0),
            windowDurationMs      = d.get("windowDurationMs", 0),
            recordsProcessed      = d.get("recordsProcessed", 0),
            totalBusyTimeMs       = d.get("totalBusyTimeMs", 0),
            observedThroughput    = d.get("observedThroughput", 0.0),
            sourceEmissionRate    = d.get("sourceEmissionRate", 0.0),
            currentParallelism    = d.get("currentParallelism", 0),
            currentBatchSize      = d.get("currentBatchSize", 0),
        )


@dataclass
class DS2Decision:
    true_rate_per_subtask: float
    avg_utilization: float
    observed_throughput: float
    estimated_source_rate: float
    target_rate: float
    base_target_rate: float
    raw_optimal: float
    current_parallelism: int
    optimal_parallelism: int
    overload_detected: bool
    total_records: int
    total_busy_ms: int
    total_duration_ms: int
    windows_used: int


# ─── Job ID 管理 ───────────────────────────────────────────────────────────
def get_current_job_id() -> Optional[str]:
    with job_id_lock:
        return current_job_id


def set_current_job_id(job_id: Optional[str]) -> None:
    global current_job_id
    with job_id_lock:
        current_job_id = job_id
    logger.info(f"当前 Flink Job ID 已更新为: {job_id}")


def get_running_job_id_from_rest() -> Optional[str]:
    url = f"{FLINK_REST}/jobs"
    try:
        with urllib.request.urlopen(url, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        running = [j for j in data.get("jobs", []) if j.get("status") == "RUNNING"]
        if not running:
            logger.warning("未发现 RUNNING Job")
            return None
        if len(running) > 1:
            logger.warning(f"发现 {len(running)} 个 RUNNING Job，取第一个: {running[0]['id']}")
        return running[0]["id"]
    except Exception as e:
        logger.error(f"查询 Flink REST API 失败: {e}")
        return None


def is_job_running(job_id: str) -> bool:
    """检查指定 job 是否还处于 RUNNING（用于 rescale 前的健康检查）。"""
    if not job_id:
        return False
    url = f"{FLINK_REST}/jobs/{job_id}"
    try:
        with urllib.request.urlopen(url, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return data.get("state") == "RUNNING"
    except Exception as e:
        logger.warning(f"查询 job {job_id} 状态失败: {e}")
        return False


# ─── 看门狗 ────────────────────────────────────────────────────────────────
def update_heartbeat() -> None:
    global last_recv_time
    with heartbeat_lock:
        last_recv_time = time.time()


def watchdog() -> None:
    while True:
        time.sleep(WATCHDOG_CHECK_INTERVAL)
        if is_reconfiguring:
            update_heartbeat()
            continue
        with heartbeat_lock:
            idle = time.time() - last_recv_time
        if idle > TIMEOUT_SECONDS:
            logger.error(f"看门狗触发：已 {idle:.0f}s 未收到数据，Daemon 退出")
            decision_logger.event(
                "DAEMON_EXIT_BY_WATCHDOG",
                [f"idle_seconds={idle:.1f}", f"timeout={TIMEOUT_SECONDS}s"],
            )
            decision_logger.force_sync()
            os._exit(0)


# ============================================================================
# DS2 核心决策算法
# ============================================================================
def compute_ds2_decision(history: List[DS2MetricsPayload]) -> Optional[DS2Decision]:
    if not history:
        logger.debug("DS2: 无历史数据")
        decision_logger.event("DECISION_SKIPPED", ["reason=no_history"])
        return None

    if len(history) < DS2_MIN_WINDOWS_REQUIRED:
        msg = f"len(history)={len(history)} < MIN_WINDOWS_REQUIRED={DS2_MIN_WINDOWS_REQUIRED}"
        logger.debug(f"DS2: 历史窗口不足（{msg}），跳过")
        decision_logger.event("DECISION_SKIPPED",
                              ["reason=insufficient_windows", msg])
        return None

    total_records      = sum(p.recordsProcessed for p in history)
    total_busy_time_ms = sum(p.totalBusyTimeMs for p in history)
    total_duration_ms  = sum(p.windowDurationMs for p in history)

    if total_records <= 0 or total_busy_time_ms <= 0 or total_duration_ms <= 0:
        logger.debug(f"DS2: 关键指标为 0，跳过")
        decision_logger.event(
            "DECISION_SKIPPED",
            [
                "reason=zero_metrics",
                f"total_records={total_records}",
                f"total_busy_ms={total_busy_time_ms}",
                f"total_duration_ms={total_duration_ms}",
            ],
        )
        return None

    current_parallelism = history[-1].currentParallelism
    if current_parallelism <= 0:
        logger.warning("DS2: currentParallelism <= 0，跳过")
        decision_logger.event(
            "DECISION_SKIPPED",
            ["reason=invalid_parallelism", f"current_parallelism={current_parallelism}"],
        )
        return None

    avg_utilization   = total_busy_time_ms / (total_duration_ms * current_parallelism)
    busy_ratio_global = total_busy_time_ms / total_duration_ms

    if busy_ratio_global < DS2_MIN_BUSY_RATIO_FOR_DECISION:
        logger.info(
            f"DS2: 全局忙时占比 {busy_ratio_global:.4f} 过低，跳过本次决策"
        )
        decision_logger.event(
            "DECISION_SKIPPED",
            [
                "reason=operator_idle",
                f"busy_ratio_global={busy_ratio_global:.4f}",
                f"threshold={DS2_MIN_BUSY_RATIO_FOR_DECISION}",
                f"avg_utilization={avg_utilization:.4f}",
                f"total_records={total_records}",
                f"total_busy_ms={total_busy_time_ms}",
                f"total_duration_ms={total_duration_ms}",
                f"current_parallelism={current_parallelism}",
            ],
        )
        return None

    true_rate_per_subtask = total_records / (total_busy_time_ms / 1000.0)
    observed_throughput   = total_records / (total_duration_ms / 1000.0)
    source_rates          = [p.sourceEmissionRate for p in history if p.sourceEmissionRate > 0]
    estimated_source_rate = (sum(source_rates) / len(source_rates)) if source_rates else 0.0

    base_target = max(observed_throughput, estimated_source_rate)
    overload_detected = avg_utilization >= DS2_OVERLOAD_UTIL_THRESHOLD
    if overload_detected:
        target_rate = base_target * DS2_OVERLOAD_PROBE_FACTOR
        logger.warning(
            f"DS2: 检测到高利用率 {avg_utilization*100:.2f}% ≥ "
            f"{DS2_OVERLOAD_UTIL_THRESHOLD*100:.0f}%，启用过载试探"
        )
    else:
        target_rate = base_target

    raw_optimal = target_rate / (true_rate_per_subtask * DS2_TARGET_UTILIZATION)
    optimal_parallelism = max(
        DS2_MIN_PARALLELISM,
        min(DS2_MAX_PARALLELISM, int(math.ceil(raw_optimal))),
    )

    decision = DS2Decision(
        true_rate_per_subtask = true_rate_per_subtask,
        avg_utilization       = avg_utilization,
        observed_throughput   = observed_throughput,
        estimated_source_rate = estimated_source_rate,
        target_rate           = target_rate,
        base_target_rate      = base_target,
        raw_optimal           = raw_optimal,
        current_parallelism   = current_parallelism,
        optimal_parallelism   = optimal_parallelism,
        overload_detected     = overload_detected,
        total_records         = total_records,
        total_busy_ms         = total_busy_time_ms,
        total_duration_ms     = total_duration_ms,
        windows_used          = len(history),
    )

    logger.info(
        f"DS2 决策 | true_rate={true_rate_per_subtask:.4f} req/s/subtask | "
        f"util={avg_utilization*100:.2f}% | throughput={observed_throughput:.4f} req/s | "
        f"src_rate={estimated_source_rate:.4f} req/s | target={target_rate:.4f} req/s | "
        f"raw_optimal={raw_optimal:.2f} → optimal_p={optimal_parallelism} | "
        f"current_p={current_parallelism}"
    )

    decision_logger.event(
        "DECISION_COMPUTED",
        [
            f"windows_used={len(history)}",
            f"total_records={total_records}",
            f"total_busy_ms={total_busy_time_ms}",
            f"total_duration_ms={total_duration_ms}",
            f"avg_utilization={avg_utilization:.4f}  ({avg_utilization*100:.2f}%)",
            f"busy_ratio_global={busy_ratio_global:.4f}",
            f"true_rate_per_subtask={true_rate_per_subtask:.4f} req/s",
            f"observed_throughput={observed_throughput:.4f} req/s",
            f"estimated_source_rate={estimated_source_rate:.4f} req/s",
            f"base_target_rate={base_target:.4f} req/s",
            f"overload_detected={overload_detected}",
            f"effective_target_rate={target_rate:.4f} req/s "
            f"(factor={DS2_OVERLOAD_PROBE_FACTOR if overload_detected else 1.0})",
            f"raw_optimal={raw_optimal:.4f}",
            f"clamped_optimal_p={optimal_parallelism}  "
            f"(range=[{DS2_MIN_PARALLELISM},{DS2_MAX_PARALLELISM}])",
            f"current_parallelism={current_parallelism}",
        ],
    )
    return decision


def should_trigger_rescale(decision: DS2Decision) -> bool:
    elapsed_since_last = time.time() - last_reconfig_time
    if elapsed_since_last < DS2_COOLDOWN_SECONDS:
        logger.info(
            f"DS2: 冷却中（{elapsed_since_last:.1f}s < {DS2_COOLDOWN_SECONDS}s），跳过"
        )
        decision_logger.event(
            "RESCALE_SKIPPED",
            [
                "reason=cooldown",
                f"elapsed_since_last={elapsed_since_last:.1f}s",
                f"cooldown={DS2_COOLDOWN_SECONDS}s",
                f"current_p={decision.current_parallelism}",
                f"optimal_p={decision.optimal_parallelism}",
            ],
        )
        return False

    if decision.optimal_parallelism == decision.current_parallelism:
        logger.info("DS2: optimal == current，无需 rescale")
        decision_logger.event(
            "RESCALE_SKIPPED",
            [
                "reason=optimal_equals_current",
                f"current_p={decision.current_parallelism}",
                f"optimal_p={decision.optimal_parallelism}",
            ],
        )
        return False

    diff_ratio = abs(
        decision.optimal_parallelism - decision.current_parallelism
    ) / decision.current_parallelism
    if diff_ratio < DS2_SCALE_THRESHOLD:
        logger.info(
            f"DS2: 偏差 {diff_ratio*100:.2f}% < 阈值 {DS2_SCALE_THRESHOLD*100:.0f}%，跳过 rescale"
        )
        decision_logger.event(
            "RESCALE_SKIPPED",
            [
                "reason=below_hysteresis_threshold",
                f"diff_ratio={diff_ratio:.4f}  ({diff_ratio*100:.2f}%)",
                f"threshold={DS2_SCALE_THRESHOLD}  ({DS2_SCALE_THRESHOLD*100:.0f}%)",
                f"current_p={decision.current_parallelism}",
                f"optimal_p={decision.optimal_parallelism}",
            ],
        )
        return False

    logger.info(
        f"DS2: 触发 rescale | {decision.current_parallelism} → {decision.optimal_parallelism} "
        f"(偏差 {diff_ratio*100:.2f}%)"
    )
    decision_logger.event(
        "RESCALE_DECISION",
        [
            "decision=TRIGGER",
            f"current_p={decision.current_parallelism}",
            f"optimal_p={decision.optimal_parallelism}",
            f"diff_ratio={diff_ratio:.4f}  ({diff_ratio*100:.2f}%)",
            f"threshold={DS2_SCALE_THRESHOLD}",
            f"true_rate_per_subtask={decision.true_rate_per_subtask:.4f} req/s",
            f"target_rate={decision.target_rate:.4f} req/s",
            f"avg_utilization={decision.avg_utilization*100:.2f}%",
            f"overload_detected={decision.overload_detected}",
        ],
    )
    return True


# ─── 重配置流程 ───────────────────────────────────────────────────────────
def trigger_reconfiguration(
    history: List[DS2MetricsPayload],
    decision: DS2Decision,
    model_name: str,
) -> None:
    """
    完整的重配置流程（在独立线程中运行）。

    关键：
      - 在调用 rescale.sh 之前，先生成 rescale_seq 并广播 prepare_rescale 给所有
        已连接的 Sink，使 Sink 在下一次 snapshotState 写入的 PRE_SAVEPOINT
        CSV 行能携带相同的 rescale_seq；
      - rescale 失败也会更新 last_reconfig_time，让冷却机制对失败也生效；
      - 失败后强制刷新 current_job_id，避免拿着已 FINISHED 的旧 ID 死循环；
      - 在 TRIGGERED / SUCCESS / FAILED 三个时点向 RescaleEventLogger 写入 CSV 行；
      - 成功时通过 _parse_rescale_timings() 解析 rescale.sh 末尾打印的
        "Savepoint Time: X ms" / "Recovery Time: X ms" 等行（兼容老版本的
        "Stop+Savepoint Time" / "State Recovery Time" 写法）。
    """
    global is_reconfiguring, last_reconfig_time

    if not reconfiguration_lock.acquire(blocking=False):
        logger.warning("重配置正在进行中，忽略本次触发")
        decision_logger.event("RESCALE_SKIPPED", ["reason=already_reconfiguring"])
        return

    rescale_succeeded = False
    old_job_id_for_refresh: Optional[str] = None
    new_job_id: Optional[str] = None
    rescale_seq: int = 0          # 0 表示尚未分配（预检查阶段失败时仍为 0）
    broadcast_clients_ok: int = 0

    latest = history[-1]
    new_parallelism = decision.optimal_parallelism
    keep_batchsize  = latest.currentBatchSize

    diff_ratio = (
        abs(decision.optimal_parallelism - decision.current_parallelism)
        / decision.current_parallelism
        if decision.current_parallelism > 0
        else 0.0
    )

    # 公共字段：用于所有 rescale 事件 CSV 行
    base_event_fields: Dict[str, Any] = {
        "old_parallelism": decision.current_parallelism,
        "new_parallelism": new_parallelism,
        "batch_size": keep_batchsize,
        "true_rate_per_subtask": decision.true_rate_per_subtask,
        "avg_utilization": decision.avg_utilization,
        "observed_throughput": decision.observed_throughput,
        "source_rate": decision.estimated_source_rate,
        "base_target_rate": decision.base_target_rate,
        "effective_target_rate": decision.target_rate,
        "raw_optimal": decision.raw_optimal,
        "diff_ratio": diff_ratio,
        "overload_detected": decision.overload_detected,
        "windows_used": decision.windows_used,
        "total_records": decision.total_records,
        "total_busy_ms": decision.total_busy_ms,
        "total_duration_ms": decision.total_duration_ms,
    }

    try:
        is_reconfiguring = True

        logger.info("=" * 60)
        logger.info("DS2 重配置流程启动")
        logger.info(f"  当前并行度: {decision.current_parallelism}")
        logger.info(f"  目标并行度: {new_parallelism}")
        logger.info(f"  批次大小:   {keep_batchsize}（保持不变）")
        logger.info("=" * 60)

        # ========= 预检查 =========
        if not RESCALE_SCRIPT_PATH or not os.path.isfile(RESCALE_SCRIPT_PATH):
            logger.error(f"RESCALE_SCRIPT_PATH 无效: {RESCALE_SCRIPT_PATH}")
            decision_logger.event(
                "RESCALE_FAILED",
                ["stage=pre_check", f"reason=invalid_script_path:{RESCALE_SCRIPT_PATH}"],
            )
            rescale_event_logger.log("RESCALE_FAILED", {
                **base_event_fields,
                "rescale_seq": "",   # 预检查阶段还未分配 seq
                "old_job_id": get_current_job_id() or "",
                "reason": "invalid_script_path",
                "rescale_status": "PRECHECK_FAIL",
                "error_msg": f"invalid script path: {RESCALE_SCRIPT_PATH}",
            })
            return

        old_job_id = get_current_job_id()
        if not old_job_id:
            old_job_id = get_running_job_id_from_rest()
            if old_job_id:
                set_current_job_id(old_job_id)
        if not old_job_id:
            logger.error("无法获取当前 Job ID，重配置中止")
            decision_logger.event(
                "RESCALE_FAILED",
                ["stage=get_job_id", "reason=no_running_job_id"],
            )
            rescale_event_logger.log("RESCALE_FAILED", {
                **base_event_fields,
                "rescale_seq": "",
                "old_job_id": "",
                "reason": "no_running_job_id",
                "rescale_status": "PRECHECK_FAIL",
                "error_msg": "no running job id",
            })
            return

        # 健康检查：避免拿着已 FINISHED 的旧 ID 触发空 savepoint
        if not is_job_running(old_job_id):
            logger.warning(
                f"Job {old_job_id} 不再处于 RUNNING 状态，刷新 job_id 后重试本次决策"
            )
            decision_logger.event(
                "RESCALE_FAILED",
                ["stage=pre_check", f"reason=job_not_running:{old_job_id}"],
            )
            rescale_event_logger.log("RESCALE_FAILED", {
                **base_event_fields,
                "rescale_seq": "",
                "old_job_id": old_job_id,
                "reason": "job_not_running",
                "rescale_status": "PRECHECK_FAIL",
                "error_msg": f"job {old_job_id} not running",
            })
            old_job_id_for_refresh = old_job_id
            return

        old_job_id_for_refresh = old_job_id

        # ========= 分配 rescale_seq 并广播 prepare_rescale =========
        # 必须在 invoke rescale.sh 之前完成，让 Sink 端能把 seq 写入 PRE_SAVEPOINT 行
        rescale_seq = next_rescale_seq()
        broadcast_clients_ok = broadcast_prepare_rescale(
            rescale_seq=rescale_seq,
            reason="ds2_decision",
            decision=decision,
            old_job_id=old_job_id,
        )
        # 留出短暂时间让 Sink reader 线程消化消息（rescale.sh 触发的
        # stop-with-savepoint 通过 REST 还要走 JM 调度，绝对值这点 sleep
        # 完全在噪声范围内，不影响整体重配置耗时）
        time.sleep(0.3)

        decision_logger.event(
            "RESCALE_TRIGGERED",
            [
                f"rescale_seq={rescale_seq}",
                f"trigger_node_ip={latest.nodeIp}",
                f"current_p={decision.current_parallelism}",
                f"target_p={new_parallelism}",
                f"keep_batchsize={keep_batchsize}",
                f"true_rate_per_subtask={decision.true_rate_per_subtask:.4f} req/s",
                f"target_rate={decision.target_rate:.4f} req/s",
                f"avg_utilization={decision.avg_utilization*100:.2f}%",
                f"overload_detected={decision.overload_detected}",
                f"current_job_id={old_job_id}",
                f"broadcast_clients_ok={broadcast_clients_ok}",
            ],
        )
        decision_logger.force_sync()

        reconfig_start = time.time()

        # ========= TRIGGERED 事件（脚本调用之前） =========
        rescale_event_logger.log("RESCALE_TRIGGERED", {
            **base_event_fields,
            "rescale_seq": rescale_seq,
            "old_job_id": old_job_id,
            "reason": "ds2_decision",
            "rescale_status": "STARTED",
            "broadcast_clients_ok": broadcast_clients_ok,
        })

        # ========= 调用 rescale.sh =========
        cmd = [
            "bash", RESCALE_SCRIPT_PATH,
            "-j", old_job_id,
            "-p", str(new_parallelism),
            "-b", str(keep_batchsize),
            "-m", model_name,
            "-r", str(runtime_max_requests),
            "-i", str(runtime_base_interval),
            "-c", runtime_cache_type,
        ]
        if DEFAULT_JAR_PATH:
            cmd += ["-J", DEFAULT_JAR_PATH]

        logger.info(f"执行命令: {' '.join(cmd)}")
        decision_logger.event(
            "RESCALE_SCRIPT_INVOKED",
            [f"rescale_seq={rescale_seq}", f"old_job_id={old_job_id}", f"cmd={' '.join(cmd)}"],
        )

        stdout_lines: List[str] = []
        stderr_lines: List[str] = []
        proc_returncode: Optional[int] = None

        try:
            proc = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
            )
            assert proc.stdout is not None
            for line in proc.stdout:
                stripped = line.rstrip()
                stdout_lines.append(stripped)
                logger.info(f"[rescale.sh] {stripped}")

            try:
                proc.wait(timeout=RESCALE_SCRIPT_TIMEOUT)
                proc_returncode = proc.returncode
            except subprocess.TimeoutExpired:
                proc.kill()
                logger.error(f"rescale.sh 超时（{RESCALE_SCRIPT_TIMEOUT}s），已强杀")
                decision_logger.event(
                    "RESCALE_FAILED",
                    [
                        f"rescale_seq={rescale_seq}",
                        "stage=script_execution",
                        f"reason=timeout_{RESCALE_SCRIPT_TIMEOUT}s",
                    ],
                )
                rescale_event_logger.log("RESCALE_FAILED", {
                    **base_event_fields,
                    "rescale_seq": rescale_seq,
                    "old_job_id": old_job_id,
                    "reason": "script_timeout",
                    "rescale_status": "TIMEOUT",
                    "rescale_elapsed_ms": int((time.time() - reconfig_start) * 1000),
                    "broadcast_clients_ok": broadcast_clients_ok,
                    "error_msg": f"timeout_{RESCALE_SCRIPT_TIMEOUT}s",
                })
                return

            if proc.stderr:
                for line in proc.stderr:
                    stderr_lines.append(line.rstrip())

            if proc_returncode != 0:
                logger.error(
                    f"rescale.sh 失败 (rc={proc_returncode}): \n" + "\n".join(stderr_lines)
                )
                decision_logger.event(
                    "RESCALE_FAILED",
                    [
                        f"rescale_seq={rescale_seq}",
                        "stage=script_execution",
                        f"return_code={proc_returncode}",
                        "stderr_tail=" + " | ".join(stderr_lines[-5:])
                        if stderr_lines else "stderr=<empty>",
                    ],
                )
                rescale_event_logger.log("RESCALE_FAILED", {
                    **base_event_fields,
                    "rescale_seq": rescale_seq,
                    "old_job_id": old_job_id,
                    "reason": "script_nonzero_exit",
                    "rescale_status": f"EXIT_{proc_returncode}",
                    "rescale_elapsed_ms": int((time.time() - reconfig_start) * 1000),
                    "broadcast_clients_ok": broadcast_clients_ok,
                    "error_msg": " | ".join(stderr_lines[-5:]) or "<empty>",
                })
                return

        except FileNotFoundError:
            logger.error("未找到 bash 命令")
            decision_logger.event(
                "RESCALE_FAILED",
                [f"rescale_seq={rescale_seq}", "stage=script_execution", "reason=bash_not_found"],
            )
            rescale_event_logger.log("RESCALE_FAILED", {
                **base_event_fields,
                "rescale_seq": rescale_seq,
                "old_job_id": old_job_id,
                "reason": "bash_not_found",
                "rescale_status": "EXEC_ERROR",
                "broadcast_clients_ok": broadcast_clients_ok,
                "error_msg": "bash not found",
            })
            return
        except Exception as e:
            logger.error(f"调用 rescale.sh 异常: {e}", exc_info=True)
            decision_logger.event(
                "RESCALE_FAILED",
                [f"rescale_seq={rescale_seq}", "stage=script_execution",
                 f"exception={type(e).__name__}: {e}"],
            )
            rescale_event_logger.log("RESCALE_FAILED", {
                **base_event_fields,
                "rescale_seq": rescale_seq,
                "old_job_id": old_job_id,
                "reason": "script_exception",
                "rescale_status": "EXEC_ERROR",
                "broadcast_clients_ok": broadcast_clients_ok,
                "error_msg": f"{type(e).__name__}: {e}",
            })
            return

        # ========= 解析新 Job ID =========
        full_stdout = "\n".join(stdout_lines)
        match = re.search(r"New Job ID\s*:\s*([0-9a-fA-F]{32})", full_stdout)
        new_job_id = match.group(1) if match else None
        if new_job_id:
            set_current_job_id(new_job_id)
            logger.info(f"DS2 重配置成功，新 Job ID: {new_job_id}")
        else:
            logger.warning("无法从 rescale.sh 输出解析新 Job ID")

        # ========= 解析耗时（来自 rescale.sh 末尾的 stat 行） =========
        # 通过独立的 _parse_rescale_timings() 函数完成解析，兼容新旧两种关键字：
        #   新: "Savepoint Time: X ms"     / "Recovery Time: X ms"
        #   旧: "Stop+Savepoint Time: X ms" / "State Recovery Time: X ms"
        # 即使未来脚本输出有微调，只要保持 "...Time: <digit> ms" 的结构，
        # 在 _SAVEPOINT_KEYS / _RECOVERY_KEYS / _TOTAL_KEYS 中追加即可，无需改 invoke 处。
        stop_savepoint_ms, state_recovery_ms, timing_lines = _parse_rescale_timings(stdout_lines)

        for tl in timing_lines:
            logger.info(f"[rescale.sh 耗时] {tl}")

        # 如果脚本明明成功 (rc=0) 却没有解析到任何 savepoint/recovery 行，
        # 给出明显的 warning 便于及时发现脚本输出格式变更。
        if not stop_savepoint_ms or not state_recovery_ms:
            logger.warning(
                "rescale.sh 已成功 (rc=0)，但未从 stdout 解析到完整的 timing 行："
                f"stop_savepoint_ms='{stop_savepoint_ms}', "
                f"state_recovery_ms='{state_recovery_ms}', "
                f"timing_lines_count={len(timing_lines)}; "
                "请检查 rescale.sh 末尾的 echo 文案是否变化。"
            )

        elapsed = time.time() - reconfig_start
        logger.info(f"DS2 重配置完成，总耗时 {elapsed:.1f}s")

        decision_logger.event(
            "RESCALE_SUCCESS",
            [
                f"rescale_seq={rescale_seq}",
                f"old_job_id={old_job_id}",
                f"new_job_id={new_job_id or 'UNKNOWN'}",
                f"new_parallelism={new_parallelism}",
                f"batchsize={keep_batchsize}",
                f"total_elapsed_s={elapsed:.2f}",
                f"parsed_stop_savepoint_ms={stop_savepoint_ms or 'UNKNOWN'}",
                f"parsed_state_recovery_ms={state_recovery_ms or 'UNKNOWN'}",
                *([f"timing: {t}" for t in timing_lines] if timing_lines else []),
            ],
        )

        rescale_event_logger.log("RESCALE_SUCCESS", {
            **base_event_fields,
            "rescale_seq": rescale_seq,
            "old_job_id": old_job_id,
            "new_job_id": new_job_id or "",
            "reason": "ds2_decision",
            "rescale_status": "OK",
            "rescale_elapsed_ms": int(elapsed * 1000),
            "stop_savepoint_ms": stop_savepoint_ms,
            "state_recovery_ms": state_recovery_ms,
            "broadcast_clients_ok": broadcast_clients_ok,
        })

        update_heartbeat()
        decision_logger.force_sync()
        rescale_succeeded = True

    except Exception as e:
        logger.error(f"重配置流程未预期异常: {e}", exc_info=True)
        decision_logger.event(
            "RESCALE_FAILED",
            [f"rescale_seq={rescale_seq}", "stage=outer_handler",
             f"exception={type(e).__name__}: {e}"],
        )
        try:
            rescale_event_logger.log("RESCALE_FAILED", {
                **base_event_fields,
                "rescale_seq": rescale_seq if rescale_seq > 0 else "",
                "old_job_id": old_job_id_for_refresh or get_current_job_id() or "",
                "reason": "outer_exception",
                "rescale_status": "EXCEPTION",
                "broadcast_clients_ok": broadcast_clients_ok,
                "error_msg": f"{type(e).__name__}: {e}",
            })
        except Exception:
            pass
    finally:
        # 始终更新冷却时间（无论成败），避免失败死循环
        last_reconfig_time = time.time()
        is_reconfiguring = False
        reconfiguration_lock.release()

        # 失败时强制刷新 job_id，避免下次仍拿着旧 ID 触发空 savepoint
        if not rescale_succeeded:
            try:
                old_id = old_job_id_for_refresh or get_current_job_id()
                set_current_job_id(None)
                discovered = get_running_job_id_from_rest()
                if discovered:
                    set_current_job_id(discovered)
                    logger.warning(
                        f"rescale 失败后已重新发现 RUNNING job: {discovered} (was {old_id})"
                    )
                    decision_logger.event(
                        "JOB_ID_REFRESHED_AFTER_FAILURE",
                        [f"old_job_id={old_id}", f"new_job_id={discovered}"],
                    )
                else:
                    logger.warning(
                        f"rescale 失败后未发现任何 RUNNING job (was {old_id})；"
                        f"将等待 {DS2_COOLDOWN_SECONDS:.0f}s 后再决策"
                    )
                    decision_logger.event(
                        "JOB_ID_REFRESH_FAILED",
                        [f"old_job_id={old_id}", "reason=no_running_job"],
                    )
            except Exception as e:
                logger.error(f"刷新 job_id 异常: {e}", exc_info=True)

        decision_logger.force_sync()
        logger.info("DS2 重配置流程结束，锁已释放")


# ============================================================================
# TCP 连接处理
# ============================================================================
def _send_greeting(client_socket: socket.socket, addr: Tuple[str, int]) -> bool:
    greeting = {
        "type": "greeting",
        "session_id": DAEMON_SESSION_ID,
        "daemon_start_time_ms": int(DAEMON_START_TIME_TS * 1000),
        "daemon_start_iso": DAEMON_START_ISO,
        "monitor_log_hdfs": decision_logger.hdfs_path or "",
        "rescale_events_hdfs": rescale_event_logger.hdfs_path or "",
    }
    try:
        line = (json.dumps(greeting) + "\n").encode("utf-8")
        # 与 broadcast 共享发送锁，避免和并发广播交织字节
        with broadcast_send_lock:
            client_socket.sendall(line)
        logger.info(f"已向 {addr} 发送 greeting | session_id={DAEMON_SESSION_ID}")
        return True
    except Exception as e:
        logger.error(f"发送 greeting 给 {addr} 失败: {e}")
        return False


def handle_connection(
    client_socket: socket.socket,
    addr: Tuple[str, int],
    model_name: str,
) -> None:
    logger.info(f"接收到 Java Sink 新连接: {addr}")
    update_heartbeat()
    decision_logger.event(
        "SINK_CONNECTED",
        [
            f"remote_addr={addr[0]}:{addr[1]}",
            f"session_id={DAEMON_SESSION_ID}",
        ],
    )

    if not _send_greeting(client_socket, addr):
        try:
            client_socket.close()
        except Exception:
            pass
        return

    # 注册到广播列表，参与后续 prepare_rescale 广播
    register_client(client_socket, addr)

    try:
        with client_socket.makefile("r", encoding="utf-8") as reader:
            for line in reader:
                line = line.strip()
                if not line:
                    continue
                update_heartbeat()
                try:
                    raw_list = json.loads(line)
                    if not isinstance(raw_list, list):
                        logger.warning(f"收到非数组 JSON，已忽略: {raw_list!r}")
                        continue
                except json.JSONDecodeError as e:
                    logger.error(f"JSON 解析失败: {e}; line={line[:200]!r}")
                    continue

                try:
                    history: List[DS2MetricsPayload] = [
                        DS2MetricsPayload.from_dict(item)
                        for item in raw_list if isinstance(item, dict)
                    ]
                except Exception as e:
                    logger.error(f"DS2MetricsPayload 反序列化失败: {e}", exc_info=True)
                    continue

                if not history:
                    logger.debug("解析后无有效 payload，跳过")
                    continue

                latest = history[-1]
                logger.info(
                    f"收到 DS2 指标 from {addr[0]} | windows={len(history)} | "
                    f"latest: records={latest.recordsProcessed}, "
                    f"busy={latest.totalBusyTimeMs}ms, "
                    f"dur={latest.windowDurationMs}ms, "
                    f"throughput={latest.observedThroughput:.4f} req/s, "
                    f"src_rate={latest.sourceEmissionRate:.4f} req/s, "
                    f"p={latest.currentParallelism}, b={latest.currentBatchSize}"
                )

                decision_logger.event(
                    "METRICS_RECEIVED",
                    [
                        f"from={addr[0]}:{addr[1]}",
                        f"windows={len(history)}",
                        f"latest.records={latest.recordsProcessed}",
                        f"latest.busy_ms={latest.totalBusyTimeMs}",
                        f"latest.duration_ms={latest.windowDurationMs}",
                        f"latest.throughput={latest.observedThroughput:.4f}",
                        f"latest.src_rate={latest.sourceEmissionRate:.4f}",
                        f"latest.parallelism={latest.currentParallelism}",
                        f"latest.batchsize={latest.currentBatchSize}",
                        f"is_reconfiguring={is_reconfiguring}",
                    ],
                )

                if is_reconfiguring:
                    logger.debug("重配置进行中，本次指标仅刷新心跳，不参与决策")
                    decision_logger.event(
                        "DECISION_SKIPPED",
                        ["reason=is_reconfiguring"],
                    )
                    continue

                try:
                    decision = compute_ds2_decision(history)
                except Exception as e:
                    logger.error(f"DS2 决策计算异常: {e}", exc_info=True)
                    decision_logger.event(
                        "DECISION_SKIPPED",
                        ["reason=exception", f"exception={type(e).__name__}: {e}"],
                    )
                    continue

                if decision is None:
                    continue

                if not should_trigger_rescale(decision):
                    continue

                t = threading.Thread(
                    target=trigger_reconfiguration,
                    args=(history, decision, model_name),
                    name=f"DS2-Rescale-{int(time.time())}",
                    daemon=True,
                )
                t.start()

    except ConnectionResetError:
        logger.warning(f"连接被对端重置: {addr}")
        decision_logger.event("SINK_DISCONNECTED",
                              [f"remote_addr={addr[0]}:{addr[1]}", "reason=reset"])
    except Exception as e:
        logger.error(f"处理连接 {addr} 时异常: {e}", exc_info=True)
        decision_logger.event(
            "SINK_DISCONNECTED",
            [f"remote_addr={addr[0]}:{addr[1]}", f"exception={type(e).__name__}: {e}"],
        )
    finally:
        unregister_client(client_socket)
        try:
            client_socket.close()
        except Exception:
            pass
        logger.info(f"连接 {addr} 已关闭")


# ─── 主入口 ────────────────────────────────────────────────────────────────
def parse_cli_args() -> Dict[str, Any]:
    if len(sys.argv) < 4:
        print(
            "Usage: daemon_reconfiguration_monitor_ds2.py "
            "<nodeIP> <port> <model> [jobId] [maxRequests] [baseInterval] [cache] [SLO]",
            file=sys.stderr,
        )
        sys.exit(2)

    args: Dict[str, Any] = {
        "node_ip": sys.argv[1],
        "port": int(sys.argv[2]),
        "model": sys.argv[3],
        "job_id": sys.argv[4] if len(sys.argv) > 4 else None,
        "max_requests": int(sys.argv[5]) if len(sys.argv) > 5 else DEFAULT_MAX_REQUESTS,
        "base_interval": int(sys.argv[6]) if len(sys.argv) > 6 else DEFAULT_BASE_INTERVAL,
        "cache": sys.argv[7] if len(sys.argv) > 7 else DEFAULT_CACHE_TYPE,
        "slo_ms": float(sys.argv[8]) if len(sys.argv) > 8 else DEFAULT_SLO_MS,
    }
    return args


def setup_logger(node_ip: str, model: str) -> None:
    log_dir = "/tmp/ds2_daemon_logs"
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, f"ds2_daemon_{node_ip}_{model.replace('/', '_')}.log")

    logger.remove()
    fmt = ("<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | "
           "<level>{level: <7}</level> | "
           "<cyan>{thread.name}</cyan> | "
           "<level>{message}</level>")
    logger.add(sys.stderr, level="INFO", format=fmt, enqueue=False)
    logger.add(log_path, level="DEBUG", format=fmt,
               rotation="50 MB", retention=5, encoding="utf-8", enqueue=True)
    logger.info(f"日志文件: {log_path}")


def start_tcp_server(host: str, port: int, model_name: str) -> None:
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        server.bind((host, port))
    except OSError as e:
        logger.error(f"绑定 {host}:{port} 失败: {e}")
        sys.exit(1)
    server.listen(16)
    logger.info(f"DS2 Daemon TCP server 监听 {host}:{port}")

    while True:
        try:
            client_sock, addr = server.accept()
        except KeyboardInterrupt:
            logger.info("收到 KeyboardInterrupt，关闭 server")
            break
        except Exception as e:
            logger.error(f"accept 异常: {e}", exc_info=True)
            time.sleep(1)
            continue

        t = threading.Thread(
            target=handle_connection,
            args=(client_sock, addr, model_name),
            name=f"sink-conn-{addr[0]}:{addr[1]}",
            daemon=True,
        )
        t.start()

    try:
        server.close()
    except Exception:
        pass


def main() -> None:
    global runtime_max_requests, runtime_base_interval, runtime_cache_type, runtime_slo_ms

    args = parse_cli_args()
    setup_logger(args["node_ip"], args["model"])

    runtime_max_requests  = args["max_requests"]
    runtime_base_interval = args["base_interval"]
    runtime_cache_type    = args["cache"]
    runtime_slo_ms        = args["slo_ms"]

    if args["job_id"]:
        set_current_job_id(args["job_id"])
    else:
        discovered = get_running_job_id_from_rest()
        if discovered:
            set_current_job_id(discovered)

    decision_logger.init(args["model"])
    rescale_event_logger.init(args["model"])

    decision_logger.event(
        "DAEMON_STARTED",
        [
            f"node_ip={args['node_ip']}",
            f"port={args['port']}",
            f"model={args['model']}",
            f"job_id={get_current_job_id()}",
            f"max_requests={runtime_max_requests}",
            f"base_interval={runtime_base_interval}",
            f"cache={runtime_cache_type}",
            f"slo_ms={runtime_slo_ms}",
            f"session_id={DAEMON_SESSION_ID}",
        ],
    )

    rescale_event_logger.log("DAEMON_STARTED", {
        "rescale_seq": "",
        "old_job_id": get_current_job_id() or "",
        "reason": "daemon_init",
        "rescale_status": "INIT",
    })

    logger.info("=" * 60)
    logger.info("DS2 Daemon 启动")
    logger.info(f"  session_id:         {DAEMON_SESSION_ID}")
    logger.info(f"  node_ip:            {args['node_ip']}")
    logger.info(f"  port:               {args['port']}")
    logger.info(f"  model:              {args['model']}")
    logger.info(f"  job_id:             {get_current_job_id()}")
    logger.info(f"  decision_log_local: {decision_logger.local_path}")
    logger.info(f"  decision_log_hdfs:  {decision_logger.hdfs_path}")
    logger.info(f"  rescale_csv_local:  {rescale_event_logger.local_path}")
    logger.info(f"  rescale_csv_hdfs:   {rescale_event_logger.hdfs_path}")
    logger.info("=" * 60)

    update_heartbeat()
    threading.Thread(target=watchdog, name="ds2-watchdog", daemon=True).start()

    start_tcp_server("0.0.0.0", args["port"], args["model"])


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as e:
        logger.error(f"Daemon 主流程异常退出: {e}", exc_info=True)
        try:
            decision_logger.event(
                "DAEMON_CRASH",
                [f"exception={type(e).__name__}: {e}"],
            )
            decision_logger.force_sync()
        except Exception:
            pass
        try:
            rescale_event_logger.log("DAEMON_CRASH", {
                "rescale_seq": "",
                "old_job_id": get_current_job_id() or "",
                "reason": "daemon_crash",
                "rescale_status": "CRASH",
                "error_msg": f"{type(e).__name__}: {e}",
            })
        except Exception:
            pass
        sys.exit(1)
