package com.infertuner.sinks;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.infertuner.models.InferenceResponse;
import com.infertuner.utils.IPAddressUtil;
import org.apache.flink.api.common.state.ListState;
import org.apache.flink.api.common.state.ListStateDescriptor;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.runtime.state.FunctionInitializationContext;
import org.apache.flink.runtime.state.FunctionSnapshotContext;
import org.apache.flink.streaming.api.checkpoint.CheckpointedFunction;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * NJU Local Cache Test Sink for DS2 Auto-scaling.
 *
 * <p><b>本版本相对前版的关键改动：</b>
 * <ol>
 *   <li>保留 rescale_seq 关联键机制（与 daemon 的 prepare_rescale 消息联动）。</li>
 *   <li>保留 PRE_SAVEPOINT_WITH_SEQ / PRE_SAVEPOINT_SPONTANEOUS / COMPLETION 三种 epoch_type。</li>
 *   <li><b>修复 idle 超时过短导致提前终止统计的问题</b>。</li>
 *   <li><b>增加 completedRequestsTracker 完成检测</b>。</li>
 *   <li><b>新增 GPU Hours 指标</b>：在最终统计中新增 {@code gpu_hours} 字段，
 *       表示整个服务过程中所有 GPU 实际处于工作的总时间（单位：<b>Hour</b>）。
 *       计算方式：直接使用程序中已累计的 {@code gpuInferenceTime}（毫秒），
 *       即每个 batch 真正用于推理的耗时之和（在 invoke 中按 batch 累加，
 *       天然避开了 replay/重复 response 的重复计算），除以 3_600_000 得到小时数。
 *       该指标随每条 CsvHistoryRow（PRE_SAVEPOINT_* / COMPLETION）一同写入 CSV。</li>
 * </ol>
 */
public class NJULocalCacheTestAutoReconfigUniformRecorderSink
        extends RichSinkFunction<List<InferenceResponse>>
        implements CheckpointedFunction {

    private static final Logger LOG = LoggerFactory.getLogger(
            NJULocalCacheTestAutoReconfigUniformRecorderSink.class);

    // ==================== Daemon 进程与 TCP 通信 ====================

    private static final int    DAEMON_PORT              = 25589;
    private static final String DAEMON_HOST              = "127.0.0.1";
    private static final int    CONNECT_TIMEOUT_MS       = 2_000;
    private static final int    GREETING_READ_TIMEOUT_MS = 5_000;

    private static final int  REPORT_INTERVAL_MS    = 60_000;
    private static final int  REPORT_WINDOW_NUM     = 5;

    private static final int  RECONNECT_MAX_RETRIES    = 5;
    private static final long RECONNECT_RETRY_DELAY_MS = 500L;
    private static final long DAEMON_START_TIMEOUT_MS  = 10_000L;

    private static final String DAEMON_SCRIPT = "/mnt/code/daemon_reconfiguration_monitor_zerotune_recorder.py";
    private static final String PYTHON_PATH   = "/opt/flink-python-venv/bin/python";

    private transient Socket         socket;
    private transient PrintWriter    socketWriter;
    private transient BufferedReader socketReader;
    private transient Process        daemonProcess;
    private transient ObjectMapper   objectMapper;

    /** 后台 reader 线程，持续读取 daemon 推送（greeting / prepare_rescale）。 */
    private transient Thread daemonReaderThread;
    /**
     * socket 生命周期互斥锁。reader 线程仅读 BufferedReader，metrics scheduler 仅写
     * PrintWriter；二者 IO 方向互不冲突，但重连时需要互斥避免读到一半 socket 被换掉。
     */
    private transient Object socketLifecycleLock;

    /** Daemon greeting 中传回的 session_id；跨重配置不变。 */
    private transient String sessionId;

    // ─── Daemon 推送的 prepare_rescale 状态 ─────────────────────────────────
    /** 待写入下一次 PRE_SAVEPOINT 行的 rescale_seq；0 表示尚未收到通知。 */
    private volatile long   pendingRescaleSeq        = 0L;
    private volatile String pendingRescaleReason      = "";
    private volatile long   pendingRescaleIssuedAtMs  = 0L;
    private volatile int    pendingRescaleTargetP     = 0;

    // ==================== 状态存储 ====================

    private transient ListState<SinkSnapshot>         snapshotState;
    private transient ListState<Map<String, Integer>> latencyMapState;
    private transient ListState<Map<String, Integer>> cacheSizeMapState;
    private transient ListState<DS2MetricsPayload>    metricsHistoryState;
    private transient ListState<CsvHistoryRow>        csvHistoryState;

    private transient LinkedList<DS2MetricsPayload> metricsHistory;
    private transient ScheduledExecutorService      metricsScheduler;

    /** 内存中维护的历史 CSV 行（自 state 恢复 + 本 epoch 追加）。 */
    private transient List<CsvHistoryRow> csvHistoryRows;

    /** CSV 行序号；每次 appendStatsRowAndPersist 调用时 +1，跨 epoch 持久化恢复。 */
    private long epochSeq = 0L;

    // ==================== DS2 当前窗口计数器（线程安全） ====================

    private transient AtomicLong    windowRecordsCounter;
    private transient AtomicLong    windowBusyTimeMs;
    private transient AtomicLong    windowMinCreateTime;
    private transient AtomicLong    windowMaxCreateTime;
    private volatile  long          windowStartTime;

    private transient AtomicInteger windowTotalCounter;
    private transient AtomicInteger windowSuccessCounter;
    private transient AtomicInteger windowUnderSLOCounter;

    // ==================== 标量持久化状态 ====================

    public static class SinkSnapshot {
        public int     responseCounter;
        public int     cacheHitResponseCounter;
        public int     successResponseCounter;
        public int     underSLOResponseCounter;
        public int     underSLOMinus2sResponseCounter;
        public int     underSLOPlus2sResponseCounter;
        public int     underSLOPlus4sResponseCounter;
        public long    totalLatency;
        public long    totalWaitLatency;
        public long    totalInferenceLatency;
        public long    totalOtherLatency;
        public long    firstRequestTime;
        public long    lastRequestTime;
        public long    lastResponseTime;
        public long    gpuInferenceTime;
        public String  cacheStrategy;
        public boolean allRequestsEmitted;
        public boolean completionTriggered;

        public long windowRecordsSnapshot;
        public long windowBusyTimeMsSnapshot;
        public long windowMinCreateTimeSnapshot;
        public long windowMaxCreateTimeSnapshot;
        public long windowStartTimeSnapshot;

        public int windowTotalCounterSnapshot;
        public int windowSuccessCounterSnapshot;
        public int windowUnderSLOCounterSnapshot;

        /** 跨 epoch 单调递增的 CSV 行序号。 */
        public long epochSeq;

        /** 已收到但尚未写入 CSV 的 prepare_rescale 通知（跨 epoch 持久化，避免崩溃丢失）。 */
        public long   pendingRescaleSeq;
        public String pendingRescaleReason;
        public long   pendingRescaleIssuedAtMs;
        public int    pendingRescaleTargetP;

        public SinkSnapshot() {}
    }

    // ==================== CSV 历史行 ====================

    /**
     * 一条 CSV 历史行。每次 PRE_SAVEPOINT_* / COMPLETION 时 append 一条。
     *
     * <p><b>新增字段 {@link #gpuHours}</b>：GPU 实际工作总时长（单位：小时）。
     * 该字段对应于 {@code gpuInferenceTime}（累计推理毫秒数）/ 3_600_000，
     * 表示从 Sink 视角观测到的、所有 batch 真实推理耗时之和换算成的小时数。
     */
    public static class CsvHistoryRow implements Serializable {
        private static final long serialVersionUID = 4L; // bump serialVersionUID 反映 schema 变更

        public String sessionId;
        public long   epochSeq;
        public String epochType;
        public String eventTimeIso;

        // ─── rescale 关联键 ───────────────────────────────────────────────────
        public long   rescaleSeq;
        public String rescaleReason;
        public long   rescaleIssuedAtMs;
        public int    rescaleTargetP;

        public int    parallelism;
        public int    batchSize;
        public int    subtaskIndex;
        public long   reportTime;
        public double targetRate;
        public int    totalRequests;
        public int    successRequests;
        public double successRate;
        public int    underSLORequests;
        public double underSLORate;
        public int    cacheHitRequests;
        public double cacheHitRate;
        public int    totalCacheSize;
        public double throughputRps;
        public double avgLatencyMs;
        public double avgWaitMs;
        public double avgInferenceMs;
        public double avgOtherMs;
        public long   processingTimeMs;
        public String cacheStrategy;
        public int    p90LatencyMs;
        public int    p95LatencyMs;
        public int    p99LatencyMs;
        public double goodputRps;
        public double gpuUtilization;

        /**
         * 新增：GPU Hours 指标，单位为 <b>小时（Hour）</b>。
         * 计算方式：所有 batch 真实推理时间（毫秒）累加后除以 3_600_000。
         * 默认值 0.0 以保持反序列化向后兼容（旧 state 中无此字段时不会报错）。
         */
        public double gpuHours;

        public CsvHistoryRow() {}

        /** 序列化为一行 CSV（与 CSV_HEADER 顺序保持一致）。 */
        public String toCsvLine() {
            return String.join(",",
                    safe(sessionId),
                    String.valueOf(epochSeq),
                    safe(epochType),
                    safe(eventTimeIso),
                    String.valueOf(rescaleSeq),
                    safe(rescaleReason),
                    String.valueOf(rescaleIssuedAtMs),
                    String.valueOf(rescaleTargetP),
                    String.valueOf(parallelism),
                    String.valueOf(batchSize),
                    String.valueOf(subtaskIndex),
                    String.valueOf(reportTime),
                    String.format("%.4f", targetRate),
                    String.valueOf(totalRequests),
                    String.valueOf(successRequests),
                    String.format("%.4f", successRate),
                    String.valueOf(underSLORequests),
                    String.format("%.4f", underSLORate),
                    String.valueOf(cacheHitRequests),
                    String.format("%.4f", cacheHitRate),
                    String.valueOf(totalCacheSize),
                    String.format("%.4f", throughputRps),
                    String.format("%.2f", avgLatencyMs),
                    String.format("%.2f", avgWaitMs),
                    String.format("%.2f", avgInferenceMs),
                    String.format("%.2f", avgOtherMs),
                    String.valueOf(processingTimeMs),
                    safe(cacheStrategy),
                    String.valueOf(p90LatencyMs),
                    String.valueOf(p95LatencyMs),
                    String.valueOf(p99LatencyMs),
                    String.format("%.4f", goodputRps),
                    String.format("%.4f", gpuUtilization),
                    // 新增列：gpu_hours，单位 Hour，6 位小数以保留毫秒级精度
                    String.format("%.6f", gpuHours)
            );
        }

        private static String safe(String s) { return s == null ? "" : s; }
    }

    // ==================== DS2 上报 Payload ====================

    public static class DS2MetricsPayload {
        public String nodeIp;
        public long   windowStartTimestamp;
        public long   windowEndTimestamp;
        public long   windowDurationMs;
        public long   recordsProcessed;
        public long   totalBusyTimeMs;
        public double observedThroughput;
        public double sourceEmissionRate;
        public int    currentParallelism;
        public int    currentBatchSize;

        public DS2MetricsPayload() {}

        public DS2MetricsPayload(String nodeIp, long windowStart, long windowEnd,
                                 long records, long busyMs, double sourceRate,
                                 int parallelism, int batchSize) {
            this.nodeIp               = nodeIp;
            this.windowStartTimestamp = windowStart;
            this.windowEndTimestamp   = windowEnd;
            this.windowDurationMs     = windowEnd - windowStart;
            this.recordsProcessed     = records;
            this.totalBusyTimeMs      = busyMs;
            this.observedThroughput   = (windowDurationMs > 0)
                    ? records / (windowDurationMs / 1000.0) : 0.0;
            this.sourceEmissionRate   = sourceRate;
            this.currentParallelism   = parallelism;
            this.currentBatchSize     = batchSize;
        }
    }

    // ==================== 实例属性（业务统计） ====================

    private int    responseCounter;
    private int    cacheHitResponseCounter;
    private int    successResponseCounter;
    private int    underSLOResponseCounter;
    private int    underSLOMinus2sResponseCounter;
    private int    underSLOPlus2sResponseCounter;
    private int    underSLOPlus4sResponseCounter;

    private long   totalLatency;
    private long   totalWaitLatency;
    private long   totalInferenceLatency;
    private long   totalOtherLatency;
    private long   firstRequestTime;
    private long   lastRequestTime;
    private long   lastResponseTime;

    /**
     * GPU 累计推理时长（毫秒）。
     * 每个 batch 取该 batch 中任一 response 的 inferenceTimeMs 作为该 batch 的推理耗时，
     * 然后累加。invoke 中的去重逻辑保证 replay/重复 response 不会被重复计入。
     * <p>该字段是 GPU Hours 指标的核心数据源：gpuHours = gpuInferenceTime / 3_600_000。
     */
    private long   gpuInferenceTime;
    private String nodeIP;
    private String cacheStrategy;

    private Map<String, Integer> requestLatencyMap;
    private Map<String, Integer> nodeCacheSizeMap;

    // ==================== 全局参数 ====================

    private int     maxRequests;
    private int     parallelism;
    private int     batchsize;
    private int     SLO;
    private int     baseInterval;
    private String  llmModelName;
    private boolean enableLoadVariation;

    // ==================== CSV 表头 ====================

    /**
     * CSV 表头：与 {@link CsvHistoryRow#toCsvLine()} 中各字段输出顺序严格一致。
     * <b>末尾新增 gpu_hours 列</b>，对应 GPU 累计工作小时数。
     */
    private static final String[] CSV_HEADER = {
            "session_id", "epoch_seq", "epoch_type", "event_time_iso",
            "rescale_seq", "rescale_reason", "rescale_issued_at_ms", "rescale_target_p",
            "parallelism", "batch_size", "subtask_index", "report_time",
            "target_rate", "total_requests", "success_requests", "success_rate_pct",
            "under_SLO_requests", "under_SLO_rate_pct", "cache_hit_requests",
            "cache_hit_rate_pct", "total_cache_size", "throughput_rps", "avg_latency_ms",
            "avg_wait_ms", "avg_inference_ms", "avg_other_ms", "processing_time_sec",
            "cache_strategy", "P90_latency_ms", "P95_latency_ms", "P99_latency_ms",
            "goodput_rps", "gpu_utilization",
            // 新增列：GPU 累计工作小时数（单位：Hour）
            "gpu_hours"
    };

    private static final SimpleDateFormat ISO_FMT =
            new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");

    // ==================== HDFS ====================

    private transient FileSystem hdfs;
    private Path csvPath;

    private transient Path sourceCompletedMarkerPath;
    private transient Path sinkCompletedMarkerPath;

    private static final String HDFS_NAMENODE    = "hdfs://10.0.0.16:9090";
    private static final String HDFS_MARKER_BASE = HDFS_NAMENODE + "/tmp/job_markers";
    private static final String HDFS_SINK_BASE   = HDFS_NAMENODE + "/sink/cache_test";

    private static final long MONITOR_CHECK_INTERVAL_MS = 5_000L;

    /**
     * Source 发完标记出现后，Sink 等待上游"最后一批"结果的超时时间。
     */
    private static final long SHORT_IDLE_TIMEOUT_MS = 600_000L;

    /**
     * 绝对硬超时：若 Sink 自首次收到数据起超过此时长仍未完成，强制终止。
     */
    private static final long HARD_TIMEOUT_MS = 600_000L;

    private volatile long    lastReceiveTime;
    private volatile boolean allRequestsEmitted = false;
    private AtomicBoolean    isFinished = new AtomicBoolean(false);
    private transient Thread monitorThread;

    // =========================================================
    // open
    // =========================================================

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        this.lastReceiveTime     = System.currentTimeMillis();
        this.socketLifecycleLock = new Object();

        if (this.metricsHistory == null) {
            this.metricsHistory = new LinkedList<>();
        }
        if (this.csvHistoryRows == null) {
            this.csvHistoryRows = new ArrayList<>();
        }

        if (this.requestLatencyMap == null) {
            this.requestLatencyMap              = new ConcurrentHashMap<>();
            this.responseCounter                = 0;
            this.cacheHitResponseCounter        = 0;
            this.successResponseCounter         = 0;
            this.underSLOResponseCounter        = 0;
            this.underSLOMinus2sResponseCounter = 0;
            this.underSLOPlus2sResponseCounter  = 0;
            this.underSLOPlus4sResponseCounter  = 0;
            this.totalLatency                   = 0;
            this.totalWaitLatency               = 0;
            this.totalInferenceLatency          = 0;
            this.totalOtherLatency              = 0;
            this.gpuInferenceTime               = 0;
            this.firstRequestTime               = Long.MAX_VALUE;
            this.lastRequestTime                = -1;
            this.lastResponseTime               = -1;
            this.lastReceiveTime                = System.currentTimeMillis();
            this.cacheStrategy                  = "NONE";
            this.nodeCacheSizeMap               = new ConcurrentHashMap<>();
            this.isFinished.set(false);
        }

        if (this.windowRecordsCounter == null) {
            this.windowRecordsCounter  = new AtomicLong(0L);
            this.windowBusyTimeMs      = new AtomicLong(0L);
            this.windowMinCreateTime   = new AtomicLong(Long.MAX_VALUE);
            this.windowMaxCreateTime   = new AtomicLong(Long.MIN_VALUE);
            this.windowStartTime       = System.currentTimeMillis();
            this.windowTotalCounter    = new AtomicInteger(0);
            this.windowSuccessCounter  = new AtomicInteger(0);
            this.windowUnderSLOCounter = new AtomicInteger(0);
            LOG.info("DS2 Sink {} 窗口计数器初始化完成", nodeIP != null ? nodeIP : "unknown");
        }

        nodeIP = IPAddressUtil.getLocalHostIP();
        LOG.info("Sink 节点 IP 地址: {}", nodeIP);

        try {
            Map<String, String> globalParams = getRuntimeContext().getExecutionConfig()
                    .getGlobalJobParameters().toMap();
            if (globalParams.containsKey("batchsize"))           batchsize          = Integer.parseInt(globalParams.get("batchsize"));
            if (globalParams.containsKey("maxRequests"))         maxRequests        = Integer.parseInt(globalParams.get("maxRequests"));
            if (globalParams.containsKey("parallelism"))         parallelism        = Integer.parseInt(globalParams.get("parallelism"));
            if (globalParams.containsKey("baseInterval"))        baseInterval       = Integer.parseInt(globalParams.get("baseInterval"));
            if (globalParams.containsKey("model"))               llmModelName       = globalParams.get("model");
            if (globalParams.containsKey("enableLoadVariation")) enableLoadVariation = Boolean.parseBoolean(globalParams.get("enableLoadVariation"));
            if (globalParams.containsKey("cache"))               this.cacheStrategy = globalParams.get("cache");
            this.SLO = globalParams.containsKey("SLO") ? Integer.parseInt(globalParams.get("SLO")) : 10000;
            LOG.info("Sink 全局参数: maxRequests={}, parallelism={}, batchsize={}, SLO={}, "
                            + "baseInterval={}, model={}, cacheStrategy={}",
                    maxRequests, parallelism, batchsize, SLO, baseInterval, llmModelName, cacheStrategy);
        } catch (NumberFormatException e) {
            LOG.error("解析全局参数失败", e);
        }

        this.objectMapper = new ObjectMapper();
        connectOrStartDaemon();
        startDaemonReaderThread();
        startMetricsReporter();

        org.apache.hadoop.conf.Configuration hadoopConf = new org.apache.hadoop.conf.Configuration();
        hadoopConf.set("fs.defaultFS", HDFS_NAMENODE);
        hadoopConf.set("fs.hdfs.impl", "org.apache.hadoop.hdfs.DistributedFileSystem");
        hadoopConf.setBoolean("dfs.client.use.datanode.hostname", false);
        hadoopConf.setInt("dfs.client.socket-timeout", 300000);
        hadoopConf.setInt("dfs.socket.timeout", 300000);
        hadoopConf.setInt("ipc.client.connect.timeout", 300000);
        hadoopConf.setInt("ipc.client.connect.max.retries", 2);
        hadoopConf.setInt("dfs.client.block.write.retries", 3);
        hadoopConf.setBoolean("dfs.client.block.write.replace-datanode-on-failure.enable", true);
        hadoopConf.setInt("dfs.client.block.write.replace-datanode-on-failure.min-replication", 1);

        this.hdfs = FileSystem.newInstance(URI.create(HDFS_NAMENODE), hadoopConf);

        String modelDir = (this.llmModelName != null && !this.llmModelName.isEmpty())
                ? this.llmModelName : "unknown_model";
        Path dir = new Path(HDFS_SINK_BASE + "/" + modelDir + "/collector");
        if (!hdfs.exists(dir)) hdfs.mkdirs(dir);

        int subtaskIdx = getRuntimeContext().getIndexOfThisSubtask();
        String safeSessionId = (this.sessionId != null && !this.sessionId.isEmpty())
                ? this.sessionId : ("nosession_" + System.currentTimeMillis());
        csvPath = new Path(dir, String.format("session_%s_subtask_%d.csv", safeSessionId, subtaskIdx));
        LOG.info("CSV 统计文件路径(本 subtask 专用，每次 PRE_SAVEPOINT_*/COMPLETION 整文件覆盖): {}", csvPath);

        String jobId = generateJobId();
        Path markerDir = new Path(HDFS_MARKER_BASE, jobId);
        sourceCompletedMarkerPath = new Path(markerDir, "source_completed");
        sinkCompletedMarkerPath   = new Path(markerDir, "sink_completed");
        LOG.info("Sink marker paths: jobId={}, src={}, sink={}", jobId, sourceCompletedMarkerPath, sinkCompletedMarkerPath);

        startLifecycleMonitor();
    }

    // =========================================================
    // Daemon 连接管理
    // =========================================================

    private void readGreetingAndExtractSession() throws IOException {
        if (this.socket == null) throw new IOException("socket is null when reading greeting");
        int oldTimeout = this.socket.getSoTimeout();
        this.socket.setSoTimeout(GREETING_READ_TIMEOUT_MS);
        try {
            this.socketReader = new BufferedReader(new InputStreamReader(
                    this.socket.getInputStream(), StandardCharsets.UTF_8));
            String greetingLine = this.socketReader.readLine();
            if (greetingLine == null || greetingLine.isEmpty()) {
                throw new IOException("Daemon greeting is empty/EOF");
            }
            handleDaemonMessage(greetingLine);
            LOG.info("Daemon greeting line: {}", greetingLine);
        } finally {
            this.socket.setSoTimeout(0);
        }
    }

    /**
     * 处理来自 daemon 的一条 JSON 消息（greeting / prepare_rescale）。
     * 可由 open 阶段同步调用，也可由后台 reader 线程异步调用。
     */
    @SuppressWarnings("unchecked")
    private void handleDaemonMessage(String line) {
        if (line == null || line.isEmpty()) return;
        try {
            Map<String, Object> msg = this.objectMapper.readValue(line, Map.class);
            Object typeObj = msg.get("type");
            String type = typeObj == null ? "" : typeObj.toString();
            switch (type) {
                case "greeting": {
                    Object sid = msg.get("session_id");
                    if (sid != null) {
                        String newSessionId = sid.toString();
                        if (this.sessionId == null) {
                            this.sessionId = newSessionId;
                            LOG.info("Sink 已从 Daemon 获取 session_id={}", this.sessionId);
                        } else if (!this.sessionId.equals(newSessionId)) {
                            LOG.warn("Daemon 返回的 session_id 与之前不同（{} -> {}）；CSV 路径保持原值",
                                    this.sessionId, newSessionId);
                        }
                    } else {
                        LOG.warn("Daemon greeting 中未包含 session_id: {}", line);
                    }
                    break;
                }
                case "prepare_rescale": {
                    long   seq    = parseLong(msg.get("rescale_seq"), 0L);
                    String reason = msg.get("reason") == null ? "" : msg.get("reason").toString();
                    long   issued = parseLong(msg.get("issued_at_ms"), System.currentTimeMillis());
                    int    tp     = (int) parseLong(msg.get("target_parallelism"), 0L);
                    if (seq <= 0L) {
                        LOG.warn("收到 prepare_rescale 但 rescale_seq 非法: {}", line);
                        break;
                    }
                    if (seq <= this.pendingRescaleSeq) {
                        LOG.warn("收到的 prepare_rescale.seq={} 不大于已有 pendingRescaleSeq={}，忽略",
                                seq, this.pendingRescaleSeq);
                        break;
                    }
                    this.pendingRescaleSeq        = seq;
                    this.pendingRescaleReason     = reason;
                    this.pendingRescaleIssuedAtMs = issued;
                    this.pendingRescaleTargetP    = tp;
                    LOG.info("收到 prepare_rescale | seq={}, reason={}, target_p={}, issued_at_ms={}",
                            seq, reason, tp, issued);
                    break;
                }
                default:
                    LOG.warn("收到未知 type 的 daemon 消息: {}", line);
            }
        } catch (Exception e) {
            LOG.warn("解析 daemon 推送失败: {}; line={}", e.getMessage(), line);
        }
    }

    private static long parseLong(Object o, long defVal) {
        if (o == null) return defVal;
        if (o instanceof Number) return ((Number) o).longValue();
        try { return Long.parseLong(o.toString()); } catch (Exception e) { return defVal; }
    }

    /** 后台 reader 线程：持续从 socket 读取 daemon 推送（主要是 prepare_rescale）。 */
    private void startDaemonReaderThread() {
        Thread t = new Thread(() -> {
            BufferedReader localReader;
            synchronized (socketLifecycleLock) {
                localReader = this.socketReader;
            }
            if (localReader == null) {
                LOG.warn("daemon reader 线程启动时 socketReader 为 null，退出");
                return;
            }
            LOG.info("daemon reader 线程启动");
            try {
                String line;
                while (!Thread.currentThread().isInterrupted()
                        && (line = localReader.readLine()) != null) {
                    handleDaemonMessage(line);
                }
                LOG.info("daemon reader 线程正常退出（EOF）");
            } catch (IOException e) {
                LOG.warn("daemon reader 线程异常退出: {}", e.getMessage());
            } catch (Exception e) {
                LOG.error("daemon reader 线程未预期异常", e);
            }
        }, "daemon-reader-" + nodeIP);
        t.setDaemon(true);
        synchronized (socketLifecycleLock) {
            this.daemonReaderThread = t;
        }
        t.start();
    }

    private void connectOrStartDaemon() throws InterruptedException, IOException {
        boolean isConnected = false;
        int retryCount = 0;
        int maxRetries = 5;

        while (!isConnected && retryCount < maxRetries) {
            try {
                Socket newSocket = new Socket();
                newSocket.connect(new InetSocketAddress(DAEMON_HOST, DAEMON_PORT), CONNECT_TIMEOUT_MS);
                newSocket.setTcpNoDelay(true);
                synchronized (socketLifecycleLock) {
                    closeSocketSilentlyLocked();
                    this.socket       = newSocket;
                    this.socketWriter = new PrintWriter(
                            new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);
                }
                readGreetingAndExtractSession();
                isConnected = true;
                LOG.info("Sink {} 复用已存在的 DS2 Daemon 进程, sessionId={}", nodeIP, sessionId);
            } catch (IOException e) {
                retryCount++;
                synchronized (socketLifecycleLock) { closeSocketSilentlyLocked(); }
                if (retryCount < maxRetries) Thread.sleep(RECONNECT_RETRY_DELAY_MS);
                else LOG.warn("Sink {} 端口 {} 共 {} 次尝试失败，准备启动新 Daemon", nodeIP, DAEMON_PORT, maxRetries);
            }
        }
        if (isConnected) return;

        LOG.info("启动新的 DS2 Daemon 进程...");
        ProcessBuilder pb = new ProcessBuilder(
                PYTHON_PATH, DAEMON_SCRIPT, nodeIP,
                String.valueOf(DAEMON_PORT), llmModelName,
                getRuntimeContext().getJobId().toString(), String.valueOf(maxRequests),
                String.valueOf(baseInterval), cacheStrategy, String.valueOf(SLO));
        pb.redirectErrorStream(false);
        try {
            this.daemonProcess = pb.start();
        } catch (IOException e) {
            throw new RuntimeException("启动 Daemon 进程失败", e);
        }

        new Thread(() -> {
            try (BufferedReader errReader = new BufferedReader(
                    new InputStreamReader(daemonProcess.getErrorStream()))) {
                String line;
                while ((line = errReader.readLine()) != null) {
                    LOG.error("Daemon stderr: {}", line);
                }
            } catch (IOException ignored) {}
        }, "daemon-stderr-" + nodeIP).start();

        long startWait = System.currentTimeMillis();
        while (!isConnected) {
            try {
                Thread.sleep(500L);
                Socket newSocket = new Socket();
                newSocket.connect(new InetSocketAddress(DAEMON_HOST, DAEMON_PORT), CONNECT_TIMEOUT_MS);
                newSocket.setTcpNoDelay(true);
                synchronized (socketLifecycleLock) {
                    closeSocketSilentlyLocked();
                    this.socket       = newSocket;
                    this.socketWriter = new PrintWriter(
                            new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);
                }
                readGreetingAndExtractSession();
                isConnected = true;
                LOG.info("Sink {} 新 Daemon 启动并连接成功，耗时 {}ms, sessionId={}",
                        nodeIP, System.currentTimeMillis() - startWait, sessionId);
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                throw new RuntimeException("等待 Daemon 启动时被中断", ie);
            } catch (IOException ex) {
                synchronized (socketLifecycleLock) { closeSocketSilentlyLocked(); }
                if (System.currentTimeMillis() - startWait > DAEMON_START_TIMEOUT_MS) {
                    throw new RuntimeException("等待 Daemon 启动超时", ex);
                }
                if (!daemonProcess.isAlive()) {
                    throw new RuntimeException("Daemon 进程已退出", ex);
                }
            }
        }
    }

    private boolean reconnectToDaemon() {
        for (int attempt = 1; attempt <= RECONNECT_MAX_RETRIES; attempt++) {
            try {
                Socket newSocket = new Socket();
                newSocket.connect(new InetSocketAddress(DAEMON_HOST, DAEMON_PORT), CONNECT_TIMEOUT_MS);
                newSocket.setTcpNoDelay(true);
                synchronized (socketLifecycleLock) {
                    closeSocketSilentlyLocked();
                    this.socket       = newSocket;
                    this.socketWriter = new PrintWriter(
                            new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);
                }
                readGreetingAndExtractSession();
                startDaemonReaderThread();
                LOG.info("Sink {} 重连 Daemon 成功（第 {} 次），sessionId={}", nodeIP, attempt, sessionId);
                return true;
            } catch (IOException e) {
                LOG.warn("Sink {} 第 {}/{} 次重连失败: {}", nodeIP, attempt, RECONNECT_MAX_RETRIES, e.getMessage());
                synchronized (socketLifecycleLock) { closeSocketSilentlyLocked(); }
                if (attempt < RECONNECT_MAX_RETRIES) {
                    try { Thread.sleep(RECONNECT_RETRY_DELAY_MS); } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt(); return false;
                    }
                }
            }
        }
        synchronized (socketLifecycleLock) { closeSocketSilentlyLocked(); }
        return false;
    }

    /** 必须在持有 socketLifecycleLock 时调用。 */
    private void closeSocketSilentlyLocked() {
        try { if (socketWriter != null) socketWriter.close(); } catch (Exception ignored) {}
        try { if (socketReader != null) socketReader.close(); } catch (Exception ignored) {}
        try { if (socket != null && !socket.isClosed()) socket.close(); } catch (Exception ignored) {}
        socketWriter = null;
        socketReader = null;
        socket       = null;
    }

    // =========================================================
    // DS2 指标定时上报
    // =========================================================

    private void startMetricsReporter() {
        ThreadFactory factory = r -> {
            Thread t = new Thread(r, "DS2MetricsReporter-" + nodeIP);
            t.setDaemon(true);
            return t;
        };
        this.metricsScheduler = Executors.newSingleThreadScheduledExecutor(factory);
        this.metricsScheduler.scheduleAtFixedRate(() -> {
            try {
                doReportMetrics();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } catch (Exception e) {
                LOG.error("DS2 指标上报异常: {}", e.getMessage(), e);
            }
        }, REPORT_INTERVAL_MS, REPORT_INTERVAL_MS, TimeUnit.MILLISECONDS);
    }

    private void doReportMetrics() throws InterruptedException {
        if (this.isFinished.get()) return;

        long currentRecords   = windowRecordsCounter.getAndSet(0L);
        long currentBusyMs    = windowBusyTimeMs.getAndSet(0L);
        long currentMinCreate = windowMinCreateTime.getAndSet(Long.MAX_VALUE);
        long currentMaxCreate = windowMaxCreateTime.getAndSet(Long.MIN_VALUE);

        windowTotalCounter.set(0);
        windowSuccessCounter.set(0);
        windowUnderSLOCounter.set(0);

        long currentEndTime = System.currentTimeMillis();
        long durationMs     = currentEndTime - this.windowStartTime;

        double sourceRate;
        if (currentRecords > 1 && currentMaxCreate > currentMinCreate) {
            long createSpanMs = currentMaxCreate - currentMinCreate;
            sourceRate = createSpanMs > 1000
                    ? currentRecords / (createSpanMs / 1000.0)
                    : (durationMs > 0 ? currentRecords / (durationMs / 1000.0) : 0.0);
        } else {
            sourceRate = 0.0;
        }

        DS2MetricsPayload payload = new DS2MetricsPayload(
                this.nodeIP, this.windowStartTime, currentEndTime,
                currentRecords, currentBusyMs, sourceRate,
                parallelism, batchsize);

        LOG.info("DS2 窗口指标 | records={}, busy={}ms, duration={}ms, "
                        + "throughput={} req/s, sourceRate={} req/s, util={}, p={}, b={}",
                currentRecords, currentBusyMs, durationMs,
                String.format("%.4f", payload.observedThroughput),
                String.format("%.4f", sourceRate),
                String.format("%.4f", durationMs > 0
                        ? (double) currentBusyMs / durationMs / Math.max(1, parallelism) : 0.0),
                parallelism, batchsize);

        ensureSocketConnected();

        String jsonPayload;
        synchronized (metricsHistory) {
            metricsHistory.add(payload);
            if (metricsHistory.size() > REPORT_WINDOW_NUM) metricsHistory.removeFirst();
            try {
                jsonPayload = this.objectMapper.writeValueAsString(metricsHistory);
            } catch (JsonProcessingException e) {
                LOG.error("DS2 payload JSON 序列化失败", e);
                this.windowStartTime = currentEndTime;
                return;
            }
        }

        synchronized (socketLifecycleLock) {
            if (this.socketWriter != null && this.socket != null && !this.socket.isClosed()) {
                this.socketWriter.println(jsonPayload);
                if (this.socketWriter.checkError()) {
                    LOG.error("Sink {} 向 Daemon 发送 DS2 指标失败，关闭连接", nodeIP);
                    closeSocketSilentlyLocked();
                } else {
                    LOG.info("Sink {} 已发送 DS2 指标（共 {} 个窗口）", nodeIP, metricsHistory.size());
                }
            } else {
                LOG.warn("Sink {} Socket 不可用，本次上报跳过", nodeIP);
            }
        }

        this.windowStartTime = currentEndTime;
    }

    private void ensureSocketConnected() {
        boolean needReconnect;
        synchronized (socketLifecycleLock) {
            needReconnect = (socket == null || socket.isClosed() || socketWriter == null);
        }
        if (!needReconnect) return;
        LOG.warn("Sink {} Daemon Socket 不可用，触发重连...", nodeIP);
        reconnectToDaemon();
    }

    // =========================================================
    // invoke
    // =========================================================

    @Override
    public synchronized void invoke(
            List<InferenceResponse> batchedInferenceResponses,
            Context context) throws Exception {

        if (isFinished.get()) {
            return;
        }

        if (batchedInferenceResponses == null || batchedInferenceResponses.isEmpty()) {
            LOG.warn("Sink 收到空 response batch，跳过");
            return;
        }

        super.invoke(batchedInferenceResponses, context);

        long now = System.currentTimeMillis();
        lastReceiveTime = now;

        int uniqueInThisBatch = 0;

        for (InferenceResponse inferenceResponse : batchedInferenceResponses) {
            if (inferenceResponse == null) {
                LOG.warn("Sink 收到 null InferenceResponse，跳过");
                continue;
            }

            String requestId = inferenceResponse.getRequestId();
            if (requestId == null || requestId.isEmpty()) {
                LOG.warn("Sink 收到 requestId 为空的 response，跳过");
                continue;
            }

            int totalLatencyMs =
                    (int) (System.currentTimeMillis()
                            - inferenceResponse.getRequestCreatedTime());

            inferenceResponse.setTotalLatencyMs(totalLatencyMs);

            /*
             * 核心去重逻辑：
             * 必须先 putIfAbsent。
             * 只有该 requestId 第一次出现时，才能累计 responseCounter、latency、success、SLO 等指标。
             */
            Integer oldLatency =
                    this.requestLatencyMap.putIfAbsent(requestId, totalLatencyMs);

            if (oldLatency != null) {
                LOG.warn("Sink 收到重复 response，requestId={}，已有 latency={}ms，本次 latency={}ms，跳过统计",
                        requestId, oldLatency, totalLatencyMs);
                continue;
            }

            uniqueInThisBatch++;

            long requestCreatedTime = inferenceResponse.getRequestCreatedTime();

            firstRequestTime = Math.min(firstRequestTime, requestCreatedTime);
            lastRequestTime = Math.max(lastRequestTime, requestCreatedTime);
            lastResponseTime = Math.max(lastResponseTime, System.currentTimeMillis());

            this.totalWaitLatency += inferenceResponse.getWaitTimeMs();
            this.totalInferenceLatency += inferenceResponse.getInferenceTimeMs();
            this.totalLatency += inferenceResponse.getTotalLatencyMs();
            this.totalOtherLatency += inferenceResponse.getTotalLatencyMs()
                    - inferenceResponse.getElapsedPredictingTimeMs()
                    - inferenceResponse.getInferenceTimeMs();

            this.responseCounter++;

            windowRecordsCounter.incrementAndGet();

            windowMinCreateTime.updateAndGet(
                    prev -> Math.min(prev, requestCreatedTime)
            );
            windowMaxCreateTime.updateAndGet(
                    prev -> Math.max(prev, requestCreatedTime)
            );

            windowTotalCounter.incrementAndGet();

            if (inferenceResponse.isSuccess()) {
                this.successResponseCounter++;
                windowSuccessCounter.incrementAndGet();
            }

            if (inferenceResponse.isFromCache()) {
                this.cacheHitResponseCounter++;
            }

            String respCacheStrategy = inferenceResponse.getCacheStrategy();
            if (respCacheStrategy != null
                    && !respCacheStrategy.equals(this.cacheStrategy)) {
                this.cacheStrategy = respCacheStrategy;
            }

            if (inferenceResponse.getTotalLatencyMs() <= this.SLO) {
                this.underSLOResponseCounter++;
                windowUnderSLOCounter.incrementAndGet();
            }

            if (inferenceResponse.getTotalLatencyMs() <= this.SLO - 2000) {
                this.underSLOMinus2sResponseCounter++;
            }

            if (inferenceResponse.getTotalLatencyMs() <= this.SLO + 2000) {
                this.underSLOPlus2sResponseCounter++;
            }

            if (inferenceResponse.getTotalLatencyMs() <= this.SLO + 4000) {
                this.underSLOPlus4sResponseCounter++;
            }

            String respNodeIp = inferenceResponse.getNodeIP();
            if (respNodeIp != null) {
                this.nodeCacheSizeMap.compute(
                        respNodeIp,
                        (k, v) -> inferenceResponse.getCurrentCacheSize()
                );
            }
        }

        /*
         * GPU busy time 是 batch 级别指标。
         * 如果整个 batch 都是重复 replay，则不能重复累计。
         * 如果 batch 中至少有一个唯一 response，则累计一次该 batch 的 inferenceTimeMs。
         *
         * 这里累计的 gpuInferenceTime 同时是 GPU Hours 指标的数据源：
         *   gpuHours = gpuInferenceTime / 3_600_000.0
         */
        if (uniqueInThisBatch > 0) {
            long batchGpuMs = batchedInferenceResponses.get(0).getInferenceTimeMs();
            this.gpuInferenceTime += batchGpuMs;
            windowBusyTimeMs.addAndGet(batchGpuMs);
        }

        int uniqueResponses = this.requestLatencyMap.size();

        LOG.info("Sink 收到 response batch，batchSize={}，uniqueInBatch={}，uniqueTotal={}/{}",
                batchedInferenceResponses.size(),
                uniqueInThisBatch,
                uniqueResponses,
                maxRequests);

        /*
         * 完成判断必须基于唯一 request 数，而不是累计 responseCounter。
         */
        if (uniqueResponses >= maxRequests) {
            triggerCompletion("MAX_REQUESTS_REACHED");
        }
    }


    // =========================================================
    // close
    // =========================================================

    @Override
    public void close() throws Exception {
        LOG.info("Closing DS2 Sink...");

        if (metricsScheduler != null && !metricsScheduler.isShutdown()) {
            metricsScheduler.shutdownNow();
            metricsScheduler.awaitTermination(1, TimeUnit.SECONDS);
        }

        if (monitorThread != null && monitorThread.isAlive()) {
            monitorThread.interrupt();
        }

        Thread reader;
        synchronized (socketLifecycleLock) {
            reader = this.daemonReaderThread;
            // 先关 socket，用于打断 readLine()
            closeSocketSilentlyLocked();
        }

        if (reader != null && reader.isAlive()) {
            reader.interrupt();
            try {
                reader.join(1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        try {
            if (hdfs != null) {
                hdfs.close();
            }
        } catch (Exception e) {
            LOG.warn("关闭 HDFS 失败", e);
        }

        super.close();
    }


    // =========================================================
    // 生命周期监控、完成逻辑、统计输出
    // =========================================================

    private String generateJobId() {
        return String.format("%s_p%d_b%d", llmModelName, parallelism, batchsize);
    }

    private void startLifecycleMonitor() {
        monitorThread = new Thread(() -> {
            while (!Thread.currentThread().isInterrupted() && !isFinished.get()) {
                try {
                    long currentTime = System.currentTimeMillis();
                    long idleTime    = currentTime - lastReceiveTime;

                    if (idleTime > HARD_TIMEOUT_MS) {
                        triggerCompletion("HARD_TIMEOUT");
                        break;
                    }

                    if (!allRequestsEmitted && hdfs.exists(sourceCompletedMarkerPath)) {
                        allRequestsEmitted = true;
                        LOG.info("Sink 检测到 Source 完成标记，进入 idle 等待阶段（超时 {}ms）",
                                SHORT_IDLE_TIMEOUT_MS);
                    }

                    if (allRequestsEmitted && idleTime > SHORT_IDLE_TIMEOUT_MS) {
                        triggerCompletion("SOURCE_DONE_IDLE");
                        break;
                    }

                    Thread.sleep(MONITOR_CHECK_INTERVAL_MS);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                } catch (IOException e) {
                    LOG.warn("HDFS markers 检查失败: {}", e.getMessage());
                } catch (Exception e) {
                    LOG.error("monitor 线程异常", e);
                }
            }
        }, "SinkLifecycleMonitor");
        monitorThread.setDaemon(true);
        monitorThread.start();
    }

    private void triggerCompletion(String reason) {
        if (isFinished.compareAndSet(false, true)) {
            LOG.info("Triggering completion. Reason: {}", reason);
            try {
                outputAndSaveResults();
                createSinkCompletionMarker(reason);
            } catch (Exception e) {
                LOG.error("完成处理异常", e);
            }
        }
    }

    private void createSinkCompletionMarker(String reason) throws IOException {
        int maxRetries = 3;
        IOException lastException = null;
        for (int retryCount = 0; retryCount < maxRetries; retryCount++) {
            try {
                Path markerDir = sinkCompletedMarkerPath.getParent();
                if (!hdfs.exists(markerDir)) hdfs.mkdirs(markerDir);
                try (FSDataOutputStream out = hdfs.create(sinkCompletedMarkerPath, true)) {
                    String content = String.format("Completed: %d\nHost: %s\nResponses: %d\nReason: %s\n",
                            System.currentTimeMillis(), nodeIP, responseCounter, reason);
                    out.write(content.getBytes(StandardCharsets.UTF_8));
                    out.flush(); out.hflush();
                }
                if (hdfs.exists(sinkCompletedMarkerPath)) return;
                throw new IOException("marker 创建后未发现");
            } catch (IOException e) {
                lastException = e;
                if (retryCount + 1 < maxRetries) {
                    try { Thread.sleep(1000L * (retryCount + 1)); } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt(); break;
                    }
                }
            }
        }
        throw new IOException("marker 创建失败", lastException);
    }

    /**
     * Sink 真正完成时调用：追加一条 epoch_type=COMPLETION 的 CSV 行并写出整文件。
     * COMPLETION 行不携带 rescale_seq。
     */
    public void outputAndSaveResults() throws IOException {
        appendStatsRowAndPersist("COMPLETION", 0L, "", 0L, 0);
    }

    /**
     * 基于当前累计统计构建一行 CsvHistoryRow（纯只读快照）。
     *
     * <p>新增逻辑：根据已累计的 {@code gpuInferenceTime}（毫秒）计算 GPU Hours：
     * {@code gpuHours = gpuInferenceTime / 3_600_000.0}，单位为小时。
     */
    private CsvHistoryRow buildCurrentStatsRow(String epochType, long seq,
                                               long rescaleSeq, String rescaleReason,
                                               long rescaleIssuedAtMs, int rescaleTargetP) {
        double avgLatency          = responseCounter > 0 ? (double) totalLatency / responseCounter : 0.0;
        double avgWaitLatency      = responseCounter > 0 ? (double) totalWaitLatency / responseCounter : 0.0;
        double avgInferenceLatency = responseCounter > 0 ? (double) totalInferenceLatency / responseCounter : 0.0;
        double avgOtherLatency     = responseCounter > 0 ? (double) totalOtherLatency / responseCounter : 0.0;
        long   processDuration     = lastResponseTime > 0 && firstRequestTime < Long.MAX_VALUE
                ? lastResponseTime - firstRequestTime : 0;
        double gpuUtilization = processDuration > 0
                ? (double) gpuInferenceTime / processDuration / Math.max(1, parallelism) : 0.0;
        double targetRate  = firstRequestTime > 0 && firstRequestTime < Long.MAX_VALUE && lastRequestTime > 0
                ? (double) responseCounter / Math.max(1.0, (lastRequestTime - firstRequestTime) / 1000.0) : 0.0;
        double throughput  = processDuration > 0 ? (double) successResponseCounter / (processDuration / 1000.0) : 0.0;
        double hitRate     = responseCounter > 0 ? (double) cacheHitResponseCounter / responseCounter : 0.0;
        double successRate = responseCounter > 0 ? (double) successResponseCounter / responseCounter : 0.0;
        double underSLORate = responseCounter > 0 ? (double) underSLOResponseCounter / responseCounter : 0.0;
        double goodPut     = responseCounter > 0 ? underSLORate * throughput : 0.0;
        int    totalCacheSize = nodeCacheSizeMap.values().stream().mapToInt(Integer::intValue).sum();

        // ─── GPU Hours 计算 ────────────────────────────────────────────────
        // gpuInferenceTime 是所有 batch 真实推理耗时（毫秒）之和，已在 invoke 中
        // 通过 uniqueInThisBatch 去重保证，replay 的 batch 不会被重复累计。
        // 1 小时 = 3_600_000 毫秒。
        double gpuHoursValue = gpuInferenceTime / 3_600_000.0;

        List<Integer> latencies = new ArrayList<>(requestLatencyMap.values());
        Collections.sort(latencies);
        int p90 = percentile(latencies, 90);
        int p95 = percentile(latencies, 95);
        int p99 = percentile(latencies, 99);

        int    subtaskIndex  = getRuntimeContext().getIndexOfThisSubtask();
        long   reportTime    = System.currentTimeMillis();
        String safeSessionId = (this.sessionId != null && !this.sessionId.isEmpty())
                ? this.sessionId : "nosession";

        CsvHistoryRow row = new CsvHistoryRow();
        row.sessionId         = safeSessionId;
        row.epochSeq          = seq;
        row.epochType         = epochType;
        row.eventTimeIso      = ISO_FMT.format(new Date(reportTime));
        row.rescaleSeq        = rescaleSeq;
        row.rescaleReason     = rescaleReason == null ? "" : rescaleReason;
        row.rescaleIssuedAtMs = rescaleIssuedAtMs;
        row.rescaleTargetP    = rescaleTargetP;
        row.parallelism       = parallelism;
        row.batchSize         = batchsize;
        row.subtaskIndex      = subtaskIndex;
        row.reportTime        = reportTime;
        row.targetRate        = targetRate;
        row.totalRequests     = responseCounter;
        row.successRequests   = successResponseCounter;
        row.successRate       = successRate;
        row.underSLORequests  = underSLOResponseCounter;
        row.underSLORate      = underSLORate;
        row.cacheHitRequests  = cacheHitResponseCounter;
        row.cacheHitRate      = hitRate;
        row.totalCacheSize    = totalCacheSize;
        row.throughputRps     = throughput;
        row.avgLatencyMs      = avgLatency;
        row.avgWaitMs         = avgWaitLatency;
        row.avgInferenceMs    = avgInferenceLatency;
        row.avgOtherMs        = avgOtherLatency;
        row.processingTimeMs  = processDuration;
        row.cacheStrategy     = this.cacheStrategy;
        row.p90LatencyMs      = p90;
        row.p95LatencyMs      = p95;
        row.p99LatencyMs      = p99;
        row.goodputRps        = goodPut;
        row.gpuUtilization    = gpuUtilization;
        // 新增字段：GPU Hours，单位为小时
        row.gpuHours          = gpuHoursValue;
        return row;
    }

    /**
     * 追加一条 CsvHistoryRow 到 csvHistoryRows 并整文件覆盖写出 CSV。
     * epochSeq 在此处自增，调用顺序保证 CSV 行序号单调递增。
     */
    private synchronized void appendStatsRowAndPersist(String epochType,
                                                       long rescaleSeq,
                                                       String rescaleReason,
                                                       long rescaleIssuedAtMs,
                                                       int rescaleTargetP) throws IOException {
        if (this.csvHistoryRows == null) this.csvHistoryRows = new ArrayList<>();

        this.epochSeq += 1L;
        CsvHistoryRow row = buildCurrentStatsRow(epochType, this.epochSeq,
                rescaleSeq, rescaleReason, rescaleIssuedAtMs, rescaleTargetP);
        this.csvHistoryRows.add(row);

        LOG.info("==== Sink Stats Snapshot [{}] ==== session={}, epochSeq={}, "
                        + "rescale_seq={}, rescale_reason='{}', target_p={}, "
                        + "p={}, b={}, subtask={}, total={}, success={}({}%), "
                        + "under_SLO={}({}%), throughput={}rps, goodput={}rps, "
                        + "gpu_util={}%, gpu_hours={}h, p90={}, p95={}, p99={}",
                epochType, row.sessionId, row.epochSeq,
                row.rescaleSeq, row.rescaleReason, row.rescaleTargetP,
                row.parallelism, row.batchSize, row.subtaskIndex,
                row.totalRequests, row.successRequests,
                String.format("%.2f", row.successRate * 100),
                row.underSLORequests, String.format("%.2f", row.underSLORate * 100),
                String.format("%.4f", row.throughputRps),
                String.format("%.4f", row.goodputRps),
                String.format("%.2f", row.gpuUtilization * 100),
                String.format("%.6f", row.gpuHours),
                row.p90LatencyMs, row.p95LatencyMs, row.p99LatencyMs);

        writeFullCsvOverwrite();
    }

    /**
     * 把内存中的 csvHistoryRows 全部覆盖写入 CSV 文件（header + N 行），多次重试。
     */
    private void writeFullCsvOverwrite() throws IOException {
        if (hdfs == null) {
            LOG.warn("HDFS 未初始化，跳过 CSV 写入");
            return;
        }
        int maxAttempts = 5;
        IOException last = null;
        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            try (FSDataOutputStream out = hdfs.create(csvPath, true);
                 BufferedWriter writer = new BufferedWriter(
                         new OutputStreamWriter(out, StandardCharsets.UTF_8))) {
                writer.write(String.join(",", CSV_HEADER));
                writer.newLine();
                for (CsvHistoryRow r : csvHistoryRows) {
                    writer.write(r.toCsvLine());
                    writer.newLine();
                }
                writer.flush();
                LOG.info("CSV 整文件覆盖写入成功 (attempt {}, {} rows): {}", attempt, csvHistoryRows.size(), csvPath);
                return;
            } catch (IOException e) {
                last = e;
                LOG.warn("CSV overwrite 失败 (attempt {}/{}): {}", attempt, maxAttempts, e.getMessage());
                try { Thread.sleep(500L * attempt); } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }
        if (last != null) {
            LOG.error("CSV overwrite 多次重试仍失败: {}", csvPath, last);
            throw last;
        }
    }

    private static int percentile(List<Integer> sortedList, double percentile) {
        if (sortedList == null || sortedList.isEmpty()) return 0;
        int index = (int) Math.ceil(percentile / 100.0 * sortedList.size()) - 1;
        return sortedList.get(Math.min(index, sortedList.size() - 1));
    }

    // =========================================================
    // CheckpointedFunction
    // =========================================================

    /**
     * 在写入 state 之前，先追加一条 PRE_SAVEPOINT_* CSV 行并写出整文件。
     * 区分 PRE_SAVEPOINT_WITH_SEQ（daemon 已发 prepare_rescale）和
     * PRE_SAVEPOINT_SPONTANEOUS（普通 checkpoint）两种情况。
     */
    @Override
    public void snapshotState(FunctionSnapshotContext context) throws Exception {
        if (!this.isFinished.get()) {
            try {
                long   seq    = this.pendingRescaleSeq;
                String reason = this.pendingRescaleReason;
                long   issued = this.pendingRescaleIssuedAtMs;
                int    tp     = this.pendingRescaleTargetP;

                if (seq > 0L) {
                    appendStatsRowAndPersist("PRE_SAVEPOINT_WITH_SEQ", seq, reason, issued, tp);
                    LOG.info("snapshotState 写入 PRE_SAVEPOINT_WITH_SEQ | seq={}, reason={}", seq, reason);
                    // 消费掉 pending，下次 snapshot 不再重复带这个 seq
                    this.pendingRescaleSeq        = 0L;
                    this.pendingRescaleReason     = "";
                    this.pendingRescaleIssuedAtMs = 0L;
                    this.pendingRescaleTargetP    = 0;
                } else {
                    appendStatsRowAndPersist("PRE_SAVEPOINT_SPONTANEOUS", 0L, "", 0L, 0);
                    LOG.info("snapshotState 写入 PRE_SAVEPOINT_SPONTANEOUS（未收到 daemon prepare_rescale）");
                }
            } catch (Exception e) {
                LOG.error("snapshotState 写入 PRE_SAVEPOINT_* 行失败 (continue snapshot anyway)", e);
            }
        } else {
            LOG.info("snapshotState: sink 已 COMPLETION，跳过 PRE_SAVEPOINT_* 写入");
        }

        snapshotState.clear();
        SinkSnapshot snapshot = new SinkSnapshot();
        snapshot.responseCounter =
                this.requestLatencyMap == null
                        ? this.responseCounter
                        : this.requestLatencyMap.size();
        snapshot.cacheHitResponseCounter        = this.cacheHitResponseCounter;
        snapshot.successResponseCounter         = this.successResponseCounter;
        snapshot.underSLOResponseCounter        = this.underSLOResponseCounter;
        snapshot.underSLOMinus2sResponseCounter = this.underSLOMinus2sResponseCounter;
        snapshot.underSLOPlus2sResponseCounter  = this.underSLOPlus2sResponseCounter;
        snapshot.underSLOPlus4sResponseCounter  = this.underSLOPlus4sResponseCounter;
        snapshot.totalLatency                   = this.totalLatency;
        snapshot.totalWaitLatency               = this.totalWaitLatency;
        snapshot.totalInferenceLatency          = this.totalInferenceLatency;
        snapshot.totalOtherLatency              = this.totalOtherLatency;
        snapshot.firstRequestTime               = this.firstRequestTime;
        snapshot.lastRequestTime                = this.lastRequestTime;
        snapshot.lastResponseTime               = this.lastResponseTime;
        snapshot.gpuInferenceTime               = this.gpuInferenceTime;
        snapshot.cacheStrategy                  = this.cacheStrategy;
        snapshot.allRequestsEmitted             = this.allRequestsEmitted;
        snapshot.completionTriggered            = this.isFinished.get();

        snapshot.windowRecordsSnapshot          = windowRecordsCounter   != null ? windowRecordsCounter.get()   : 0L;
        snapshot.windowBusyTimeMsSnapshot       = windowBusyTimeMs       != null ? windowBusyTimeMs.get()       : 0L;
        snapshot.windowMinCreateTimeSnapshot    = windowMinCreateTime    != null ? windowMinCreateTime.get()    : Long.MAX_VALUE;
        snapshot.windowMaxCreateTimeSnapshot    = windowMaxCreateTime    != null ? windowMaxCreateTime.get()    : Long.MIN_VALUE;
        snapshot.windowStartTimeSnapshot        = this.windowStartTime;

        snapshot.windowTotalCounterSnapshot     = windowTotalCounter    != null ? windowTotalCounter.get()    : 0;
        snapshot.windowSuccessCounterSnapshot   = windowSuccessCounter  != null ? windowSuccessCounter.get()  : 0;
        snapshot.windowUnderSLOCounterSnapshot  = windowUnderSLOCounter != null ? windowUnderSLOCounter.get() : 0;

        snapshot.epochSeq                       = this.epochSeq;

        snapshot.pendingRescaleSeq              = this.pendingRescaleSeq;
        snapshot.pendingRescaleReason           = this.pendingRescaleReason;
        snapshot.pendingRescaleIssuedAtMs       = this.pendingRescaleIssuedAtMs;
        snapshot.pendingRescaleTargetP          = this.pendingRescaleTargetP;

        snapshotState.add(snapshot);

        latencyMapState.clear();
        latencyMapState.add(new HashMap<>(this.requestLatencyMap));
        cacheSizeMapState.clear();
        cacheSizeMapState.add(new HashMap<>(this.nodeCacheSizeMap));

        metricsHistoryState.clear();
        if (this.metricsHistory != null) {
            synchronized (metricsHistory) {
                metricsHistoryState.addAll(this.metricsHistory);
            }
        }

        csvHistoryState.clear();
        if (this.csvHistoryRows != null && !this.csvHistoryRows.isEmpty()) {
            csvHistoryState.addAll(this.csvHistoryRows);
        }

        LOG.info("snapshotState 完成: responseCounter={}, csvHistoryRows={}, epochSeq={}, "
                        + "pendingRescaleSeq={}, gpuInferenceTimeMs={}, gpuHours={}",
                responseCounter,
                csvHistoryRows == null ? 0 : csvHistoryRows.size(),
                epochSeq, pendingRescaleSeq,
                gpuInferenceTime,
                String.format("%.6f", gpuInferenceTime / 3_600_000.0));
    }

    @Override
    public void initializeState(FunctionInitializationContext context) throws Exception {
        ListStateDescriptor<SinkSnapshot> snapshotDesc = new ListStateDescriptor<>(
                "sink-snapshot-state", SinkSnapshot.class);
        snapshotState = context.getOperatorStateStore().getListState(snapshotDesc);

        ListStateDescriptor<Map<String, Integer>> latencyMapDesc = new ListStateDescriptor<>(
                "latency-map-state", TypeInformation.of(new TypeHint<>() {
        }));
        latencyMapState = context.getOperatorStateStore().getListState(latencyMapDesc);

        ListStateDescriptor<Map<String, Integer>> cacheSizeMapDesc = new ListStateDescriptor<>(
                "cache-size-map-state", TypeInformation.of(new TypeHint<>() {
        }));
        cacheSizeMapState = context.getOperatorStateStore().getListState(cacheSizeMapDesc);

        ListStateDescriptor<DS2MetricsPayload> metricsHistoryDesc = new ListStateDescriptor<>(
                "ds2-metrics-history-state", DS2MetricsPayload.class);
        metricsHistoryState = context.getOperatorStateStore().getListState(metricsHistoryDesc);

        ListStateDescriptor<CsvHistoryRow> csvHistoryDesc = new ListStateDescriptor<>(
                "csv-history-state", CsvHistoryRow.class);
        csvHistoryState = context.getOperatorStateStore().getListState(csvHistoryDesc);

        if (this.metricsHistory == null)  this.metricsHistory  = new LinkedList<>();
        if (this.csvHistoryRows == null)  this.csvHistoryRows  = new ArrayList<>();

        if (context.isRestored()) {
            LOG.info("Restoring DS2 Sink State ...");
            this.isFinished = new AtomicBoolean(false);

            SinkSnapshot lastSnapshot = null;
            int snapshotCount = 0;
            long maxEpochSeq          = 0L;
            long maxPendingRescaleSeq = 0L;
            String mergedPendingReason  = "";
            long   mergedPendingIssued  = 0L;
            int    mergedPendingTargetP = 0;

            for (SinkSnapshot s : snapshotState.get()) {
                lastSnapshot = s;
                snapshotCount++;
                if (s.epochSeq > maxEpochSeq) maxEpochSeq = s.epochSeq;
                if (s.pendingRescaleSeq > maxPendingRescaleSeq) {
                    maxPendingRescaleSeq = s.pendingRescaleSeq;
                    mergedPendingReason  = s.pendingRescaleReason == null ? "" : s.pendingRescaleReason;
                    mergedPendingIssued  = s.pendingRescaleIssuedAtMs;
                    mergedPendingTargetP = s.pendingRescaleTargetP;
                }
            }

            if (lastSnapshot != null) {
                this.responseCounter                = lastSnapshot.responseCounter;
                this.cacheHitResponseCounter        = lastSnapshot.cacheHitResponseCounter;
                this.successResponseCounter         = lastSnapshot.successResponseCounter;
                this.underSLOResponseCounter        = lastSnapshot.underSLOResponseCounter;
                this.underSLOMinus2sResponseCounter = lastSnapshot.underSLOMinus2sResponseCounter;
                this.underSLOPlus2sResponseCounter  = lastSnapshot.underSLOPlus2sResponseCounter;
                this.underSLOPlus4sResponseCounter  = lastSnapshot.underSLOPlus4sResponseCounter;
                this.totalLatency                   = lastSnapshot.totalLatency;
                this.totalWaitLatency               = lastSnapshot.totalWaitLatency;
                this.totalInferenceLatency          = lastSnapshot.totalInferenceLatency;
                this.totalOtherLatency              = lastSnapshot.totalOtherLatency;
                this.firstRequestTime               = lastSnapshot.firstRequestTime;
                this.lastRequestTime                = lastSnapshot.lastRequestTime;
                this.lastResponseTime               = lastSnapshot.lastResponseTime;
                this.gpuInferenceTime               = lastSnapshot.gpuInferenceTime;
                this.cacheStrategy                  = lastSnapshot.cacheStrategy;
                this.allRequestsEmitted             = lastSnapshot.allRequestsEmitted;
                this.isFinished.set(lastSnapshot.completionTriggered);

                this.windowRecordsCounter  = new AtomicLong(lastSnapshot.windowRecordsSnapshot);
                this.windowBusyTimeMs      = new AtomicLong(lastSnapshot.windowBusyTimeMsSnapshot);
                this.windowMinCreateTime   = new AtomicLong(lastSnapshot.windowMinCreateTimeSnapshot);
                this.windowMaxCreateTime   = new AtomicLong(lastSnapshot.windowMaxCreateTimeSnapshot);
                this.windowStartTime       = lastSnapshot.windowStartTimeSnapshot;

                this.windowTotalCounter    = new AtomicInteger(lastSnapshot.windowTotalCounterSnapshot);
                this.windowSuccessCounter  = new AtomicInteger(lastSnapshot.windowSuccessCounterSnapshot);
                this.windowUnderSLOCounter = new AtomicInteger(lastSnapshot.windowUnderSLOCounterSnapshot);

                this.epochSeq = maxEpochSeq;

                this.pendingRescaleSeq        = maxPendingRescaleSeq;
                this.pendingRescaleReason     = mergedPendingReason;
                this.pendingRescaleIssuedAtMs = mergedPendingIssued;
                this.pendingRescaleTargetP    = mergedPendingTargetP;
            }

            if (this.windowRecordsCounter == null) {
                this.windowRecordsCounter  = new AtomicLong(0L);
                this.windowBusyTimeMs      = new AtomicLong(0L);
                this.windowMinCreateTime   = new AtomicLong(Long.MAX_VALUE);
                this.windowMaxCreateTime   = new AtomicLong(Long.MIN_VALUE);
                this.windowStartTime       = System.currentTimeMillis();
                this.windowTotalCounter    = new AtomicInteger(0);
                this.windowSuccessCounter  = new AtomicInteger(0);
                this.windowUnderSLOCounter = new AtomicInteger(0);
            }

            Map<String, Integer> lastLatency = null;
            for (Map<String, Integer> map : latencyMapState.get()) lastLatency = map;
            this.requestLatencyMap = (lastLatency != null)
                    ? new ConcurrentHashMap<>(lastLatency) : new ConcurrentHashMap<>();

            Map<String, Integer> lastCache = null;
            for (Map<String, Integer> map : cacheSizeMapState.get()) lastCache = map;
            this.nodeCacheSizeMap = (lastCache != null)
                    ? new ConcurrentHashMap<>(lastCache) : new ConcurrentHashMap<>();

            this.metricsHistory.clear();

            this.csvHistoryRows = new ArrayList<>();
            for (CsvHistoryRow r : csvHistoryState.get()) {
                this.csvHistoryRows.add(r);
            }

            LOG.info("DS2 Sink State Restored: snapshots={}, responses={}, csvHistoryRows={}, "
                            + "epochSeq={}, pendingRescaleSeq={}, gpuInferenceTimeMs={}, gpuHours={}",
                    snapshotCount, responseCounter, csvHistoryRows.size(), epochSeq, pendingRescaleSeq,
                    gpuInferenceTime,
                    String.format("%.6f", gpuInferenceTime / 3_600_000.0));
        } else {
            LOG.info("DS2 Sink 首次启动（无 state 可恢复）");
        }
    }
}
