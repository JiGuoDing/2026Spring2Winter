"""
ZeroTune 算法共享常量与数据结构
================================

本模块定义 ZeroTune 算法所需的常量、候选配置空间、特征/目标列名，
以及核心决策数据结构 ZeroTuneDecision。供训练脚本和 Daemon 进程共同导入。

ZeroTune 算法核心思想（来自论文 Section IV-V）：
    1. 离线层：在历史数据上预训练性能预测器（Predictor），学习
       (parallelism, batch_size, arrival_rate) → (latency, throughput, gpu_util)
       的映射关系。
    2. 在线层：监控运行中的作业，利用预测器评估所有候选配置，
       在满足 SLO 和队列稳定性约束的前提下，选择资源成本最低的配置。

本系统适配：
    - 单算子场景：仅有一个推理算子，仅并行度 (parallelism) 可调，
      批次大小 (batch_size) 在单次会话中保持不变。
    - 候选配置空间：parallelism ∈ {1,2,3,4}，batch_size ∈ {4,8,16}。
    - 成本度量：gpu_utilization × parallelism（GPU 资源消耗代理）。
"""
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

# ============================================================================
# 候选配置空间
# ============================================================================
PARALLELISM_VALUES: List[int] = [1, 2, 3, 4]
BATCH_SIZE_VALUES: List[int] = [4, 8, 16]
MIN_PARALLELISM: int = 1
MAX_PARALLELISM: int = 4

# 所有可能的 (parallelism, batch_size) 组合，共 12 个
# 用于训练阶段遍历全部配置；在线阶段仅评估当前 batch_size 下的 4 个配置
CANDIDATE_CONFIGS: List[Tuple[int, int]] = [
    (p, b) for p in PARALLELISM_VALUES for b in BATCH_SIZE_VALUES
]

# ============================================================================
# 特征与目标列名（与 sink CSV 列名严格对齐）
# ============================================================================
FEATURE_COLUMNS: List[str] = ["parallelism", "batch_size", "arrival_rate"]

# 目标列名映射：预测器名称 → sink CSV 中的列名
TARGET_COLUMNS: Dict[str, str] = {
    "latency":     "avg_latency_ms",
    "throughput":  "throughput_rps",
    "gpu":         "gpu_utilization",
}

# sink CSV 中用于训练的原始列名
COL_PARALLELISM:     str = "parallelism"
COL_BATCH_SIZE:      str = "batch_size"
COL_TARGET_RATE:     str = "target_rate"       # 训练时重命名为 arrival_rate
COL_THROUGHPUT:      str = "throughput_rps"
COL_LATENCY:         str = "avg_latency_ms"
COL_GPU_UTIL:        str = "gpu_utilization"
COL_GPU_HOURS:       str = "gpu_hours"
COL_TOTAL_REQUESTS:  str = "total_requests"

# ============================================================================
# ZeroTune 算法参数
# ============================================================================
# 冷却时间（秒）：两次重配置之间的最短间隔，与 DS2 保持一致
ZT_COOLDOWN_SECONDS: float = 120.0

# 最少历史窗口数：收到的指标窗口数不足此值时跳过决策
ZT_MIN_HISTORY_WINDOWS: int = 3

# 到达率估计窗口：取最近 N 个窗口的 sourceEmissionRate 均值
ZT_ARRIVAL_RATE_WINDOW: int = 5

# SLO 安全裕度：预测延迟必须 ≤ SLO × 此系数（预留 10% 余量）
ZT_SLO_SAFETY_MARGIN: float = 0.9

# 默认 SLO（毫秒），CLI 可覆盖
DEFAULT_SLO_MS: float = 90000.0

# ============================================================================
# 模型路径
# ============================================================================
ZT_MODEL_DIR: str = "/mnt/models"
ZT_MODEL_LATENCY:    str = "predictor_latency.joblib"
ZT_MODEL_THROUGHPUT: str = "predictor_throughput.joblib"
ZT_MODEL_GPU:        str = "predictor_gpu.joblib"
ZT_MODEL_METADATA:   str = "model_metadata.json"

# ============================================================================
# 成本度量
# ============================================================================
# "gpu_util_x_p"：gpu_utilization × parallelism，GPU 资源消耗代理
# 可扩展为 "estimated_completion_time" 等
ZT_COST_METRIC: str = "gpu_util_x_p"


# ============================================================================
# 决策数据结构
# ============================================================================
@dataclass
class ZeroTuneDecision:
    """
    ZeroTune 算法的决策输出。

    包含选定的候选配置、各项预测值、约束评估结果、成本，
    以及用于诊断的候选集评估详情。
    """
    # ── 选定的配置 ──
    candidate_parallelism: int
    candidate_batch_size: int

    # ── 对选定配置的预测值 ──
    predicted_latency_ms: float
    predicted_throughput_rps: float
    predicted_gpu_utilization: float

    # ── 约束评估 ──
    slo_satisfied: bool           # 预测延迟 ≤ SLO
    queue_stable: bool            # 预测吞吐 ≥ 到达率

    # ── 成本 ──
    predicted_cost: float         # gpu_utilization × parallelism

    # ── 当前状态 ──
    arrival_rate_used: float      # 本次决策使用的到达率估计
    current_parallelism: int
    current_batch_size: int

    # ── 诊断信息 ──
    num_candidates_evaluated: int
    num_candidates_slo_ok: int
    num_candidates_queue_ok: int
    num_candidates_both_ok: int

    # 所有候选配置的评估详情（用于日志和调试）
    all_candidates_detail: Optional[List[Dict[str, Any]]] = field(
        default=None, repr=False
    )
