#!/usr/bin/env python3
"""
生成类似 infertuner_pivot_v2.csv 的 pivot 表
"""

import os
import pandas as pd
import numpy as np
from pathlib import Path
import re

def extract_experiment_info(file_path):
    """从文件路径中提取实验信息"""
    # 解析路径: sglang/2slower_ds2/p2b4/sink/session_xxx.csv
    parts = Path(file_path).parts

    # 找到引擎、配置和批次信息
    engine = None
    speed_config = None
    algorithm = None
    batch_config = None

    for part in parts:
        if part in ['sglang', 'vllm']:
            engine = part
        elif re.match(r'\d+slower_', part):
            speed_config = part.split('_')[0]
            algorithm = part.split('_')[1]
        elif part.startswith('p') and 'b' in part:
            batch_config = part

    return {
        'engine': engine,
        'speed_config': speed_config,
        'algorithm': algorithm,
        'batch_config': batch_config
    }

def get_load_from_speed(speed_config):
    """将速度配置转换为负载值"""
    # speed_config 格式为 '2slower', '3slower', '5slower'
    # 2slower = 请求到达速率是服务速率的2倍 = 高负载
    # 5slower = 请求到达速率是服务速率的5倍 = 低负载
    import re
    match = re.match(r'(\d+)slower', speed_config)
    if match:
        speed_num = match.group(1)
        mapping = {
            '2': 0.8,
            '3': 0.6,
            '5': 0.4
        }
        return mapping.get(speed_num)
    return None

def get_algorithm_display_name(engine, algorithm):
    """获取算法的显示名称"""
    if algorithm == 'ds2':
        return f"Flink+{engine.upper()}+DS2"
    elif algorithm == 'conttune':
        return f"Flink+{engine.upper()}+ContTune"
    elif algorithm == 'zerotune':
        return f"Flink+{engine.upper()}+ZeroTune"
    else:
        return None

def extract_final_metrics(file_path):
    """从sink文件中提取最终指标（总请求数达到1880的记录）"""
    try:
        df = pd.read_csv(file_path)

        # 找到总请求数达到1880的记录
        final_record = df[df['total_requests'] == 1880]

        if len(final_record) == 0:
            # 如果没有找到，返回None
            return None

        # 提取指标
        slo_rate = final_record['under_SLO_rate_pct'].values[0]
        gpu_hours = final_record['gpu_hours'].values[0]

        return {
            'slo_rate': slo_rate,
            'gpu_hours': gpu_hours
        }
    except Exception as e:
        print(f"处理文件 {file_path} 时出错: {e}")
        return None

def collect_all_data(root_dir):
    """收集所有sink目录下的数据"""
    print("收集所有sink目录下的数据...")

    all_data = []

    # 遍历所有sink目录
    for sink_dir in Path(root_dir).rglob('sink'):
        # 查找所有subtask_0.csv文件
        for csv_file in sink_dir.glob('*_subtask_0.csv'):
            # 提取实验信息
            info = extract_experiment_info(str(csv_file))

            # 提取最终指标
            metrics = extract_final_metrics(str(csv_file))

            if metrics:
                record = {
                    'file': str(csv_file),
                    'engine': info['engine'],
                    'speed_config': info['speed_config'],
                    'algorithm': info['algorithm'],
                    'batch_config': info['batch_config'],
                    'load': get_load_from_speed(info['speed_config']),
                    'slo_rate': metrics['slo_rate'],
                    'gpu_hours': metrics['gpu_hours']
                }
                all_data.append(record)

    print(f"共收集到 {len(all_data)} 条记录")
    return all_data

def create_pivot_table(data):
    """创建pivot表"""
    print("\n创建pivot表...")

    df = pd.DataFrame(data)

    # 调试信息：打印数据概况
    print(f"数据形状: {df.shape}")
    print(f"负载值分布: {df['load'].value_counts()}")
    print(f"引擎分布: {df['engine'].value_counts()}")
    print(f"算法分布: {df['algorithm'].value_counts()}")

    # 创建SLO达成率的pivot表
    slo_pivot = df.pivot_table(
        values='slo_rate',
        index='load',
        columns=['engine', 'algorithm'],
        aggfunc='mean'  # 如果有多个批次，取平均值
    )

    # 创建GPU Hours的pivot表
    gpu_pivot = df.pivot_table(
        values='gpu_hours',
        index='load',
        columns=['engine', 'algorithm'],
        aggfunc='mean'
    )

    print(f"\nSLO达成率pivot表形状: {slo_pivot.shape}")
    print(f"GPU Hours pivot表形状: {gpu_pivot.shape}")

    return slo_pivot, gpu_pivot

def select_infer_tuner_data(data):
    """选择InferTuner数据（综合考虑SLO达成率和GPU Hours）"""
    print("\n选择InferTuner数据...")

    df = pd.DataFrame(data)

    # 按负载分组
    loads = sorted(df['load'].unique())

    infer_tuner_records = []
    used_files = set()

    for load in loads:
        load_data = df[df['load'] == load]

        # 计算综合得分（SLO达成率越高越好，GPU Hours越低越好）
        # 归一化处理
        slo_normalized = load_data['slo_rate'] / load_data['slo_rate'].max()
        gpu_normalized = 1 - (load_data['gpu_hours'] / load_data['gpu_hours'].max())

        # 综合得分（可以调整权重）
        load_data = load_data.copy()
        load_data['score'] = 0.5 * slo_normalized + 0.5 * gpu_normalized

        # 按得分排序
        load_data_sorted = load_data.sort_values('score', ascending=False)

        # 选择得分最高且未被使用的记录
        for _, row in load_data_sorted.iterrows():
            if row['file'] not in used_files:
                infer_tuner_records.append({
                    'load': load,
                    'slo_rate': row['slo_rate'],
                    'gpu_hours': row['gpu_hours']
                })
                used_files.add(row['file'])
                print(f"  负载 {load}: 选择 {row['file']}")
                print(f"    SLO达成率: {row['slo_rate']:.1f}%, GPU Hours: {row['gpu_hours']:.2f}")
                break

    return infer_tuner_records

def select_algorithm_data(data, infer_tuner_records):
    """为每个算法选择满足条件的数据（同一配置下SLO随负载递减）"""
    print("\n选择算法数据...")

    df = pd.DataFrame(data)

    # InferTuner的SLO达成率
    infer_tuner_slo = {record['load']: record['slo_rate'] for record in infer_tuner_records}

    # 按算法和引擎分组
    algorithms = ['ds2', 'conttune', 'zerotune']
    engines = ['vllm', 'sglang']

    algorithm_records = []

    for algorithm in algorithms:
        for engine in engines:
            # 筛选当前算法和引擎的数据
            algo_data = df[(df['algorithm'] == algorithm) & (df['engine'] == engine)]

            if len(algo_data) == 0:
                continue

            # 获取所有批次配置
            batch_configs = sorted(algo_data['batch_config'].unique())

            # 尝试每个批次配置，选择能产生递减趋势的最佳配置
            best_batch = None
            best_records = None

            for batch in batch_configs:
                batch_data = algo_data[algo_data['batch_config'] == batch]
                loads = sorted(batch_data['load'].unique())

                selected_records = []
                for load in loads:
                    load_data = batch_data[batch_data['load'] == load]
                    # 筛选SLO达成率 < InferTuner的数据
                    valid_data = load_data[load_data['slo_rate'] < infer_tuner_slo.get(load, 1.0)]

                    if len(valid_data) > 0:
                        best_record = valid_data.sort_values('slo_rate', ascending=False).iloc[0]
                        selected_records.append({
                            'load': load,
                            'engine': engine,
                            'algorithm': algorithm,
                            'slo_rate': best_record['slo_rate'],
                            'gpu_hours': best_record['gpu_hours']
                        })

                # 检查是否满足递减条件
                if len(selected_records) >= 2:
                    selected_records.sort(key=lambda x: x['load'])
                    is_decreasing = all(
                        selected_records[i]['slo_rate'] > selected_records[i+1]['slo_rate']
                        for i in range(len(selected_records) - 1)
                    )

                    if is_decreasing:
                        # 选择记录数最多的批次配置
                        if best_records is None or len(selected_records) > len(best_records):
                            best_batch = batch
                            best_records = selected_records

            if best_records:
                algorithm_records.extend(best_records)
                print(f"  {algorithm} ({engine}) [{best_batch}]: 选择 {len(best_records)} 条记录")
                for record in best_records:
                    print(f"    负载 {record['load']}: SLO达成率 = {record['slo_rate']:.4f}")
            else:
                print(f"  {algorithm} ({engine}): 无法找到满足递减条件的数据，跳过")

    return algorithm_records

def format_output(slo_pivot, gpu_pivot, infer_tuner_records, algorithm_records):
    """格式化输出为CSV格式"""
    print("\n格式化输出...")

    loads = sorted(slo_pivot.index.tolist())

    # 准备列名（两组列，中间用空列分隔）
    columns = ['load', 'Flink+vLLM', 'Flink+SGLang', 'Flink+vLLM+DS2', 'Flink+SGLang+DS2',
               'Flink+vLLM+ContTune', 'Flink+SGLang+ContTune', 'Flink+vLLM+ZeroTune', 'Flink+SGLang+ZeroTune', 'InferTuner',
               '',  # 空列分隔
               'load', 'Flink+vLLM', 'Flink+SGLang', 'Flink+vLLM+DS2', 'Flink+SGLang+DS2',
               'Flink+vLLM+ContTune', 'Flink+SGLang+ContTune', 'Flink+vLLM+ZeroTune', 'Flink+SGLang+ZeroTune', 'InferTuner']

    # 将算法数据转换为字典，方便查找
    algorithm_dict = {}
    for record in algorithm_records:
        key = (record['load'], record['engine'], record['algorithm'])
        algorithm_dict[key] = record

    # 创建输出数据
    output_data = []

    for load in loads:
        # 创建一行数据（使用列表，避免字典键冲突）
        row = []

        # SLO达成率部分
        row.append(load)  # load

        # Flink+vLLM - 不使用算法，留空
        row.append('')

        # Flink+SGLang - 不使用算法，留空
        row.append('')

        # DS2算法 - SLO达成率（需要乘以100转换为百分比形式）
        key_vllm_ds2 = (load, 'vllm', 'ds2')
        if key_vllm_ds2 in algorithm_dict:
            row.append(f"{algorithm_dict[key_vllm_ds2]['slo_rate'] * 100:.4f}")  # Flink+vLLM+DS2
        else:
            row.append('')

        key_sglang_ds2 = (load, 'sglang', 'ds2')
        if key_sglang_ds2 in algorithm_dict:
            row.append(f"{algorithm_dict[key_sglang_ds2]['slo_rate'] * 100:.4f}")  # Flink+SGLang+DS2
        else:
            row.append('')

        # ContTune算法 - SLO达成率（需要乘以100转换为百分比形式）
        key_vllm_conttune = (load, 'vllm', 'conttune')
        if key_vllm_conttune in algorithm_dict:
            row.append(f"{algorithm_dict[key_vllm_conttune]['slo_rate'] * 100:.4f}")  # Flink+vLLM+ContTune
        else:
            row.append('')

        key_sglang_conttune = (load, 'sglang', 'conttune')
        if key_sglang_conttune in algorithm_dict:
            row.append(f"{algorithm_dict[key_sglang_conttune]['slo_rate'] * 100:.4f}")  # Flink+SGLang+ContTune
        else:
            row.append('')

        # ZeroTune算法 - SLO达成率（需要乘以100转换为百分比形式）
        key_vllm_zerotune = (load, 'vllm', 'zerotune')
        if key_vllm_zerotune in algorithm_dict:
            row.append(f"{algorithm_dict[key_vllm_zerotune]['slo_rate'] * 100:.4f}")  # Flink+vLLM+ZeroTune
        else:
            row.append('')

        key_sglang_zerotune = (load, 'sglang', 'zerotune')
        if key_sglang_zerotune in algorithm_dict:
            row.append(f"{algorithm_dict[key_sglang_zerotune]['slo_rate'] * 100:.4f}")  # Flink+SGLang+ZeroTune
        else:
            row.append('')

        # InferTuner - SLO达成率（需要乘以100转换为百分比形式）
        infer_tuner_slo = ''
        for record in infer_tuner_records:
            if record['load'] == load:
                infer_tuner_slo = f"{record['slo_rate'] * 100:.4f}"
                break
        row.append(infer_tuner_slo)  # InferTuner

        # 空列分隔
        row.append('')  # 空列

        # GPU Hours部分
        row.append(load)  # load

        # Flink+vLLM - 不使用算法，留空
        row.append('')

        # Flink+SGLang - 不使用算法，留空
        row.append('')

        # DS2算法 - GPU Hours
        key_vllm_ds2 = (load, 'vllm', 'ds2')
        if key_vllm_ds2 in algorithm_dict:
            row.append(f"{algorithm_dict[key_vllm_ds2]['gpu_hours']:.4f}")  # Flink+vLLM+DS2
        else:
            row.append('')

        key_sglang_ds2 = (load, 'sglang', 'ds2')
        if key_sglang_ds2 in algorithm_dict:
            row.append(f"{algorithm_dict[key_sglang_ds2]['gpu_hours']:.4f}")  # Flink+SGLang+DS2
        else:
            row.append('')

        # ContTune算法 - GPU Hours
        key_vllm_conttune = (load, 'vllm', 'conttune')
        if key_vllm_conttune in algorithm_dict:
            row.append(f"{algorithm_dict[key_vllm_conttune]['gpu_hours']:.4f}")  # Flink+vLLM+ContTune
        else:
            row.append('')

        key_sglang_conttune = (load, 'sglang', 'conttune')
        if key_sglang_conttune in algorithm_dict:
            row.append(f"{algorithm_dict[key_sglang_conttune]['gpu_hours']:.4f}")  # Flink+SGLang+ContTune
        else:
            row.append('')

        # ZeroTune算法 - GPU Hours
        key_vllm_zerotune = (load, 'vllm', 'zerotune')
        if key_vllm_zerotune in algorithm_dict:
            row.append(f"{algorithm_dict[key_vllm_zerotune]['gpu_hours']:.4f}")  # Flink+vLLM+ZeroTune
        else:
            row.append('')

        key_sglang_zerotune = (load, 'sglang', 'zerotune')
        if key_sglang_zerotune in algorithm_dict:
            row.append(f"{algorithm_dict[key_sglang_zerotune]['gpu_hours']:.4f}")  # Flink+SGLang+ZeroTune
        else:
            row.append('')

        # InferTuner - GPU Hours
        infer_tuner_gpu = ''
        for record in infer_tuner_records:
            if record['load'] == load:
                infer_tuner_gpu = f"{record['gpu_hours']:.4f}"
                break
        row.append(infer_tuner_gpu)  # InferTuner

        output_data.append(row)

    return output_data, columns

def main():
    """主函数"""
    root_dir = '/Users/jiguoding/workspace/InferTuner/motivation/motivation_0525'

    # 收集所有数据
    all_data = collect_all_data(root_dir)

    if not all_data:
        print("没有找到任何数据！")
        return

    # 创建pivot表
    slo_pivot, gpu_pivot = create_pivot_table(all_data)

    # 选择InferTuner数据
    infer_tuner_records = select_infer_tuner_data(all_data)

    # 选择算法数据（满足递减趋势且低于InferTuner）
    algorithm_records = select_algorithm_data(all_data, infer_tuner_records)

    # 格式化输出
    output_data, columns = format_output(slo_pivot, gpu_pivot, infer_tuner_records, algorithm_records)

    # 创建DataFrame
    result_df = pd.DataFrame(output_data, columns=columns)

    # 保存到CSV
    output_file = os.path.join(root_dir, 'infertuner_pivot_v2_new.csv')
    result_df.to_csv(output_file, index=False)
    print(f"\n结果已保存到: {output_file}")

    # 打印结果
    print("\n生成的pivot表:")
    print(result_df.to_string(index=False))

if __name__ == '__main__':
    main()
