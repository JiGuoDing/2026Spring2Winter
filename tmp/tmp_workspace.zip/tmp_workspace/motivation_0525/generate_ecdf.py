#!/usr/bin/env python3
"""
生成 Rescale vs Stop ECDF CSV 文件
"""

import os
import pandas as pd
import numpy as np
from pathlib import Path

def find_rescale_events_files(root_dir):
    """查找所有rescale_events_*.csv文件"""
    rescale_files = []
    for path in Path(root_dir).rglob('rescale_events_*.csv'):
        rescale_files.append(str(path))
    return rescale_files

def extract_success_events(file_path):
    """从CSV文件中提取RESCALE_SUCCESS事件的时间数据"""
    try:
        df = pd.read_csv(file_path)
        # 筛选RESCALE_SUCCESS事件
        success_events = df[df['event_type'] == 'RESCALE_SUCCESS'].copy()

        if len(success_events) == 0:
            return None

        # 提取关键字段并转换为秒
        result = pd.DataFrame({
            'rescale_elapsed_s': success_events['rescale_elapsed_ms'] / 1000.0,
            'stop_savepoint_s': success_events['stop_savepoint_ms'] / 1000.0
        })

        return result
    except Exception as e:
        print(f"处理文件 {file_path} 时出错: {e}")
        return None

def merge_all_data(root_dir):
    """合并所有monitor目录中的重配置数据"""
    print("步骤1: 查找并合并数据...")

    # 查找所有rescale_events文件
    rescale_files = find_rescale_events_files(root_dir)
    print(f"找到 {len(rescale_files)} 个rescale_events文件")

    # 合并所有数据
    all_data = []
    for file_path in rescale_files:
        data = extract_success_events(file_path)
        if data is not None and len(data) > 0:
            all_data.append(data)

    if not all_data:
        raise ValueError("没有找到有效的RESCALE_SUCCESS事件数据")

    # 合并所有DataFrame
    merged_data = pd.concat(all_data, ignore_index=True)
    print(f"合并后共有 {len(merged_data)} 条记录")

    return merged_data

def remove_outliers_iqr(data, column):
    """使用IQR方法剔除异常值"""
    Q1 = data[column].quantile(0.25)
    Q3 = data[column].quantile(0.75)
    IQR = Q3 - Q1

    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR

    # 筛选在范围内的数据
    mask = (data[column] >= lower_bound) & (data[column] <= upper_bound)
    filtered_data = data[mask].copy()

    outliers_count = len(data) - len(filtered_data)
    print(f"{column}: 剔除 {outliers_count} 个异常值 (范围: [{lower_bound:.2f}, {upper_bound:.2f}])")

    return filtered_data

def clean_data(data):
    """剔除异常值"""
    print("\n步骤2: 剔除异常值...")

    # 对两列分别剔除异常值
    cleaned_data = remove_outliers_iqr(data, 'rescale_elapsed_s')
    cleaned_data = remove_outliers_iqr(cleaned_data, 'stop_savepoint_s')

    print(f"清洗后剩余 {len(cleaned_data)} 条记录")

    return cleaned_data

def compute_ecdf(data):
    """计算经验累积分布函数"""
    sorted_data = np.sort(data)
    n = len(sorted_data)
    # P(X ≤ x) = i/n，其中i从1开始
    ecdf = np.arange(1, n + 1) / n
    return sorted_data, ecdf

def generate_ecdf_csv(cleaned_data, output_file):
    """生成ECDF CSV文件"""
    print("\n步骤3: 生成ECDF...")

    # 分别计算两个CDF
    rescale_times, rescale_cdf = compute_ecdf(cleaned_data['rescale_elapsed_s'].values)
    stop_times, stop_cdf = compute_ecdf(cleaned_data['stop_savepoint_s'].values)

    # 合并所有时间点
    all_times = np.unique(np.concatenate([rescale_times, stop_times]))
    all_times.sort()

    # 创建结果DataFrame
    result_data = []

    # 对于每个时间点，计算两个CDF值
    rescale_idx = 0
    stop_idx = 0
    rescale_cdf_value = 0.0
    stop_cdf_value = 0.0

    for time_point in all_times:
        # 更新rescale CDF值
        while rescale_idx < len(rescale_times) and rescale_times[rescale_idx] <= time_point:
            rescale_cdf_value = rescale_cdf[rescale_idx]
            rescale_idx += 1

        # 更新stop CDF值
        while stop_idx < len(stop_times) and stop_times[stop_idx] <= time_point:
            stop_cdf_value = stop_cdf[stop_idx]
            stop_idx += 1

        result_data.append({
            'Time (s)': time_point,
            'Rescale elapsed CDF': rescale_cdf_value,
            'Stop savepoint CDF': stop_cdf_value
        })

    # 创建DataFrame并保存
    result_df = pd.DataFrame(result_data)

    # 确保CDF值单调递增（处理可能的浮点精度问题）
    result_df['Rescale elapsed CDF'] = result_df['Rescale elapsed CDF'].cummax()
    result_df['Stop savepoint CDF'] = result_df['Stop savepoint CDF'].cummax()

    # 保存到CSV
    result_df.to_csv(output_file, index=False)
    print(f"ECDF文件已保存到: {output_file}")
    print(f"共 {len(result_df)} 个数据点")

    return result_df

def main():
    """主函数"""
    root_dir = '/Users/jiguoding/workspace/InferTuner/motivation/motivation_0525'

    # 步骤1: 合并数据
    merged_data = merge_all_data(root_dir)

    # 保存中间文件
    merged_output = os.path.join(root_dir, 'merged_rescale_data.csv')
    merged_data.to_csv(merged_output, index=False)
    print(f"合并数据已保存到: {merged_output}")

    # 步骤2: 剔除异常值
    cleaned_data = clean_data(merged_data)

    # 保存清洗后的数据
    cleaned_output = os.path.join(root_dir, 'cleaned_rescale_data.csv')
    cleaned_data.to_csv(cleaned_output, index=False)
    print(f"清洗数据已保存到: {cleaned_output}")

    # 步骤3: 生成ECDF
    ecdf_output = os.path.join(root_dir, 'infertuner_rescale_vs_stop_ecdf_new.csv')
    result_df = generate_ecdf_csv(cleaned_data, ecdf_output)

    # 验证结果
    print("\n验证结果:")
    print(f"  最终CDF值 - Rescale elapsed: {result_df['Rescale elapsed CDF'].iloc[-1]:.4f}")
    print(f"  最终CDF值 - Stop savepoint: {result_df['Stop savepoint CDF'].iloc[-1]:.4f}")
    print(f"  Rescale elapsed CDF单调递增: {(result_df['Rescale elapsed CDF'].diff().dropna() >= 0).all()}")
    print(f"  Stop savepoint CDF单调递增: {(result_df['Stop savepoint CDF'].diff().dropna() >= 0).all()}")

if __name__ == '__main__':
    main()
