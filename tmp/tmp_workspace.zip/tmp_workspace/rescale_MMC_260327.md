# M/M/c 排队论的具体实现及应用

## 具体判断重配置决策逻辑

将 Flink 推理集群抽象成一个经典排队系统

- 请求 = 顾客
- 每个推理算子 = 一个服务台
- c = 并行度 (服务台数量)
- λ = 请求到达率 (顾客到达率)
- μ = 每个服务台的最大服务率 (每个推理算子的最大处理能力)
- a = 总流量强度 (系统同时需要处理的平均请求数，单位服务台的平均请求数)
- $\rho$ = 单个算子的利用率 (繁忙程度)
- E[T] = 平均系统端到端时延 (请求的端到端时延)

### 决策流程图

```plaintext
收到 history（n 个窗口）
        │
        ▼
  数据量不够？ ──是──▶ return False（跳过）
        │否
        ▼
  λ < 1e-6？ ──是──▶ return False（空闲，跳过）
        │否
        ▼
  c <= 0？ ──是──▶ return False（数据异常，跳过）
        │否
        ▼
  计算 avg_gpu_util（多窗口均值）
        │
        ▼
  avg_gpu_util ≥ 0.95？ ──是──▶ return True, scale_up（过载短路）
        │否
        ▼
  effective_gpu_util = max(avg_gpu_util, 1e-3)
  μ = λ / (c × effective_gpu_util)
        │
        ▼
  compute_expected_sojourn_time(c, λ, μ)
        │
        ├─▶ 返回 None（ρ≥1，不稳定）──▶ return True, scale_up, c_min
        │
        ▼
  E[T] > SLO？ ──是──▶ return True, scale_up, c_min
        │否
        ▼
  find_min_parallelism → c_min
        │
        ├─▶ c_min < c ──▶ return True, scale_down, c_min
        │
        └─▶ c_min == c ──▶ return False（配置恰好）
```

### 系统参数估计

#### 1. 请求到达率 $\lambda$ 的估计

取各窗口 `windowedThroughput` 的均值作为 $\lambda$ 的估计值

$\lambda = \frac{1}{n}\sum_{i=1}^{n} windowedThroughput_{i} (req/s)$

理论依据：稳态系统中，吞吐率等于到达率，因此可以用实际测量的吞吐率来近似表示请求到达率。(参考 [Little's Law](https://zh.wikipedia.org/wiki/%E5%88%A9%E7%89%B9%E7%88%BE%E6%B3%95%E5%89%87))

#### 2. 请求到达率 $\lambda$ 近零保护

如果 $\lambda < 1e-6$ 即系统几乎没有请求到达，则认为系统处于极度空闲状态，不需要重配置，直接跳过判断

#### 3. 使用 GPU 利用率近似表示算子利用率 $\rho$

估算单个算子的利用率 $\rho$，表示单个算子的繁忙程度，取值为 $[0,1)$。这里用 GPU 利用率来代替 $\rho$，在 LLM 推理场景中，GPU 几乎只在处理推理请求时被占用，因此 GPU 空闲 $\approx$ 算子空闲，因此：
$\rho_{GPU} = \frac{1}{n}\sum_{i=1}^{n} windowedGPUUtilization_{i} \approx \rho = \frac{\lambda}{c \cdot \mu}$

由此可以反推出单个算子的最大服务率 $\mu$：

$\mu = \frac{\lambda}{c \cdot \rho_{GPU}} (req/s/worker)$

#### 4. GPU 过载短路

当 GPU 利用率过高时，直接认为系统过载，需要扩容

#### 5. 计算当前配置下的 E[T]

##### Erlang-C 公式的含义

$erlang\_c\_formular(c, a)$ 计算的是“当一个新请求到达时，所有 c 个推理算子都在忙的概率”，也就是该请求需要排队等待的概率 $P_{C}$

$E[T] = \frac{P_{C}}{c\mu - \lambda} + \frac{1}{\mu}$

其中 $c\mu - \lambda$ 是系统的“剩余服务能力”，$P_{C}$ 越大越容易排队、剩余服务能力越小，等待时间越长

#### 6. 判断是否需要扩容

如果系统不稳定 (E[T] > SLO)，说明当前 $\rho \ge 1$，队列无限增长，需要增加并行度；否则说明当前算子并行度可能过多，继续判断是否需要缩容

#### 7. 判断是否需要缩容

当 E[T] <= SLO 时，搜索最小的满足 SLO 的并行度 c_min

1. 搜索起点：稳定运行所需的最小并行度，即 $c_{stable_min} = \lfloor a \rfloor + 1$ (保证 $\rho = a/c < 1$，系统稳定)
2. 逐步递增：从 $c_{stable_min}$ 开始，找到第一个使 $E[T] \le SLO$ 的最小的 c，即为 $c_{min}$
3. 搜索上界：设定上界 (默认 64)，防止在极高负载下无限循环。若搜索范围内无解，则返回 None

$c_{min} = min\{c \in Z^{+} | c > \frac{\lambda}{\mu}, E[T](c, \lambda, \mu) \le SLO \}$

若 $c_{min} < c$ 则认为当前配置过于宽松，可以缩容；否则认为当前配置恰好，不需要调整

## 运行时截图

![](./assets/mmc.png)




