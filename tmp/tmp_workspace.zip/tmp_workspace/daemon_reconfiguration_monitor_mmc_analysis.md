# `daemon_reconfiguration_monitor_mmc.py` 逻辑分析

## 1. 重配置脚本功能

`scripts/python/Monitor/daemon_reconfiguration_monitor_mmc.py` 是 InferTuner 系统里的**控制面守护进程**。站在控制面的角度做三件事：

1. 接收 `NJULocalCacheTestSink.java` 定时上报的窗口指标；
2. 用一套 **M/M/c + Erlang-C** 的判定逻辑判断当前配置是否该重配；
3. 如果需要，就调用 `rescale.sh` 执行 Flink Job 的 savepoint / cancel / submit。

---

## 2. 完整工作流链路

```text
NJULocalRequestSource
  -> InferenceStateFetcherProcessor
  -> InferenceRequestBatcherProcessor
  -> NJULocalInferenceAsyncProcessor
  -> NJULocalCacheTestSink
```

与重配置操作相关：

| 文件                                                              | 角色       | 作用                            |
|-----------------------------------------------------------------|----------|-------------------------------|
| `src/main/java/com/infertuner/sinks/NJULocalCacheTestSink.java` | 数据面指标上报者 | 聚合窗口指标、维护历史、通过 TCP 发送给 Daemon |
| `scripts/python/Monitor/daemon_reconfiguration_monitor_mmc.py`  | 控制面决策者   | 解析指标、做 M/M/c 判定、触发重配置         |

整体闭环如下：

```mermaid
flowchart LR
    A[Flink Job] --> B[NJULocalCacheTestSink]
    B -->|每60s发送最近5个窗口指标| C[daemon_reconfiguration_monitor_mmc.py]
    C -->|需要重配置| D[rescale.sh]
    D -->|savepoint/cancel/submit| E[Flink Cluster]
    E -->|新Job启动| A
```

## 2.1 符号总览（全局速查表）

> 用于全文统一检索；后续关键章节还会提供局部符号表，避免来回翻页。

| 符号                        | 代码/字段名                                | 含义                                         | 单位/范围             | 首次重点出现   |
|---------------------------|---------------------------------------|--------------------------------------------|-------------------|----------|
| $\lambda$                 | `windowedThroughput` 的理论映射            | 到达率（论文理论量）                                 | req/s, $\ge 0$    | 3.2.1, 6 |
| $\hat{\lambda}$           | `avg(windowedThroughput)`             | 估计到达率（5窗口均值）                               | req/s, $\ge 0$    | 7.2      |
| $\mu$                     | 无直接字段（理论量）                            | 单服务台服务率                                    | req/s, $>0$       | 6        |
| $\hat{\mu}$               | 由 $\hat{\lambda}, c, \bar g_{eff}$ 反推 | 估计单 worker 服务率                             | req/s, $>0$       | 7.5      |
| $c$                       | `currentParallelism`                  | 并行 worker 数（服务台数）                          | 正整数               | 7.1      |
| $b$                       | `currentBatchSize`                    | 当前批大小                                      | 正整数               | 7.1      |
| $\rho$                    | 无直接字段（理论量）                            | 单服务台利用率                                    | $[0,1)$ 稳态        | 6        |
| $\hat{\rho}$              | 由估计式得到                                | 估计利用率                                      | 近似 $\bar g_{eff}$ | 7.7      |
| $a$                       | `offered load`（理论量）                   | 总 offered load, $a=\lambda/\mu$            | 无量纲, $\ge 0$      | 6.2      |
| $\hat a$                  | 由估计式得到                                | 估计 offered load                            | 无量纲               | 7.7      |
| $P_{wait}$                | `erlang_c_formula` 输出                 | 需要排队的概率                                    | $[0,1]$           | 6.2      |
| $\mathbb{E}[W_q]$         | `compute_expected_sojourn_time` 中间量   | 平均排队等待时间                                   | s, $\ge 0$        | 6.3      |
| $\mathbb{E}[T]$           | `compute_expected_sojourn_time` 输出    | 平均系统时间（sojourn）                            | s, $>0$           | 6.3      |
| $\mathbb{E}[T]_{current}$ | 当前 $c$ 下计算结果                          | 当前配置理论平均系统时间                               | s                 | 8.4      |
| $\text{SLO}_{ms}$         | `runtime_slo_ms` / `slo_ms`           | 延迟目标（毫秒）                                   | ms, $>0$          | 8.5      |
| $\text{SLO}_s$            | `slo_ms / 1000`                       | 秒级 SLO 阈值                                  | s, $>0$           | 8.5      |
| $x_i$                     | `windowedThroughput_i`                | 第 $i$ 个窗口吞吐率                               | req/s             | 7.1      |
| $g_i$                     | `windowedGPUUtilization_i`            | 第 $i$ 个窗口 GPU 利用率                          | 通常 $[0,1]$        | 7.1      |
| $s_i$                     | `windowedSLORate_i`                   | 第 $i$ 个窗口 SLO 达标率                          | $[0,1]$           | 7.1      |
| $n$                       | `REPORT_WINDOW_NUM`                   | 历史窗口数                                      | 当前为 5             | 7.1      |
| $\bar g$                  | `avg(windowedGPUUtilization)`         | GPU 利用率均值                                  | 通常 $[0,1]$        | 7.3      |
| $\bar g_{eff}$            | `max(\bar g, 1e-3)`                   | 利用率地板修正值                                   | $\ge 10^{-3}$     | 7.4      |
| $\varepsilon$             | 常量 `1e-3`                             | 地板值，防除零与极端值                                | $10^{-3}$         | 7.4      |
| $\theta_{overload}$       | 常量 `0.95`                             | GPU 过载短路阈值                                 | 0.95              | 8.3      |
| $                         | history                               | $                                          | `len(history)`    | 可用窗口样本数  | 非负整数 | 8.1 |
| $c_{stable,min}$          | 搜索起点                                  | 稳态下界 $\lfloor\hat\lambda/\hat\mu\rfloor+1$ | 正整数               | 8.7      |
| $c_{min}$                 | `find_min_parallelism` 输出             | 满足 SLO 的最小可行并行度                            | 正整数或空             | 8.7      |
| `need_reconfig`           | `check_reconfiguration_needed` 返回     | 是否触发重配置                                    | 布尔                | 8        |
| `scale_direction`         | 返回值之一                                 | 动作方向（`scale_up/down`）                      | 枚举                | 8        |
| `hint_parallelism`        | 返回值之一                                 | 推荐并行度                                      | 整数或空              | 8, 12.2  |
| `hint_batchsize`          | 返回值之一                                 | 推荐批大小（当前常为 `None`）                         | 整数或空              | 8, 12.2  |
| `current_job_id`          | 全局状态                                  | 当前 Flink Job ID                            | 32位 hex 字符串       | 12.3     |
| `is_reconfiguring`        | 全局状态                                  | 是否处于重配置过程                                  | 布尔                | 12.1     |
| `reconfiguration_lock`    | 全局锁                                   | 防并发重配置                                     | 互斥锁               | 12.1     |
| `TIMEOUT_SECONDS`         | 看门狗常量                                 | 无上报超时时间                                    | 当前 180s           | 13       |

---

## 3. 重配置脚本与 `NJULocalCacheTestSink.java` 的交互

这一部分是理解 Daemon 的前提，因为 Daemon 的所有判断都建立在 Sink 提供的数据口径上。

### 3.1 Daemon 接收的是什么

Sink 每个上报周期构造一个 `MetricsPayload`，字段如下：

- `nodeIp`
- `windowStartTimestamp`
- `windowEndTimestamp`
- `windowedThroughput`
- `windowedSLORate`
- `windowedGPUUtilization`
- `currentParallelism`
- `currentBatchSize`

**局部符号表（3.1：Payload 字段）**

| 字段/符号                    | 含义             | 单位/备注          |
|--------------------------|----------------|----------------|
| `nodeIp`                 | 指标上报节点 IP      | 字符串            |
| `windowStartTimestamp`   | 窗口开始时间戳        | ms since epoch |
| `windowEndTimestamp`     | 窗口结束时间戳        | ms since epoch |
| `windowedThroughput`     | 窗口吞吐率          | req/s          |
| `windowedSLORate`        | 窗口 SLO 达标率     | $[0,1]$        |
| `windowedGPUUtilization` | 窗口 GPU 利用率     | 通常 $[0,1]$     |
| `currentParallelism`     | 当前并行度          | 正整数            |
| `currentBatchSize`       | 当前批大小          | 正整数            |
| `durationMs`             | 窗口时长（由起止时间差得到） | ms             |

Python 端的 `MetricsPayload` 与 Java 端字段名一一对应，所以 Daemon 可以直接把 JSON 数组反序列化为同构对象列表。

### 3.2 Payload 的指标在 Sink 中的计算逻辑

`NJULocalCacheTestSink.doReportMetrics()` 的核心口径如下。

#### 3.2.1 窗口吞吐率

设当前窗口内：

- 成功请求数为 `currentSuccess`
- 窗口时长为 `durationMs`

则窗口吞吐率为：

$\text{windowedThroughput} = \frac{\text{currentSuccess}}{\text{durationMs}/1000} \quad (\text{req/s})$

注意：这里的分子是**成功请求数**，不是总到达请求数。因此在 Daemon 里把它当成到达率 \(\lambda\) 时，应理解为：

> 在当前实现里，$\lambda$ 不是外部独立测得的真实到达率，而是“窗口成功吞吐率对稳态到达率的近似”。这里利用了 Little Law 的隐式假设：在近稳态且成功率较高的情况下，成功吞吐率可以近似到达率。

#### 3.2.2 窗口 SLO 达成率

设当前窗口内：

- 总请求数为 `currentTotal`
- 满足 SLO 的请求数为 `currentUnderSLO`

则窗口 SLO 达成率为：

$\text{windowedSLORate} = \frac{\text{currentUnderSLO}}{\text{currentTotal}}$

这个量会被 Daemon 记录和打印，但**当前代码并没有把它纳入重配置判定公式**。

#### 3.2.3 窗口 GPU 利用率

设当前窗口内：

- 累积 GPU 推理时间为 `currentWindowGpuMs`
- 窗口时长为 `durationMs`
- 并行度为 `parallelism`

则窗口 GPU 利用率为：

$\text{windowedGPUUtilization} = \frac{\text{currentWindowGpuMs}}{\text{durationMs} \cdot \text{parallelism}}$

这个 GPU 利用率实际上是：

> 用“每个 worker 平均有多少时间处于 GPU 推理忙碌状态”来近似单 worker 利用率。**基于一个假设：一个请求处于推理时间 = 一个 worker 处于服务态的时间**。

这正是 Daemon 把它映射到 M/M/c 中 $\rho$ 的原因。

### 3.3 Sink 发送最近 5 个窗口的历史

Sink 内部维护 `metricsHistory`，每次上报时：

1. 先将当前窗口 `payload` 压入历史；
2. 最多保留最近 `REPORT_WINDOW_NUM = 5` 个窗口；
3. 将整个 `metricsHistory` 序列化为 JSON 数组发给 Daemon。

因此 Daemon 的输入不是一个点，而是一段短历史。  
Daemon 后续使用的是这 5 个窗口的均值，而不是最后一个窗口的瞬时值。

### 3.4 重配置 (任务重启) 后不继承旧窗口历史

`NJULocalCacheTestSink` 虽然对 `metricsHistory` 做了状态快照，但在 `initializeState()` 恢复时，恢复旧历史的代码被故意注释掉了。

这意味着：

- 新 Job 启动后不会混入旧配置下的窗口历史；
- Daemon 会重新等待凑满 5 个窗口后再做判断；
- 不会用“旧配置的指标”去评估“新配置是否合理”。

这对自动重配置尤其重要，因为它避免了跨配置污染。

### 3.5 Sink 算子与重配置脚本的连接策略

`NJULocalCacheTestSink` 的连接策略非常明确：

- `open()` 中调用 `connectOrStartDaemon()`
  - 先尝试连接已有 Daemon；
  - 连不上才启动新的 Python Daemon。
- 运行中断线时调用 `reconnectToDaemon()`
  - 只重连；
  - 不再新启动 Daemon。

所以系统的设计目标是：

> Daemon 进程长驻且唯一；Flink Job 可以多次重启，但都回连同一个 Daemon 进程。

---

## 4. 重配置脚本的总体结构

从职责上看，这个文件可以拆成六层。

| 层次    | 主要函数                                                                                                             | 作用                    |
|-------|------------------------------------------------------------------------------------------------------------------|-----------------------|
| 数据模型层 | `MetricsPayload`                                                                                                 | 承接 Java Sink 发来的指标结构  |
| 状态层   | `current_job_id`、`is_reconfiguring` 等全局状态                                                                        | 保存跨连接、跨重配置的控制状态       |
| 接入层   | `main()`、`handle_connection()`                                                                                   | 监听 TCP、接收并解析 JSON 数组  |
| 理论判定层 | `check_reconfiguration_needed()`、`erlang_c_formula()`、`compute_expected_sojourn_time()`、`find_min_parallelism()` | 用 M/M/c 判断是否该重配置      |
| 执行层   | `trigger_reconfiguration()`                                                                                      | 确定新参数并调用 `rescale.sh` |
| 守护层   | `watchdog()`、`update_heartbeat()`                                                                                | 防止 Daemon 在无连接时长期僵死   |

---

## 5. 重配置监控脚本的主流程：从启动到下一轮监控

### 5.1 启动流程

`main()` 的执行顺序如下：

1. 解析命令行参数；
2. 初始化运行期全局参数：
   - `runtime_max_requests`
   - `runtime_base_interval`
   - `runtime_cache_type`
   - `runtime_slo_ms`
   - `runtime_target_throughput`
   - `runtime_target_slo_rate`
3. 初始化当前 Job ID：
   - 优先使用 CLI 传入值；
   - 否则通过 Flink REST API 查询 RUNNING Job；
4. 启动看门狗线程；
5. 监听 TCP 端口；
6. 等待 Sink 建立连接；
7. 每来一个连接就起一个线程执行 `handle_connection()`。(实际上同一时刻也只会有一个 sink 算子)

### 5.2 单个连接上的处理流程

`handle_connection()` 会对一个长连接循环做如下处理：

1. 逐行读取；
2. 每一行都被视为一个 JSON 数组；
3. 解析为 `List[MetricsPayload]`；
4. 记录最新窗口日志；
5. 调用 `check_reconfiguration_needed()`；
6. 如果需要重配置，则异步启动 `trigger_reconfiguration()`。

### 5.3 重配置完成后的行为

Daemon 进程不会在一次重配置后退出，而是继续等待新 Sink 重新连接。  
因此它的真实运行模式是“持续监控、多轮判定、按需多次重配置”。

完整流程如下：

```mermaid
flowchart TD
    A[Daemon启动] --> B[解析CLI参数]
    B --> C[初始化Job ID与运行时参数]
    C --> D[启动watchdog]
    D --> E[监听TCP端口]
    E --> F[Sink连接]
    F --> G[接收一行JSON数组]
    G --> H[反序列化为payload_history]
    H --> I[check_reconfiguration_needed]
    I -->|无需重配置| G
    I -->|需要重配置| J[异步 trigger_reconfiguration]
    J --> K[调用 rescale.sh]
    K --> L[更新 current_job_id]
    L --> M[等待新Sink重连]
    M --> G
```

---

## 6. 重配置脚本的核心部分之一：是否需要重配置的判断逻辑

这一节是整个重配置脚本的第一个核心部分。为了讲清楚，必须把三层东西分开：

1. **标准 M/M/c 理论公式**；
2. **代码如何用 Sink 指标去估计理论参数**；
3. **代码在理论之外加入的工程保护**。

### 6.1 标准 M/M/c 理论前提

标准 M/M/c 模型假设：

- 到达过程近似为泊松过程；
- 单个服务台服务时间服从指数分布；
- 共有 $c$ 个同质服务台；
- 先来先服务；
- 队列容量无限；
- 当 $\lambda < c\mu$ 时系统稳态存在。

这里：

- $\lambda$：系统到达率；
- $\mu$：单个服务台服务率；
- $c$：服务台数量；
- $a = \lambda / \mu$：offered load；
- $\rho = \lambda / (c\mu) = a/c$：单服务台利用率。

> 需要特别强调：代码中使用 M/M/c 是一种**决策近似模型**，不是在运行时证明业务流量严格满足这些分布假设。

### 6.2 标准 Erlang-C 公式

当 $0 \le \rho < 1$ 时，等待概率为：

$P_{\text{wait}} = \frac{\frac{a^c}{c!}\cdot \frac{1}{1-\rho}}
{\sum_{k=0}^{c-1}\frac{a^k}{k!}+\frac{a^c}{c!}\cdot \frac{1}{1-\rho}}$

重配置脚本代码中的 `erlang_c_formula(c, a)` 实现的正是这个式子。  
如果 $\rho \ge 1$，代码直接返回 `1.0`，把系统视为“全部请求都需要排队”的极端不稳定状态。

### 6.3 平均等待时间与平均系统时间

标准 M/M/c 中：

$\mathbb{E}[W_q] = \frac{P_{\text{wait}}}{c\mu-\lambda}$

$\mathbb{E}[T] = \mathbb{E}[W_q] + \frac{1}{\mu}$

其中：

- $\mathbb{E}[W_q]$：平均排队等待时间；
- $1/\mu$：平均服务时间；
- $\mathbb{E}[T]$：平均系统时间（sojourn time）。

重配置脚本代码中的 `compute_expected_sojourn_time(c, lam, mu)` 对应的就是这个计算。  
若 $c\mu \le \lambda$，函数返回 `None`，表示系统不稳定、$\mathbb{E}[T]$ 理论上发散。

---

## 7. 观测指标与 M/M/c 参数的映射关系

### 7.1 观测窗口记号

**局部符号表（7.1-7.7：参数映射）**

| 符号              | 含义                | 来源/计算                              |
|-----------------|-------------------|------------------------------------|
| $n$             | 历史窗口数             | 当前固定为 `REPORT_WINDOW_NUM=5`        |
| $i$             | 窗口索引              | $i\in\{1,\dots,n\}$                |
| $x_i$           | 第 $i$ 个窗口吞吐率      | `windowedThroughput_i`             |
| $s_i$           | 第 $i$ 个窗口 SLO 达标率 | `windowedSLORate_i`                |
| $g_i$           | 第 $i$ 个窗口 GPU 利用率 | `windowedGPUUtilization_i`         |
| $c$             | 当前并行度             | 最新窗口 `currentParallelism_n`        |
| $b$             | 当前批大小             | 最新窗口 `currentBatchSize_n`          |
| $\hat{\lambda}$ | 估计到达率             | $\frac{1}{n}\sum_i x_i$            |
| $\bar g$        | GPU 利用率均值         | $\frac{1}{n}\sum_i g_i$            |
| $\bar g_{eff}$  | 利用率修正值            | $\max(\bar g,\varepsilon)$         |
| $\varepsilon$   | 地板值               | $10^{-3}$                          |
| $\hat\mu$       | 估计服务率             | $\hat\lambda/(c\cdot\bar g_{eff})$ |
| $\hat a$        | 估计 offered load   | $\hat\lambda/\hat\mu$              |
| $\hat\rho$      | 估计利用率             | $\hat\lambda/(c\hat\mu)$           |

设 Daemon 收到的历史窗口数为 \(n\)。当前实现中要求：

$n = \texttt{REPORT_WINDOW_NUM} = 5$

对第 \(i\) 个窗口，定义：

- $x_i = \text{windowedThroughput}_i$
- $s_i = \text{windowedSLORate}_i$
- $g_i = \text{windowedGPUUtilization}_i$

并以最新窗口中的：

- $c = \text{currentParallelism}_{n}$
- $b = \text{currentBatchSize}_{n}$

作为当前配置。

### 7.2 到达率估计 $\hat{\lambda}$

用 5 个窗口吞吐率均值估计到达率：

$\hat{\lambda} = \frac{1}{n}\sum_{i=1}^{n} x_i$

单位是 req/s。

严格地说，这里得到的是**成功吞吐率均值**，而不是外部独立采样的真实到达率。  
因此更精确的表述应是：

> 在系统近稳态、成功率较高且无大规模排队积压漂移时，用窗口成功吞吐率均值近似到达率。(Little Law)

### 7.3 GPU 利用率均值 $\bar{g}$

代码计算：

$\bar{g} = \frac{1}{n}\sum_{i=1}^{n} g_{i}$

并把它作为单 worker 利用率 $\rho$ 的工程代理。

这一步不是排队论定理，而是本系统中的**建模假设**：

> 在 GPU 主导的 LLM 推理场景下，单 worker 的 GPU 忙碌比例可以近似反映 worker 的服务忙碌比例。

### 7.4 GPU 地板值保护

代码使用：

$\bar{g}_{\text{eff}} = \max(\bar{g}, \varepsilon)$

其中：

$\varepsilon = 10^{-3}$

作用有两个：

1. 避免后续用 $1/\bar{g}$ 时出现除零；
2. 在极低负载下仍能推导出一个非常大的 $\hat{\mu}$，从而自然产生缩容判断。

### 7.5 单 worker 服务率估计 $\hat{\mu}$

这是当前实现最关键的公式。重配置脚本代码使用：

$\hat{\mu} = \frac{\hat{\lambda}}{c \cdot \bar{g}_{\text{eff}}}$

推导来自稳态利用率恒等式：

$\rho = \frac{\lambda}{c\mu}$

若用 $\bar{g}_{\text{eff}}$ 近似 $\rho$，就得到：

$\hat{\mu} = \frac{\hat{\lambda}}{c \cdot \bar{g}_{\text{eff}}}$

### 7.6 为什么这个 $\hat{\mu}$ 公式非常重要

一个常见但错误的写法是：

$\mu' = \frac{\lambda}{c}$

如果把它代回利用率定义，会得到：

$\rho' = \frac{\lambda}{c\mu'} = \frac{\lambda}{c \cdot (\lambda/c)} = 1$

这意味着系统会被错误地估计成“永远满载”，后续 Erlang-C 几乎总会判定不稳定。  
因此当前代码明确采用：

$\hat{\mu} = \frac{\hat{\lambda}}{c \cdot \bar{g}_{\text{eff}}}$

而不是 $\lambda/c$。

### 7.7 派生量 $\hat{a}$ 与 $\hat{\rho}$

得到 $\hat{\lambda}$ 和 $\hat{\mu}$ 后，代码隐式构造：

$\hat{a} = \frac{\hat{\lambda}}{\hat{\mu}} = c \cdot \bar{g}_{\text{eff}}$

$\hat{\rho} = \frac{\hat{\lambda}}{c\hat{\mu}} = \bar{g}_{\text{eff}}$

这两个量分别对应：

- $\hat{a}$：总 offered load；
- $\hat{\rho}$：单 worker 利用率估计。

---

## 8. “是否重配置”的完整判定过程

下面按代码真实执行顺序展开。

**局部符号表（8.x：决策判定）**

| 符号/变量               | 含义            | 当前实现值/规则                                |
|---------------------|---------------|-----------------------------------------|
| $                   | history       | $                                       | 样本窗口个数 | 必须 $\ge 5$ 才进入建模 |
| `REPORT_WINDOW_NUM` | 最小窗口要求        | 5                                       |
| $10^{-6}$           | 零流量近似阈值       | 若 $\hat\lambda<10^{-6}$ 则跳过             |
| $\theta_{overload}$ | GPU 过载阈值      | $0.95$                                  |
| $\text{SLO}_s$      | 秒级 SLO 阈值     | `slo_ms / 1000`                         |
| $c_{stable,min}$    | 稳态搜索起点        | $\lfloor\hat\lambda/\hat\mu\rfloor + 1$ |
| $c_{min}$           | 满足 SLO 的最小并行度 | `find_min_parallelism` 线性搜索结果           |
| `need_reconfig`     | 是否重配置         | 布尔返回值                                   |
| `scale_direction`   | 动作方向          | `scale_up` / `scale_down` / `None`      |
| `hint_parallelism`  | 推荐并行度         | 整数或 `None`                              |
| `hint_batchsize`    | 推荐批大小         | 当前主路径通常 `None`                          |

### 8.1 Step 0：先做输入合法性过滤

`check_reconfiguration_needed()` 在正式计算前会先过滤掉不适合建模的情况。

#### 条件 1：历史为空

若 `history` 为空，直接返回“不重配置”。

#### 条件 2：窗口数不足 5

若：

$|history| < 5$

也直接跳过。

这是为了避免刚启动时样本太少导致误判。

#### 条件 3：到达率近零

若：

$\hat{\lambda} < 10^{-6}$

也直接跳过。因为流量几乎为零时，排队模型失去实际意义。

#### 条件 4：当前并行度非法

若：

$c \le 0$

同样跳过，因为此时模型本身无定义。

这一段流程图如下：

```mermaid
flowchart TD
    A[收到 payload_history] --> B{history 为空?}
    B -->|是| N[返回 不重配置]
    B -->|否| C{窗口数 < 5?}
    C -->|是| N
    C -->|否| D{lambda_hat < 1e-6?}
    D -->|是| N
    D -->|否| E{currentParallelism <= 0?}
    E -->|是| N
    E -->|否| F[进入正式 M/M/c 判定]
```

### 8.2 Step 1：估计当前系统参数

代码使用如下估计：

$\hat{\lambda} = \frac{1}{n}\sum_{i=1}^{n} x_i$

$\bar{g} = \frac{1}{n}\sum_{i=1}^{n} g_i$

$\bar{g}_{\text{eff}} = \max(\bar{g}, 10^{-3})$

$\hat{\mu} = \frac{\hat{\lambda}}{c \cdot \bar{g}_{\text{eff}}}$

$\hat{a} = \frac{\hat{\lambda}}{\hat{\mu}} = c \cdot \bar{g}_{\text{eff}}$

$\hat{\rho} = \frac{\hat{\lambda}}{c \hat{\mu}} = \bar{g}_{\text{eff}}$

### 8.3 Step 2：GPU 过载短路

代码定义了过载阈值：

$\theta_{\text{overload}} = 0.95$

若：

$\bar{g} \ge \theta_{\text{overload}}$

则代码**不再继续计算 Erlang-C**，而是直接返回：

```text
(True, "scale_up", None, None)
```

这一步是工程保护，而不是 M/M/c 标准公式的一部分。  
它的意图是：当 GPU 利用率已经逼近 100% 时，系统处于高风险区，直接扩容比等待理论时间继续恶化更稳妥。

### 8.4 Step 3：计算当前配置下的理论平均系统时间 (端到端时间)

如果没有触发 GPU 过载短路，则继续计算：

$\mathbb{E}[T]_{\text{current}} = \mathbb{E}[T](c, \hat{\lambda}, \hat{\mu})$

具体分为三步：

1. 计算 $\hat{a} = \hat{\lambda}/\hat{\mu}$；
2. 计算 $P_{\text{wait}} = \text{ErlangC}(c, \hat{a})$；
3. 计算：

$\mathbb{E}[W_q] = \frac{P_{\text{wait}}}{c\hat{\mu}-\hat{\lambda}}$

$\mathbb{E}[T]_{\text{current}} = \mathbb{E}[W_q] + \frac{1}{\hat{\mu}}$

若 $c\hat{\mu} \le \hat{\lambda}$，则当前配置被视为不稳定，代码把 $\mathbb{E}[T]_{\text{current}}$ 记为 `None`。

### 8.5 Step 4：把 SLO 从毫秒转成秒

设配置传入的延迟目标是 `slo_ms`，则代码使用：

$\text{SLO}_s = \frac{\text{slo\_ms}}{1000}$

因为 `compute_expected_sojourn_time()` 的输出单位是秒。

### 8.6 Step 5：判断当前配置是否已经不满足 SLO

若出现以下任一情况，则直接判定**需要扩容**。

#### 情况 A：系统不稳定

即：

$c\hat{\mu} \le \hat{\lambda} \quad\Leftrightarrow\quad \hat{\rho} \ge 1$

此时：

$\mathbb{E}[T]_{\text{current}} = \infty$

代码返回：

```text
(True, "scale_up", c_min, None)
```

其中 `c_min` 来自后续的最小并行度搜索。

#### 情况 B：理论平均系统时间超过 SLO

若：

$\mathbb{E}[T]_{\text{current}} > \text{SLO}_s$

则同样返回扩容：

```text
(True, "scale_up", c_min, None)
```

### 8.7 Step 6：计算满足 SLO 的最小并行度 $c_{\min}$

如果当前配置已经满足 SLO，重配置脚本还会继续下一步逻辑：

> 是否存在更小的并行度，也同样满足 SLO？

代码把这个问题写成一个线性搜索：

$c_{\min} = \min \left\{ c' \in \mathbb{Z}_{\ge 1} \;\middle|\; \mathbb{E}[T](c', \hat{\lambda}, \hat{\mu}) \le \text{SLO}_s,\; c'\hat{\mu} > \hat{\lambda} \right\}$

搜索起点不是 1，而是稳定性下界：

$c_{\text{stable,min}} = \lfloor \hat{a} \rfloor + 1 = \left\lfloor \frac{\hat{\lambda}}{\hat{\mu}} \right\rfloor + 1$

原因是稳定系统必须满足：

$c' > \frac{\hat{\lambda}}{\hat{\mu}}$

代码随后在线性区间

$c' \in [c_{\text{stable,min}}, 64]$

中找到第一个满足 SLO 的 $c'$，并将其作为 `hint_parallelism`。

### 8.8 Step 7：是否可以缩容

若当前配置已经满足 SLO，且搜索到：

$c_{\min} < c$

则返回：

```text
(True, "scale_down", c_min, None)
```

其含义是：

> 当前配置虽然没违约，但并行度配高了；更小的并行度也能满足 SLO。

### 8.9 Step 8：无需重配置

若当前配置满足 SLO，且：

$c_{\min} \ge c$

或搜索不到更小的可行值，则返回：

```text
(False, None, None, None)
```

这表示当前配置已经处在“满足 SLO 的当前规模附近”，没有必要变更。

---

## 9. 判定是否重配置的逻辑总览

```mermaid
flowchart TD
    A[收到最近5个窗口指标] --> B[计算 lambda_hat avg_gpu c]
    B --> C{avg_gpu >= 0.95 ?}
    C -->|是| U1[直接 scale_up]
    C -->|否| D[计算 mu_hat = lambda_hat / (c * avg_gpu_eff)]
    D --> E[计算 E[T]_current]
    E --> F{系统不稳定 或 E[T]_current > SLO ?}
    F -->|是| U2[scale_up 并给出 c_min hint]
    F -->|否| G[搜索满足 SLO 的最小 c_min]
    G --> H{c_min < current c ?}
    H -->|是| D1[scale_down]
    H -->|否| N[不重配置]
```

---

## 10. M/M/c 判定的子步骤与公式总表

### 10.1 子步骤 1：窗口统计量定义

对最近 \(n=5\) 个窗口：

$x_i = \text{windowedThroughput}_i$

$g_i = \text{windowedGPUUtilization}_i$

$s_i = \text{windowedSLORate}_i$

### 10.2 子步骤 2：观测均值计算

$\hat{\lambda} = \frac{1}{n}\sum_{i=1}^{n} x_i$

$\bar{g} = \frac{1}{n}\sum_{i=1}^{n} g_i$

$\bar{s} = \frac{1}{n}\sum_{i=1}^{n} s_i$

其中 $\bar{s}$ 在当前实现中只用于日志解释，不用于决策。

### 10.3 子步骤 3：极低利用率修正

$\bar{g}_{\text{eff}} = \max(\bar{g}, \varepsilon), \quad \varepsilon = 10^{-3}$

### 10.4 子步骤 4：服务率反推

由稳态关系：

$\rho = \frac{\lambda}{c\mu}$

以及工程近似：

$\rho \approx \bar{g}_{\text{eff}}$

得到：

$\hat{\mu} = \frac{\hat{\lambda}}{c \cdot \bar{g}_{\text{eff}}}$

### 10.5 子步骤 5：offered load 与利用率

$\hat{a} = \frac{\hat{\lambda}}{\hat{\mu}}$

$\hat{\rho} = \frac{\hat{\lambda}}{c\hat{\mu}} = \frac{\hat{a}}{c}$

在当前实现中，由于 $\hat{\mu}$ 的反推方式，上式还可化简为：

$\hat{\rho} = \bar{g}_{\text{eff}}$

### 10.6 子步骤 6：等待概率

当 $(\hat{\rho} < 1)$ 时：

$P_{\text{wait}} = \frac{\frac{\hat{a}^c}{c!}\cdot \frac{1}{1-\hat{\rho}}}{\sum_{k=0}^{c-1}\frac{\hat{a}^k}{k!}+\frac{\hat{a}^c}{c!}\cdot \frac{1}{1-\hat{\rho}}}$

当 $(\hat{\rho} \ge 1)$ 时，代码把系统视为不稳定状态，直接按“必须扩容”处理。

### 10.7 子步骤 7：平均等待时间

$\mathbb{E}[W_q] = \frac{P_{\text{wait}}}{c\hat{\mu}-\hat{\lambda}}$

要求：

$c\hat{\mu} > \hat{\lambda}$

否则系统不稳定。

### 10.8 子步骤 8：平均系统时间

$\mathbb{E}[T] = \mathbb{E}[W_q] + \frac{1}{\hat{\mu}}$

### 10.9 子步骤 9：SLO 约束判断

设：

$\text{SLO}_s = \frac{\text{SLO}_{ms}}{1000}$

则：

- 若 $\mathbb{E}[T] > \text{SLO}_s$，当前配置不满足延迟目标；
- 若 $\mathbb{E}[T] \le \text{SLO}_s$，当前配置满足延迟目标。

### 10.10 子步骤 10：最小可行并行度搜索

定义：

$
c_{\min}
=
\min
\left\{
c' \in \mathbb{Z}_{\ge 1}
\;\middle|\;
\mathbb{E}[T](c',\hat{\lambda},\hat{\mu}) \le \text{SLO}_s,\;
c'\hat{\mu} > \hat{\lambda}
\right\}
$

实现上从：

$c_{\text{stable,min}} = \left\lfloor \frac{\hat{\lambda}}{\hat{\mu}} \right\rfloor + 1$

开始线性搜索到 64。

### 10.11 子步骤 11：最终决策函数

如果把代码抽象成数学上的分段决策，其实可以写成：

$
\text{Decision} =
\begin{cases}
\text{scale\_up}, & \bar{g} \ge 0.95 \\
\text{scale\_up}, & c\hat{\mu} \le \hat{\lambda} \\
\text{scale\_up}, & \mathbb{E}[T](c,\hat{\lambda},\hat{\mu}) > \text{SLO}_s \\
\text{scale\_down}, & \mathbb{E}[T](c,\hat{\lambda},\hat{\mu}) \le \text{SLO}_s \land c_{\min} < c \\
\text{no\_change}, & \text{otherwise}
\end{cases}
$

这一式子就是当前实现对“是否要重配置”的最紧凑表达。

---

## 11. 具体重配置

### 11.1 例子 A：GPU 已经过载，直接扩容

假设最近 5 个窗口：

- 当前并行度 $c=4$
- 吞吐率均值 $\hat{\lambda}=6$ req/s
- GPU 利用率均值 $\bar{g}=0.97$

因为：

$0.97 \ge 0.95$

代码直接触发扩容，不再计算 Erlang-C。  
这类场景说明系统已经逼近满载，继续保守等待只会增加违约风险。

### 11.2 例子 B：当前理论时延超过 SLO，因此扩容

假设：

- $c=2$
- $\hat{\lambda}=1.5$ req/s
- $\bar{g}=0.75$

则：

$
\hat{\mu}
=
\frac{1.5}{2 \times 0.75}
= 1.0 \text{ req/s}
$

$
\hat{a}
=
\frac{1.5}{1.0}
= 1.5
$

$
\hat{\rho}
=
\frac{1.5}{2 \times 1.0}
= 0.75
$

对 M/M/2：

$
P_{\text{wait}}
=
\frac{\frac{1.5^2}{2!}\cdot \frac{1}{1-0.75}}
{1 + 1.5 + \frac{1.5^2}{2!}\cdot \frac{1}{1-0.75}}
=
\frac{4.5}{7}
=
0.642857
$

$
\mathbb{E}[W_q]
=
\frac{0.642857}{2\times1.0 - 1.5}
=
1.285714 \text{ s}
$

$
\mathbb{E}[T]
=
1.285714 + 1
=
2.285714 \text{ s}
$

如果目标是：

$
\text{SLO}_s = 2.0 \text{ s}
$

则：

$
\mathbb{E}[T] > \text{SLO}_s
$

因此应扩容。

### 11.3 例子 C：低负载下可缩容

假设：

- $c=8$
- $\hat{\lambda}=1$ req/s
- $\bar{g}=0.05$

则：

$
\hat{\mu}
=
\frac{1}{8 \times 0.05}
=
2.5 \text{ req/s}
$

对单 worker 的 M/M/1 来看，如果尝试 \(c'=1\)：

$
\rho' = \frac{1}{1 \times 2.5} = 0.4
$

系统稳定，并且：

$
\mathbb{E}[T]_{M/M/1}
=
\frac{1}{\mu-\lambda}
=
\frac{1}{2.5-1}
=
0.6667 \text{ s}
$

如果 SLO 是 10 秒，那么 $c'=1$ 已经足够。  
因此 $c_{\min}$ 很可能远小于 8，代码会触发缩容。

### 11.4 例子 D：SLO 达标率低，但不一定触发重配置

假设最近 5 个窗口：

- $\bar{s}=0.70$
- 但模型算出 $\mathbb{E}[T] \le \text{SLO}_s$
- 并且 $c_{\min}=c$

则当前代码**不会**仅因为 $\bar{s}$ 低就触发重配置。  
原因很简单：当前实现的决策变量是 $\mathbb{E}[T]$，而不是 $\bar{s}$。

所以一定要区分：

- `windowedSLORate`：观测指标、日志解释指标；
- $\mathbb{E}[T] \le \text{SLO}$：真正决策条件。

---

## 12. 确定需要重配置后的重配置执行逻辑

`check_reconfiguration_needed()` 只负责判断；真正执行动作的是 `trigger_reconfiguration()`。

**局部符号表（12.x：执行与控制状态）**

| 变量/符号                   | 含义                      | 备注                         |
|-------------------------|-------------------------|----------------------------|
| `current_job_id`        | 当前被控制的 Flink Job ID     | 可能来自内存、CLI 或 REST 自动发现     |
| `is_reconfiguring`      | 重配置进行中标志                | `watchdog` 会据此避免误杀         |
| `reconfiguration_lock`  | 重配置互斥锁                  | 防止并发触发                     |
| `runtime_max_requests`  | 运行时透传参数                 | 用于重提作业参数                   |
| `runtime_base_interval` | 运行时透传参数                 | 对应 Flink 参数 `baseInterval` |
| `runtime_cache_type`    | 运行时透传参数                 | 对应 Flink 参数 `cache`        |
| `new_parallelism`       | 新并行度                    | 由 hint 或回退策略生成             |
| `new_batchsize`         | 新批大小                    | 按 `scale_up/down` 做倍增/减半   |
| `New Job ID`            | `rescale.sh` stdout 关键字 | 用于解析并更新 `current_job_id`   |

### 12.1 先加锁，防止并发重配置

函数开头先尝试获取 `reconfiguration_lock`。  
如果已经有重配置在执行，则直接放弃这次触发。

同时设置：

```text
is_reconfiguring = True
```

这个标志不仅防并发，还会通知 `watchdog()` 暂停超时判定。

### 12.2 如何确定新并行度和新批次大小

这里必须区分“代码注释写的理想路径”和“当前真实主路径”。

#### 理想路径

文件里预留了 `run_pb_search()`，意图是：

- 输入当前 `parallelism` / `batchsize` / `slo_ms` / `target_throughput`
- 由外部 PB 调优脚本输出更优的 `(parallelism, batchsize)`

#### 当前真实路径

当前 `trigger_reconfiguration()` **没有调用** `run_pb_search()`。  
实际生效的是以下回退策略：

- 并行度：
  - 若 `hint_parallelism` 非空，则使用它；
  - 否则保持当前并行度不变。
- 批次大小：
  - `scale_up`：`batchsize * 2`
  - `scale_down`：`max(1, batchsize // 2)`
  - 否则不变。

因此目前真实逻辑是：

> M/M/c 决定“要不要调”和“并行度大概要调到哪里”；批大小只做一个简单的方向性配套调整。

### 12.3 调用 `rescale.sh`

确定新参数后，Daemon 会：

1. 获取旧 Job ID；
2. 构造 `bash rescale.sh ...` 命令；
3. 用 `subprocess.Popen()` 执行；
4. 实时读取 stdout；
5. 等待脚本结束。

Job ID 的来源优先级为：

1. 内存中的 `current_job_id`
2. 启动参数传入的初始 Job ID
3. Flink REST API 自动发现

### 12.4 从脚本输出中解析新 Job ID

脚本成功后，Daemon 会在 stdout 中匹配：

```text
New Job ID: <32位十六进制串>
```

如果成功解析，就调用 `set_current_job_id(new_job_id)` 更新全局状态。

### 12.5 重配置结束后为什么 Daemon 不会被误杀

`trigger_reconfiguration()` 结束前会主动调用一次 `update_heartbeat()`，然后：

- `is_reconfiguring = False`
- 释放 `reconfiguration_lock`

这样即使新 Sink 还没连回来，看门狗也会从一个刚刷新的心跳开始重新计时。

完整时序如下：

```mermaid
sequenceDiagram
    participant Sink as NJULocalCacheTestSink
    participant Daemon as daemon_reconfiguration_monitor_mmc.py
    participant Script as rescale.sh
    participant Flink as Flink Cluster

    Sink->>Daemon: 发送最近5个窗口指标
    Daemon->>Daemon: check_reconfiguration_needed
    alt 需要重配置
        Daemon->>Daemon: acquire lock & is_reconfiguring=True
        Daemon->>Script: 调用 rescale.sh(oldJobId,new p,new b,...)
        Script->>Flink: savepoint / cancel / submit
        Flink-->>Script: 新 Job RUNNING
        Script-->>Daemon: stdout 输出 New Job ID
        Daemon->>Daemon: 更新 current_job_id
        Daemon->>Daemon: update_heartbeat()
        Daemon->>Daemon: release lock
        Flink->>Sink: 新 Sink 启动
        Sink->>Daemon: 重连并继续上报
    else 不需要重配置
        Daemon->>Daemon: 继续等待下一次上报
    end
```

---

## 13. 看门狗与 Daemon 生命周期

`watchdog()` 每隔 10 秒检查一次是否超过 `TIMEOUT_SECONDS = 180` 秒没收到 Sink 数据。

### 13.1 为什么需要看门狗

如果：

- Flink Job 已结束；
- Sink 不再上报；
- 但 Daemon 还留在后台；

那么它会成为一个没有控制对象的僵尸进程。  
看门狗的目的就是在这种情况下自动退出。

### 13.2 为什么重配置期间不会误杀

只要：

```text
is_reconfiguring == True
```

看门狗就不会按空闲超时杀进程，而是持续刷新心跳。

这保证了：

- `rescale.sh` 执行时间较长时；
- 旧 Sink 已断开，新 Sink 尚未连回时；

Daemon 依然能稳定存活。

---

## 14. 几个必须指出的实现细节

### 14.1 实际窗口数是 5，不是 3

文件头部旧注释提到过“最近 3 个窗口”，但当前实际常量是：

```python
REPORT_WINDOW_NUM = 5
```

Java Sink 中也是 5。分析和论文都应以实际实现为准。

### 14.2 `windowedSLORate` 不参与核心判定

虽然 Daemon 会计算：

$
\bar{s} = \frac{1}{n}\sum_{i=1}^{n}s_i
$

但当前实现只把它用于日志，不参与是否重配置的分段判断。

### 14.3 `run_pb_search()` 已实现但未接入主链路

代码中存在 PB 搜索函数，但 `trigger_reconfiguration()` 当前没有真正调用它。  
所以不能把当前版本描述成“PB 决策主导”，更准确的说法应是：

> 当前主链路是 “M/M/c 判定 + M/M/c hint 并行度 + 批大小简单回退策略 + rescale.sh”。

### 14.4 `batchsize` 不参与 M/M/c 判定公式

当前实现里 `currentBatchSize` 只在执行重配置时参与“新参数生成”，并不进入：

- $\hat{\lambda}$ 估计
- $\hat{\mu}$ 反推
- Erlang-C
- $\mathbb{E}[T]$
- $c_{\min}$ 搜索

因此：

> 代码中的“是否重配置”本质上是并行度决策问题，批大小是后续伴随调整项。

### 14.5 新 Job 不继承旧窗口历史，是设计上的故意行为

这不是遗漏，而是为了避免重配置前后的指标混杂。  
对自动控制系统来说，这是一种“分段观测、分段决策”的隔离策略。

---

## 15. 最终总结

从表到里，这个文件的逻辑可以分三层理解。

### 表层：它做了什么

- 接收 Sink 指标；
- 判断是否需要重配置；
- 调用脚本重提 Flink Job；
- 等待下一轮上报。

### 中层：它依据什么判断

- 用最近 5 个窗口均值估计 $\hat{\lambda}$ 与 $\hat{\mu}$；
- 用 M/M/c + Erlang-C 计算 $\mathbb{E}[T]$；
- 用 $\mathbb{E}[T]$ 与 SLO 比较；
- 再用 $c_{\min}$ 判断是否能缩容。

### 深层：真正决定动作的分段规则

$
\text{Decision} =
\begin{cases}
\text{scale_up}, & \bar{g} \ge 0.95 \\
\text{scale_up}, & c\hat{\mu} \le \hat{\lambda} \\
\text{scale_up}, & \mathbb{E}[T](c,\hat{\lambda},\hat{\mu}) > \text{SLO}_s \\
\text{scale_down}, & \mathbb{E}[T](c,\hat{\lambda},\hat{\mu}) \le \text{SLO}_s \land c_{\min} < c \\
\text{no_change}, & \text{otherwise}
\end{cases}
$

因此，最准确的一句话总结是：

> `daemon_reconfiguration_monitor_mmc.py` 是一个基于 Sink 窗口观测、使用 M/M/c 理论近似评估延迟约束、再通过 `rescale.sh` 落地执行 Flink 自动重配置的控制面守护进程。
